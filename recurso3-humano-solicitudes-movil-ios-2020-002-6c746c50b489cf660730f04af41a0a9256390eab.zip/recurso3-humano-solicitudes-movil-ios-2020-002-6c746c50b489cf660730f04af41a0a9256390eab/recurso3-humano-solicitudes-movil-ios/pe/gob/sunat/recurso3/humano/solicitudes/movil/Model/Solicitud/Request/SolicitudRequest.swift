//
//  SolicitudRequest.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 11/4/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation
struct SolicitudRequest : Codable {
    
    var codPersona  : String?
    var parametrosBusqueda   : ParametrosBusqueda?
    var annSolicitud : String?
    var numSolicitud : String?
    
    func toDictionary() -> [String:Any]{
        ["codPersona":   codPersona as Any,
         "annSolicitud": annSolicitud as Any,
         "numSolicitud": numSolicitud as Any]
    }
 

}
