//
//  AutorizarRenovacionesViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import UIKit

protocol AutorizarRenovacionesViewControllerDelegate {
    func windowWasClosed()
}

private let reuseIdentifier = "RenovationTableViewCell"
class AutorizarRenovacionesViewController: ParentViewController {
    
    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selectedItemsBarView: UIView!
    
    @IBOutlet weak var selectAFilterLabel: UILabel!
    @IBOutlet weak var FilterRenovationsButton: UIButton!
    
    @IBOutlet weak var letsBeginLabel: UILabel!
    @IBOutlet weak var searchImage: UIImageView!
    
    @IBOutlet weak var noResultsLabel: UILabel!
    @IBOutlet weak var forThisMomentLabel: UILabel!
    @IBOutlet weak var emptyStateImageView: UIImageView!
    
    var renovations = [Renovacion]() //general
    var renovationsFilteredBySearch = [Renovacion]() //for applications returned by filter. After received, this array become 'applications' array
    var alerts = ToastAlerts()
    var UUOOArray: [String] = [String] ()
    var selectedRenovation : Renovacion? //application selected by simple touch on cell
    var searchIsActive = false
    var approveApplication = false
    var willBeAMassiveProcess = false
    var userIsInSelectMode = false
    var selectedRenovationsIndexPath = [IndexPath]()
    let refreshControl = UIRefreshControl()
    let group = DispatchGroup()
    var vistaFiltro = FiltroAutorizarRenovacionViewController()
    var expectedResponses : Int = 0
    var currentResponses : Int = 0
    var currentSituation = "09"
    var currentUUOO = "TODOS"
    @objc class Percentage: NSObject {
        @objc dynamic var completePercentage = 0 {
            didSet {
                print(completePercentage)
            }
        }
    }
    
    private var observer: NSKeyValueObservation?
    var approveRenovationResponseList = [AprobarRenovacionResponse]()
    var editRenovationResponseList = [EditarRenovacionResponse]()
    var delegate : AutorizarRenovacionesViewControllerDelegate?
    var percentage = Percentage()
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.AUTHORIZE_RENOVATIONS, leftImage: "iconLeft", rightImage: "iconSearch", rightImage2: "iconFilter", useSearchBar: true)
        let gif = UIImage.gif(name: "filter")
        self.searchImage.image = gif
        let gifEmpty = UIImage.gif(name: "emptyBox")
        self.emptyStateImageView.image = gifEmpty
        self.emptyStateImageView.isHidden = true
        self.noResultsLabel.isHidden = true
        self.forThisMomentLabel.isHidden = true
        self.FilterRenovationsButton.roundBorders(corner: 5.0)
        expectedResponses = 0
        currentResponses = 0
        observer = percentage.observe(\Percentage.completePercentage, options: .new) { (percentage, change) in
            print("Percentage: \(percentage)")

        }
        //table view setup
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: UIRenovacionTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: UIRenovacionTableViewCell.IDENTIFIER)
        self.tableView.tableFooterView = UIView(frame: .zero)
            //adding long press gesture
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        self.tableView.addGestureRecognizer(longPress)
            //adding refresh control for refresh on pull gesture
        self.tableView.refreshControl = refreshControl
        self.refreshControl.addTarget(self, action: #selector(retrieveRenovations), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.refreshControl.attributedTitle = NSAttributedString(string: "Recuperando renovaciones ...", attributes: attributes)
        self.tableView.isHidden = true
        self.tableView.isUserInteractionEnabled = false
        
        self.setBotonBarView(self.selectedItemsBarView, viewControllerTitle: AppConstants.VIEWCONTROLLER.TITLE.AUTHORIZE_RENOVATIONS, viewController: self)
    
        //self.retrieveRenovations()
    }
    
    func showLoadingSpinner(onView : UIView) {
        DispatchQueue.main.async {
            if !self.isShowingSpinner {
                let spinnerView = UIView.init(frame: onView.bounds)
                let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
                let activityIndicator = UIActivityIndicatorView.init(style: .white)
                var strLabel = UILabel()
                
                spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
                strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 60))
                
                
                strLabel.text = "\(self.percentage.completePercentage)% completado"
                strLabel.font = .systemFont(ofSize: 14, weight: .medium)
                strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
                
                activityIndicator.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
                activityIndicator.startAnimating()
                
                effectView.frame = CGRect(x: self.view.frame.midX - 90, y: self.view.frame.midY - strLabel.frame.height/2 , width: 180, height: 60)
                effectView.layer.cornerRadius = 15
                effectView.layer.masksToBounds = true
                
                
                effectView.contentView.addSubview(activityIndicator)
                effectView.contentView.addSubview(strLabel)
                spinnerView.addSubview(effectView)
                onView.addSubview(spinnerView)
                
                
                self.vSpinner = spinnerView
                self.isShowingSpinner = true
                print("Colocando spinner")
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: false)
        }
        print("viewWillAppear indexSelected after clean \(selectedRenovationsIndexPath.count)")
    }
    
    
    // MARK: - Miscellaneous Fuctions
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: self.tableView)
            if let indexPath = self.tableView.indexPathForRow(at: touchPoint) {
                self.selectCellOn(indexPath: indexPath)
                if !self.userIsInSelectMode {
                    self.userIsInSelectMode = true
                }
            }
        }
        print("handleLongPress indexsSelected \(selectedRenovationsIndexPath.count)")
    }
    
    private func selectCellOn(indexPath : IndexPath){
        print("selected :\(indexPath.row)")
        let cell = tableView.cellForRow(at: indexPath)
        if selectedRenovationsIndexPath.contains(indexPath){
            cell?.backgroundColor = .white
            if let index = selectedRenovationsIndexPath.firstIndex(of: indexPath){
                selectedRenovationsIndexPath.remove(at: index)
            }
        } else {
            cell!.backgroundColor = UIColor(named: "selectedColor")
            selectedRenovationsIndexPath.append(indexPath)
        }
        
        if selectedRenovationsIndexPath.count == 0 {
            self.userIsInSelectMode = false
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.ocultarBotonAction()
                botonBarView.setLabelSelectTodo()
                botonBarView.checkTotal.isChecked = false
            }
        } else {
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.setLabelTotal(totalFila: String(selectedRenovationsIndexPath.count))
                if currentSituation == "03" {
                    botonBarView.mostrarBotonAction()
                } else {
                    botonBarView.mostrarRenovationAuthorizationBotonAction()
                }
            }
        }
    }
    
    func prepareDefaultRenovationRequest()->ObtenerRenovacionesRequest{
        var request = ObtenerRenovacionesRequest()
        request.codUOrga = currentUUOO
        request.codSituacion = currentSituation
        request.dependencias = "1"
        return request
    }
    
    @objc func retrieveRenovations(){
        self.searchIsActive = false
        self.renovationsFilteredBySearch.removeAll()
        self.selectedRenovationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        self.showSpinner(onView: self.view)
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionWorker.getRenovations(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: self.prepareDefaultRenovationRequest(), onSuccess: { (onSuccessResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.renovations = onSuccessResponse.httpBody.renovaciones!

                if self.renovations.count == 0 {
                    self.emptyStateImageView.isHidden = false
                    self.noResultsLabel.isHidden = false
                    self.forThisMomentLabel.isHidden = false
                    self.letsBeginLabel.text = AppMessages.SERVICE.APROBAR_RENOVACION.NO_RESULTS_MESSAGE
                    self.selectAFilterLabel.text = AppMessages.SERVICE.APROBAR_RENOVACION.NO_RENOVATIONS_FOR_THE_MOMENT
                } else {
                    self.emptyStateImageView.isHidden = true
                    self.noResultsLabel.isHidden = true
                    self.forThisMomentLabel.isHidden = true
                    self.letsBeginLabel.isHidden = true
                    self.selectAFilterLabel.isHidden = true
                    self.searchImage.isHidden = true
                    self.tableView.isHidden = false
                }
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
                self.removeSpinner()
            }
        }, onFailed: {(onFailed) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.renovationsFilteredBySearch.removeAll()
                print("falló la obtención")
                self.renovations.removeAll()
                self.tableView.reloadData()
                self.removeSpinner()
                self.letsBeginLabel.isHidden = true
                self.selectAFilterLabel.isHidden = true
                self.searchImage.isHidden = true
                self.emptyStateImageView.isHidden = false
                self.noResultsLabel.isHidden = false
                self.forThisMomentLabel.isHidden = false
            }
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                print("falló la autenticación")
                self.refreshControl.endRefreshing()
                self.showExpiredSessionAlert(on: self)
                self.removeSpinner()
            }
        })
        
    }
    
    func prepareRenovationsForRequest() -> [AprobarRenovacion]? {
        var renovaciones : [AprobarRenovacion]?
        if selectedRenovation != nil {
            var renovationsForChecking = [Renovacion]()
            renovationsForChecking.append(selectedRenovation!)
            let errorMessage = validateRenovations(renovations: renovationsForChecking)
            if(errorMessage.count == 0){
                if searchIsActive {
                    renovaciones = [AprobarRenovacion]()
                    let renovation = AprobarRenovacion()
                    renovation.numIntencion = selectedRenovation?.numIntencion
                    renovation.codSituacion =  selectedRenovation?.codSituacion
                    if let codSituacion = renovation.codSituacion {
                        let newSituacionInt = Int(codSituacion)! + 1
                        renovation.codSituacion = formatSituation(situationInt: newSituacionInt)
                    }
                    renovaciones!.append(renovation)
                } else {
                    renovaciones = [AprobarRenovacion]()
                    let renovation = AprobarRenovacion()
                    renovation.numIntencion = selectedRenovation?.numIntencion
                    renovation.codSituacion =  selectedRenovation?.codSituacion
                    if let codSituacion = renovation.codSituacion {
                        let newSituacionInt = Int(codSituacion)! + 1
                        renovation.codSituacion = formatSituation(situationInt: newSituacionInt)
                    }
                    renovaciones!.append(renovation)
                }
                
            } else {
                DispatchQueue.main.async {
                    self.removeSpinner()
                    self.alerts.showToastAlert(vc: self, message: errorMessage)
                    //self.retrieveRenovations()
                }
                return nil
            }
        }
        
        if selectedRenovationsIndexPath.count > 0 {
            var renovationsForChecking = [Renovacion]()
            for indexPath in selectedRenovationsIndexPath {
                if searchIsActive {
                    renovationsForChecking.append(renovationsFilteredBySearch[indexPath.row])
                } else {
                    renovationsForChecking.append(renovations[indexPath.row])
                }
            }
            let errorMessage = validateRenovations(renovations: renovationsForChecking)
            
            if errorMessage.count == 0 {
                renovaciones = [AprobarRenovacion]()
                for indexPath in selectedRenovationsIndexPath{
                    var renovation : AprobarRenovacion?
                    if searchIsActive {
                        renovation = AprobarRenovacion()
                        
                        renovation?.codSituacion =  renovationsFilteredBySearch[indexPath.row].codSituacion
                        renovation?.numIntencion =  renovationsFilteredBySearch[indexPath.row].numIntencion
                        if let codSituacion = renovation?.codSituacion {
                            let newSituacionInt = Int(codSituacion)! + 1
                            renovation!.codSituacion = formatSituation(situationInt: newSituacionInt)
                        }
                        
                    } else {
                        renovation = AprobarRenovacion()
                        renovation?.codSituacion =  renovations[indexPath.row].codSituacion
                        renovation?.numIntencion =  renovations[indexPath.row].numIntencion
                        if let codSituacion = renovation?.codSituacion {
                            let newSituacionInt = Int(codSituacion)! + 1
                            renovation!.codSituacion = formatSituation(situationInt: newSituacionInt)
                        }
                    }
                    
                    if let _ = renovation{
                        renovaciones?.append(renovation!)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.removeSpinner()
                    self.alerts.showToastAlert(vc: self, message: errorMessage)
                    //self.retrieveRenovations()
                }
                return nil
            }
        }
        return renovaciones!
    }
    
    
    func prepareRenovationsForEditing(codTipoRenov: String, numPeriRenov: Int, obsRenovacion: String) -> [EditarRenovacion]? {
        var renovaciones : [EditarRenovacion]?
        if selectedRenovation != nil {
            var renovationsForChecking = [Renovacion]()
            renovationsForChecking.append(selectedRenovation!)
            
            if searchIsActive {
                renovaciones = [EditarRenovacion]()
                let renovation = EditarRenovacion()
                renovation.numIntencion = Int((selectedRenovation?.numIntencion)!)
                renovation.codTiporenov = codTipoRenov
                renovation.numPerirenov = numPeriRenov
                renovation.obsRenovacion = obsRenovacion
                renovaciones!.append(renovation)
            } else {
                renovaciones = [EditarRenovacion]()
                let renovation = EditarRenovacion()
                renovation.numIntencion = Int((selectedRenovation?.numIntencion)!)
                renovation.codTiporenov = codTipoRenov
                renovation.numPerirenov = numPeriRenov
                renovation.obsRenovacion = obsRenovacion
                renovaciones!.append(renovation)
            }
            
        }
        
        
        if selectedRenovationsIndexPath.count > 0 {
            var renovationsForChecking = [Renovacion]()
            for indexPath in selectedRenovationsIndexPath {
                if searchIsActive {
                    renovationsForChecking.append(renovationsFilteredBySearch[indexPath.row])
                } else {
                    renovationsForChecking.append(renovations[indexPath.row])
                }
            }
            
            renovaciones = [EditarRenovacion]()
            for indexPath in selectedRenovationsIndexPath{
                var renovation : EditarRenovacion?
                if searchIsActive {
                    renovation = EditarRenovacion()
                    renovation?.numIntencion =  Int(renovationsFilteredBySearch[indexPath.row].numIntencion!)!
                    renovation?.codTiporenov = codTipoRenov
                    renovation?.numPerirenov = numPeriRenov
                    renovation?.obsRenovacion = obsRenovacion
                    
                } else {
                    renovation = EditarRenovacion()
                    print(renovationsFilteredBySearch)
                    renovation?.numIntencion =  Int(self.renovations[indexPath.row].numIntencion!)!
                    renovation?.codTiporenov = codTipoRenov
                    renovation?.numPerirenov = numPeriRenov
                    renovation?.obsRenovacion = obsRenovacion
                }
                
                if let _ = renovation{
                    renovaciones?.append(renovation!)
                }
                
            }
        }
        return renovaciones
    }
    
    func validateRenovations( renovations : [Renovacion]) -> String {
        var thereIsAProblem = ""
        
        for renovation in renovations {
            if(renovation.codSituacion == "09" && (renovation.estado == "NO RENUEVA" || renovation.estado == "RENUEVA") && (renovation.codPDF == nil || renovation.codPDF!.count < 4)) {
                thereIsAProblem = "No puede finalizar si el colaborador no firmó electrónicamente o se cargó un documento"
            } else if (renovation.codSituacion == "03" && (renovation.estado == nil || renovation.estado!.count < 3)){
                thereIsAProblem = "Un registro seleccionado no cuenta con un estado renovación"
            }
        }
        
        return thereIsAProblem
    }
    
    func formatSituation(situationInt : Int) -> String {
        var newString = ""
        if situationInt < 10 {
            newString = "0\(situationInt)"
        } else {
            newString = "\(situationInt)"
        }
        return newString
    }
    
    @IBAction func filterRenovationsButtonAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "filtroAutorizarRenovaciones") as! FiltroAutorizarRenovacionViewController
        vc.modalPresentationStyle = .fullScreen
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
        vistaFiltro = vc
    }
    
    func callApproveService(with request : [AprobarRenovacion]){
        
    }
    

    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DetalleAutorizacionViewController {
            vc.parametersForRenovationDetail = self.selectedRenovation
        } else if let vc = segue.destination as? FiltroAutorizarRenovacionViewController {
            vc.delegate = self
        }
    }
 
}


// MARK: - EXTENSION TABLEVIEW
extension AutorizarRenovacionesViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if renovations.count == 0 {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: false)
        } else {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: true)
        }
        
        if searchIsActive {
            return renovationsFilteredBySearch.count
        }
        return renovations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UIRenovacionTableViewCell.IDENTIFIER ,for: indexPath) as! UIRenovacionTableViewCell
        cell.selectionStyle = .none
        
        let renovation : Renovacion?
        if searchIsActive {
            renovation = renovationsFilteredBySearch[indexPath.row]
        } else {
            renovation = renovations[indexPath.row]
        }
        
        if selectedRenovationsIndexPath.contains(indexPath){
            cell.backgroundColor = UIColor(named: "selectedColor")
        } else {
            cell.backgroundColor = .white
        }
        
        
        
        if let codUOrga = renovation?.codUOrga, let desUOrga = renovation?.desUOrga {
            cell.codUOrgaAndDesUOrgaLabel.text = codUOrga + " - " + desUOrga
        }
        if let codRegistro = renovation?.codRegistro, let nombPersona = renovation?.nombPersona {
            cell.codRegistroAndNombPersonaLabel.text = codRegistro + " - " + nombPersona
        }
        if let situacion = renovation?.situacion {
            cell.situacionLabel.text = situacion
        }
        
        // validar el estado -> RENUEVA, NO RENUEVA O NULL
        
        if let estado = renovation?.estado {
            cell.desPeriodoAndTipContratoLabel.text = "\(estado) - "
            let image = UIImage(named: "notificationCircle")
            let tintedImage = image?.withRenderingMode(.alwaysTemplate)
            cell.IconUIImageView.image = tintedImage
            cell.IconUIImageView.tintColor = UIColor(named: "renovationCircleColor")
            cell.UIRNSLabel.text = estado.first?.uppercased()
            if estado == "RENUEVA" {
                if let periodo = renovation?.desPeriodo {
                    cell.desPeriodoAndTipContratoLabel.text! +=  "\(periodo) - "
                }
            }
        } else {
            cell.desPeriodoAndTipContratoLabel.text = "SIN ESTADO - "
            let image = UIImage(named: "notificationCircle")
            let tintedImage = image?.withRenderingMode(.alwaysTemplate)
            cell.IconUIImageView.image = tintedImage
            cell.IconUIImageView.tintColor = UIColor(named: "renovationCircleColor")
            cell.UIRNSLabel.text = "S"
        }
        
        
        if let tipContrato = renovation?.tipContrato {
            cell.desPeriodoAndTipContratoLabel.text! += tipContrato
        }
        
        
        if let codPdf = renovation?.codPDF {
            if (codPdf.count == 0 ){
                cell.isSignedImageView.isHidden = true
            } else {
                cell.isSignedImageView.isHidden = false
            }
        } else  {
            cell.isSignedImageView.isHidden = true
        }
        
        if let observacion = renovation?.observacion {
            if (observacion.count == 0 ){
                cell.observartionImage.isHidden = true
            } else {
                cell.observartionImage.isHidden = false
            }
        } else  {
            cell.observartionImage.isHidden = true
        }
        
        cell.delegate = self
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if userIsInSelectMode {
            self.selectCellOn(indexPath: indexPath)
        } else {
            if renovationsFilteredBySearch.count > 0 {
                self.selectedRenovation = renovationsFilteredBySearch[indexPath.row]
            } else {
                self.selectedRenovation = renovations[indexPath.row]
            }
            self.performSegue(withIdentifier: AppConstants.SEGUE.RENOVATION_DETAIL, sender: nil)
        }
    }
    
    /*func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let approveAction =  UIContextualAction(style: .destructive, title: "APROBAR", handler: { (action,view,completionHandler ) in
                self.approveApplication = false
                self.willBeAMassiveProcess = false
            UserAlerts.showAlertForRenovationsApproval(on: self)
            })
        approveAction.title = "APROBAR"
        approveAction.backgroundColor = .systemBlue
        if searchIsActive {
            self.selectedRenovation = renovationsFilteredBySearch[indexPath.row]
        } else {
            self.selectedRenovation = renovations[indexPath.row]
        }
        let configuration = UISwipeActionsConfiguration(actions: [approveAction])
        return configuration
    }*/
    
    func setupHiddenPropertyForNotFoundRelatedViews(isHidden :  Bool){
        /*self.noItemsFoundView.isHidden = isHidden
        self.imgNotFoundItems.isHidden = isHidden
        self.lblNotFoundItems.isHidden = isHidden*/
        if !isHidden {
            self.tableView.backgroundColor = .clear
        } else {
            self.tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    

}


// MARK: - EXTENSION HeaderView
extension AutorizarRenovacionesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goToMenu()
    }
    
    func goToMenu() {
        self.delegate?.windowWasClosed()
        self.dismiss(animated: true, completion: nil)
    }
    
    func actionMore() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "filtroAutorizarRenovaciones") as! FiltroAutorizarRenovacionViewController
        vc.modalPresentationStyle = .fullScreen
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
        vistaFiltro = vc
    }
    
    func searchOnBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchIsActive = true;
        if searchText.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            self.searchIsActive = false
        }else{
            self.renovationsFilteredBySearch = renovations.filter({ (renovation) -> Bool in
                self.searchIsActive = true
                let add = (renovation.codRegistro?.lowercased().contains(searchText.lowercased()) ?? false || (renovation.nombPersona?.lowercased().contains(searchText.lowercased()) ?? false))
                return add
            })
        }
        self.tableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setValue("Cancelar", forKey: "cancelButtonText")
        searchBar.showsCancelButton = true
        searchBar.enablesReturnKeyAutomatically = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = nil
        searchBar.showsCancelButton = false
        //Remove focus from the search bar.
        searchBar.endEditing(true)
        renovationsFilteredBySearch = []
        searchIsActive = false;
        self.tableView.reloadData()
     }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}


// MARK: - EXTENSION FiltroSolicitudes
extension AutorizarRenovacionesViewController: FiltroAutorizarRenovacionViewControllerDelegate {
    
    func filtersWereApplied(filteredRenovations: [Renovacion]?, codSituacion: String, UUOO: String) {
        self.tableView.isHidden = false
        self.tableView.isUserInteractionEnabled = true
        
        self.selectAFilterLabel.isHidden = true
        self.letsBeginLabel.isHidden = true
        self.searchImage.isHidden = true
        self.FilterRenovationsButton.isHidden = true
        self.FilterRenovationsButton.isEnabled = false
        self.currentSituation = codSituacion
        self.currentUUOO = UUOO
        
        self.renovations = filteredRenovations ?? [Renovacion]()

        for indexPath in selectedRenovationsIndexPath {
            let cell = self.tableView.cellForRow(at: indexPath)
            cell?.backgroundColor = .white
        }
        self.selectedRenovationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        if self.renovations.count == 0 {
            self.searchImage.isHidden = true
            self.letsBeginLabel.isHidden = true
            self.selectAFilterLabel.isHidden = true
            self.emptyStateImageView.isHidden = false
            self.noResultsLabel.isHidden = false
            self.forThisMomentLabel.isHidden = false
            self.letsBeginLabel.text = AppMessages.SERVICE.APROBAR_RENOVACION.NO_RESULTS_MESSAGE
            self.selectAFilterLabel.text = AppMessages.SERVICE.APROBAR_RENOVACION.NO_RENOVATIONS_FOR_THE_MOMENT
        } else {
            self.searchImage.isHidden = true
            self.letsBeginLabel.isHidden = true
            self.selectAFilterLabel.isHidden = true
            self.emptyStateImageView.isHidden = true
            self.noResultsLabel.isHidden = true
            self.forThisMomentLabel.isHidden = true
            self.tableView.isHidden = false
        }
        retrieveRenovations()
        self.tableView.reloadData()
    }
    
    func cleanFiltersRenovacion() {
        vistaFiltro.dismiss(animated: true, completion: nil)
        var contRenovacion = 0
        for _ in renovations{
            let index = IndexPath(row: contRenovacion, section: 0)
            if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                    self.selectedRenovationsIndexPath.remove(at: indexPosition)
            }
            contRenovacion  = contRenovacion  + 1
        }
        retrieveRenovations()
    }
    
}


// MARK: - EXTENSION BotonBarView
extension AutorizarRenovacionesViewController: BotonBarViewDelegate {
    
    func actionCheckBox() {
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            if botonBarView.getChecked(){
                self.userIsInSelectMode = true
                self.selectedRenovationsIndexPath.removeAll()
                if currentSituation == "03" {
                    botonBarView.mostrarBotonAction()
                } else {
                    botonBarView.mostrarRenovationAuthorizationBotonAction()
                }
                var counter = 0
                if self.searchIsActive{
                    botonBarView.setLabelTotal(totalFila: String (renovationsFilteredBySearch.count))
                    for _ in renovationsFilteredBySearch{
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedRenovationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                } else {
                    botonBarView.setLabelTotal(totalFila: String (renovations.count))
                    for _ in renovations {
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedRenovationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                }
                
            }else{
                self.userIsInSelectMode = false
                botonBarView.setLabelSelectTodo()
                botonBarView.ocultarBotonAction()
                var counter = 0
                if searchIsActive {
                    for _ in renovationsFilteredBySearch {
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                            self.selectedRenovationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                } else {
                    for _ in renovations {
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                            self.selectedRenovationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                }
            }
        }
        self.tableView.reloadData()
    }
    
    func actionAprobar () {
        print("Se van a aprobar \(self.selectedRenovationsIndexPath.count) solicitudes")
        var selectedRenovations = [Renovacion]()
        for indexPath in selectedRenovationsIndexPath {
            selectedRenovations.append(self.renovations[indexPath.row])
        }
        
        if selectedRenovations.count > 0 {
            UserAlerts.showAlertForRenovationsEditing(on: self, renovaciones : selectedRenovations)
        }  else {
            alerts.showToastAlert(vc: self, message: "Debe seleccionar autorizaciones para editarlas")
        }
        
        
        /*self.approveApplication = true
         self.willBeAMassiveProcess = true*/
    }
    
    func actionRechazar() {
        /*print("Se van a rechazar \(self.selectedRenovationsIndexPath.count) solicitudes")
        self.approveApplication = false
        self.willBeAMassiveProcess = true*/
        
        if selectedRenovationsIndexPath.count > 0 {
            UserAlerts.showAlertForRenovationsApproval(on: self)
        }  else {
            alerts.showToastAlert(vc: self, message: "Debe seleccionar renovaciones para autorizarlas")
        }
    }
    
    func divideArray(approveRenovationsArray : [AprobarRenovacion]) -> [[AprobarRenovacion]] {
        let arrays =  approveRenovationsArray.chunked(into: 100)
        /*var arrays = [[AprobarRenovacion]]()
        var e = approveRenovationsArray.count/100
        if e > Int(e) {
            e = Int(e) + 1
        } else {
            e = Int(e)
        }
        
        for _ in 0...(e - 1) {
            if i + 99 < approveRenovationsArray.count - 1 {
                var subarray = [AprobarRenovacion]()
                for _ in 0...99 {
                    subarray.append(approveRenovationsArray[i])
                    i += 1
                }
                arrays.append(subarray)
            } else {
                var subarray = [AprobarRenovacion]()
                for _ in i...approveRenovationsArray.count - 1 {
                    subarray.append(approveRenovationsArray[i])
                    i += 1
                }
                arrays.append(subarray)
            }
        }*/
        expectedResponses = arrays.count
        return arrays
    }
    
    func divideArrayForEditing(approveRenovationsArray : [EditarRenovacion]) -> [[EditarRenovacion]] {
        let arrays =  approveRenovationsArray.chunked(into: 100)
        
        /*var e = approveRenovationsArray.count/100
        if e > Int(e) {
            e = Int(e) + 1
        } else {
            e = Int(e)
        }
        if e < 1 {
            var subarray = [EditarRenovacion]()
            for _ in i...approveRenovationsArray.count - 1 {
                subarray.append(approveRenovationsArray[i])
                i += 1
            }
            arrays.append(subarray)
        } else {
            for _ in 0...(e - 1) {
                if i + 99 < approveRenovationsArray.count - 1 {
                    var subarray = [EditarRenovacion]()
                    for _ in 0...99 {
                        subarray.append(approveRenovationsArray[i])
                        i += 1
                    }
                    arrays.append(subarray)
                } else {
                    var subarray = [EditarRenovacion]()
                    for _ in i...approveRenovationsArray.count - 1 {
                        subarray.append(approveRenovationsArray[i])
                        i += 1
                    }
                    arrays.append(subarray)
                }
            }
        }
        */
        expectedResponses = arrays.count
        print("Expected Responses: \(expectedResponses)")
        return arrays
    }
    
}

extension AutorizarRenovacionesViewController : UIRenovacionTableViewCellDelegate {
    func showRenovationTrack(object: UIRenovacionTableViewCell) {
        let indexPathOfSelectedByTapOnCheck = self.tableView.indexPath(for: object)
        if let secureIndexPath =  indexPathOfSelectedByTapOnCheck{
            if self.searchIsActive {
                let renovationByIndexPathOnSearch = self.renovationsFilteredBySearch[secureIndexPath.row]
                self.selectedRenovation = renovationByIndexPathOnSearch
            } else {
                let renovationByIndexPath = self.renovations[secureIndexPath.row]
                self.selectedRenovation = renovationByIndexPath
            }
            UserAlerts.showTrackingsAlert(on: self, for: selectedRenovation!)
        }
    }

}


// MARK: - EXTENSION UIObservationInputAlertViewController
extension AutorizarRenovacionesViewController :  UIApproveRenovationAlertViewControllerDelegate {
    func authorizeAction() {
        var request = [AprobarRenovacion]()
        if let renovations = self.prepareRenovationsForRequest() {
            request = renovations
        }
        
        if request.count > 0 {
            let arrays = self.divideArray(approveRenovationsArray: request)
            self.showSpinner(onView: self.view)
            for array in arrays {
                var autorizacionbean = "ios-"
                if let uuid = appDelegate.UUID {
                    autorizacionbean += uuid + "|"
                }
                
                if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
                    autorizacionbean += "\(latitude)|\(longitude)"
                }
                RenovacionWorker.approveRenovation(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: array) { (onSuccessResponse) in
                    self.approveRenovationResponseList.append(onSuccessResponse)
                    self.currentResponses += 1
                    self.percentage.completePercentage = (self.currentResponses/self.expectedResponses) * 100
                    if let exito = onSuccessResponse.httpBody.exito {
                        if exito == false {
                            let errorMessage =  onSuccessResponse.httpBody.mensaje ?? "No hay detalle."
                            DispatchQueue.main.async {
                                self.removeSpinner()
                                self.alerts.showToastAlert(vc: self, message: errorMessage)
                                self.retrieveRenovations()
                            }
                            
                        } else {
                            if self.currentResponses == self.expectedResponses {
                                DispatchQueue.main.async {
                                    self.removeSpinner()
                                    self.alerts.showToastAlert(vc: self, message: "Se autorizó correctamente")
                                    self.retrieveRenovations()
                                }
                                self.currentResponses = 0
                                self.expectedResponses = 0
                            }
                        }
                    }
                    
                } onFailed: { (onFailedResponse) in
                    
                    DispatchQueue.main.async {
                        self.removeSpinner()
                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                        self.retrieveRenovations()
                    }
                    
                    
                } onAuthenticationError: { (onFailedResponse) in
                    self.showExpiredSessionAlert(on: self)
                }
            }
            //self.callApproveService(with: request)
            self.selectedRenovation = nil
        }
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
        
    }
}

extension AutorizarRenovacionesViewController: UIAsignarPeriodoAlertViewControllerDelegate {
    
    func aceptarAction(codTipoRenov: String, numPeriRenov: Int, obsRenovacion: String) {
        var parameters : [EditarRenovacion]?
        parameters = prepareRenovationsForEditing(codTipoRenov: codTipoRenov, numPeriRenov: numPeriRenov, obsRenovacion: obsRenovacion)
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        self.showSpinner(onView: self.view)
        
        if let parameters = parameters {
            let arrays = self.divideArrayForEditing(approveRenovationsArray: parameters)
            for array in arrays {
                RenovacionWorker.updateRenovationPeriod(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: array) { (onSuccessResponse) in
                    self.editRenovationResponseList.append(onSuccessResponse)
                    self.currentResponses += 1

                    self.percentage.completePercentage = (self.editRenovationResponseList.count/self.expectedResponses)*100
                    
                    if onSuccessResponse.httpBody.exito == true {
                        if self.currentResponses == self.expectedResponses {
                            DispatchQueue.main.async {
                                self.removeSpinner()
                                self.alerts.showToastAlert(vc: self, message: "Se registró con éxito")
                                self.retrieveRenovations()
                            }
                            self.currentResponses = 0
                            self.expectedResponses = 0
                        }
                    } else {
                        if self.currentResponses == self.expectedResponses {
                            DispatchQueue.main.async {
                                self.removeSpinner()
                                if let mensaje = onSuccessResponse.httpBody.mensaje {
                                    self.alerts.showToastAlert(vc: self, message: mensaje)
                                }
                                self.retrieveRenovations()
                            }
                            self.currentResponses = 0
                            self.expectedResponses = 0
                        }
                    }
                } onFailed: { (onFailed) in
                    DispatchQueue.main.async {
                        self.removeSpinner()
                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                        self.retrieveRenovations()
                        
                    }
                    
                } onAuthenticationError: { (onFailedResponse) in
                    //
                }
            }
            
            
        }
        
    }
    
    
}

// MARK: - EXTENSION DetalleSolicitud
extension AutorizarRenovacionesViewController : DetalleSolicitudViewControllerDelegate {
    
    func applicationApprovedOrRejected() {
        self.retrieveRenovations()
    }
}

// MARK: - EXTENSION UIActionResultAlert
extension AutorizarRenovacionesViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        //self.retrieveRenovations()
    }
}



