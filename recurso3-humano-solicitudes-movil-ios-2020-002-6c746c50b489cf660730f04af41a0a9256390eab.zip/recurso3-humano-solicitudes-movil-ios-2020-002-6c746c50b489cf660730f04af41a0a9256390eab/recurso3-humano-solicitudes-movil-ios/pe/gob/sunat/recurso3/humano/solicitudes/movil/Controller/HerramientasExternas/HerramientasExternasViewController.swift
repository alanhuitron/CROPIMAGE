//
//  HerramientasExternasViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/6/20.
//

import UIKit
import WebKit

class HerramientasExternasViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var webKitView: WKWebView!
    
    var externalToolURL : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let safeURLString = externalToolURL {
            let url = URL(string: safeURLString)!
            webKitView.load(URLRequest(url: url))
        }
        
        self.setHeaderView(headerNavigationBarView, viewController: self, title:  "", leftImage: "iconLeft", rightImage: "", rightImage2: "", useSearchBar: true)
        
    }
    
}

// MARK: - EXTENSION HeaderView
extension HerramientasExternasViewController: HeaderViewDelegate{

    func actionLeft() {
        self.goBackMore()
    }
    
}
