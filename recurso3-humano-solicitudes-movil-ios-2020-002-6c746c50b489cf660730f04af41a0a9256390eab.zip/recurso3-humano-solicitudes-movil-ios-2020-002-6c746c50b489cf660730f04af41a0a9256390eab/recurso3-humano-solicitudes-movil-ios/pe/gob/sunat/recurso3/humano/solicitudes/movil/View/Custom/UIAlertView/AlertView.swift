//
//  AlertView.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/8/19.
//
import Foundation
import UIKit

class AlertView: UIView {
    
    static let instance = AlertView()


    @IBOutlet weak var parentView: UIView!
    
    @IBOutlet weak var alertViewParam: UIView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    class func instanceFromNib() -> UIView {
              return UINib(nibName: "AlertView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    func showAlert() {
         
        
       /// UIApplication.shared.keyWindow?.addSubview(self.self)
    }
    
    
    override init(frame: CGRect) {
         super.init(frame: frame)
      
        ///checkTotal.borderStyle = .roundedSquare(radius: 80)
     }
    
     required init?(coder aDecoder: NSCoder) {
         super.init(coder: aDecoder)
        alertViewParam.layer.cornerRadius = 10
        //
        parentView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
           parentView.autoresizingMask = [.flexibleHeight, .flexibleWidth]

     }

}
