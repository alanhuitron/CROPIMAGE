//
//  OptionCollectionViewCell.swift
//  test-rh
//
//  Created by MOJAVE on 10/31/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import UIKit

class UIOptionCollectionViewCell: UICollectionViewCell {

    static let NAME = "UIOptionCollectionViewCell"
    
    @IBOutlet weak var view: UIView!
    @IBOutlet weak var imgOption: UIImageView!
    @IBOutlet weak var lblTitleOption: UILabel!
    @IBOutlet weak var lblDescOption: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }
    
    func setupContent(title : String, description : String , image : String){
        self.lblTitleOption.text = title
        self.lblDescOption.text = description
        self.imgOption.image = UIImage(named: image)
        
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOpacity = 0.3
        view.layer.shadowOffset = .zero
        //viewContenido.layer.shadowRadius = 8
        view.layer.cornerRadius = 8
        // view.layer.shadowPath = UIBezierPath(rect: view.bounds).cgPath
        view.layer.shouldRasterize = true
        view.layer.rasterizationScale = UIScreen.main.scale
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
}
