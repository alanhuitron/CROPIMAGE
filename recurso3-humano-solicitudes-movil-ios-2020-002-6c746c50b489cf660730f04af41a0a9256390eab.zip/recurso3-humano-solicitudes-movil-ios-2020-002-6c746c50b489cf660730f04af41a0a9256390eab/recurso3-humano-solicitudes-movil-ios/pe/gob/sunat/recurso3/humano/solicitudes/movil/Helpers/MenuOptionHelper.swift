//
//  MenuOption.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/8/19.
//

import Foundation

class MenuOption : Equatable, ExpressibleByStringLiteral {
    
    var key : String
    var value : String
    
    static func == (lhs: MenuOption, rhs: MenuOption) -> Bool {
        return (lhs.key == rhs.key)
    }
    
    public required init(stringLiteral value: String) {
        let components = value.components(separatedBy: ",")
        if components.count == 2 {
            self.key = components[0]
            self.value = components[1]
        }else{
            self.key = ""
            self.value = ""
        }
    }
    
    public required convenience init(unicodeScalarLiteral value: String) {
        self.init(stringLiteral: value)
    }
    public required convenience init(extendedGraphemeClusterLiteral value: String) {
        self.init(stringLiteral: value)
    }
}

enum MenuOptionEnum : MenuOption {
    case applicationsAndAuthorizations = "01,segueApplicationsAndAuthorizations"
    case electronicTickets = "02,segueElectronicTickets"
    case attendanceRecord = "03,segueAttendanceRecord"
    case externalTools = "06,segueExternalTools"
    case renovations = "07,segueRenovations"
}
