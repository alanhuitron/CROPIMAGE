//
//  UUOO.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/28/20.
//

import Foundation

struct UUOO: Decodable {
    var t12codUorga: String?
    var t12codJefat: String?
    var t12codEncar: String?
    var t12desUorga: String?
}
