//
//  ViewController.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/21/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func updateUserInterface() {
        switch Network.reachability.status {
        case .unreachable:
            let alert = UIAlertController(title: "Ups!", message: "No tienes conexión a internet", preferredStyle: .alert)
            let action = UIAlertAction(title: "Aceptar", style: .default) { (action) -> Void in
                self.navigationController?.popToRootViewController(animated: true)
            }
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
        case .wwan, .wifi:
            break
        }

    }
    
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
    @objc func statusManager(_ notification: Notification) {
        updateUserInterface()
    }
    @objc func istatusManager(_ notification: Notification) {
        updateUserInterface()
    }
    
    func canPerformSegue(withIdentifier identifier: String) -> Bool {
        //first fetch segue templates set in storyboard.
        guard let identifiers = value(forKey: "storyboardSegueTemplates") as? [NSObject] else {
           //if cannot fetch, return false
            return false
        }
        //check every object in segue templates, if it has a value for key _identifier equals your identifier.
        let canPerform = identifiers.contains { (object) -> Bool in
            if let id = object.value(forKey: "_identifier") as? String {
                if id == identifier{
                    return true
                } else {
                    return false
                }
            } else {
              return false
            }
        }
        return canPerform
    }
}

