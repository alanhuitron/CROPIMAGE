//
//  BotonBarView.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/7/19.
//

import UIKit
@objc protocol BotonBarViewDelegate {
    
    @objc optional func actionCheckBox()
    @objc optional func actionRechazar()
    @objc optional func actionAprobar()
}
class BotonBarView: UIView {

    ///@IBOutlet  var cbCheck: UICheckboxControl!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet weak var checkTotal: UICheckboxControl!
    
    @IBOutlet weak var labelTotal: UILabel!
   
    @IBOutlet weak var objectButtonRechaza: UIButton!
    
    @IBOutlet weak var objectButtonAcepta: UIButton!
    
    public var delegate: BotonBarViewDelegate!
    

    
    struct VALUES {
        static let NIBNAME = "BotonBarView"
        static let TOTALSELEC : String  = "Total Seleccionados ({variable})"
         static let SELECCIONA : String  = "Seleccionar Todo"
    }
    override func awakeFromNib() {
                checkTotal.style = .tick
        checkTotal.borderStyle = .square
        checkTotal.backgroundColor = UIColor.white
           // cbCheck.style = .tick
           /// cbCheck.borderStyle = .roundedSquare(radius: 12)
       
    }
    class func instanceFromNib() -> UIView {
              return UINib(nibName: VALUES.NIBNAME, bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    
    public func   getChecked() -> Bool{
        return checkTotal.isChecked
    }
    
    public func mostrarBotonAction () {
        self.objectButtonAcepta.isHidden = false
        self.objectButtonRechaza.isHidden = false
    }
    
    public func mostrarRenovationEvaluationBotonAction() {
        self.objectButtonAcepta.isHidden = true
        self.objectButtonRechaza.isHidden = false
    }

    public func mostrarRenovationAuthorizationBotonAction() {
        self.objectButtonAcepta.isHidden = true
        self.objectButtonRechaza.isHidden = false
    }
    
    
    public func ocultarBotonAction () {
        self.objectButtonAcepta.isHidden = true
        self.objectButtonRechaza.isHidden = true
    }
    
    public func setLabelSelectTodo(){
        labelTotal.text = VALUES.SELECCIONA
     }
    
    public func setLabelTotal(totalFila : String){
        labelTotal.text = VALUES.TOTALSELEC.replacingOccurrences(of: "{variable}", with: totalFila)
       }
    
    @IBAction func checkTotalSelect(_ sender: UICheckboxControl) {
        delegate.actionCheckBox?()
    }
    
    
    @IBAction func btnRechazar(_ sender: UIButton) {
            delegate.actionRechazar?()
        
    }

    
    @IBAction func btnAceptar(_ sender: UIButton) {
        delegate.actionAprobar?()
    }
    
    
    override init(frame: CGRect) {
         super.init(frame: frame)
      
        ///checkTotal.borderStyle = .roundedSquare(radius: 80)
     }
    
     required init?(coder aDecoder: NSCoder) {
         super.init(coder: aDecoder)

     }

}
