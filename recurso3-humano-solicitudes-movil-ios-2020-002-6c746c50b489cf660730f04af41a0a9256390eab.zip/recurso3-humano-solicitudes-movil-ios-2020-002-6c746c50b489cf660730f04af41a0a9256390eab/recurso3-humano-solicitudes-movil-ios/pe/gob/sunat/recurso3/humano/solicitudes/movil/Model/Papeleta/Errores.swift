//
//  Errores.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/18/19.
//

import Foundation

struct Errores:Codable {

    var cod : String?
    var msg : String?
}
