//
//  Papeleta.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation
struct Papeleta: Codable {
    
    var codPersona:String?
    var codPeriodo:String?
    var codUnidad:String?
    var nomPersona:String?
    var desPapeleta:String?
    var fecIngreso:String?
    var horIngreso:String?
    var fecSalida:String?
    var horSalida:String?
    var desObservacion:String?
    var fecPapeleta:String?
    
    //mensaje de ERROR
     var cod:String?
     var msg:String?
    
    
    
}
