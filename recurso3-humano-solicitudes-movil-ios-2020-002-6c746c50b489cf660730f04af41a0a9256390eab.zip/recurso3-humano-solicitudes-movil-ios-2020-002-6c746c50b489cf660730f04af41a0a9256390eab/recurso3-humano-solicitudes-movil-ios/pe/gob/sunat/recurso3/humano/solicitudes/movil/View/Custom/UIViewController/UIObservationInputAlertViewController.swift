//
//  UIObservationInputAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/14/19.
//

import UIKit

@objc protocol UIObservationInputAlertViewControllerDelegate{
    
    @objc func observationWasAdded(observation : String)
    @objc optional func observationInputEventWasCancelled()
}

class UIObservationInputAlertViewController: ParentViewController {

    @IBOutlet weak var txtvObservation: UITextView!
    @IBOutlet weak var viewParent: BorderView!
    
    var observation : String?
    var delegate : UIObservationInputAlertViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.viewParent.layer.cornerRadius = 30
        self.txtvObservation.delegate = self
        self.txtvObservation.textColor = UIColor.lightGray
    }
    
    @IBAction func acceptObservation(_ sender: Any) {
        self.txtvObservation.resignFirstResponder()
        guard let validObservation = observation, !validObservation.isEmpty else {
            UserAlerts.showAlertMessage(on: self, message: "Debe ingregar una observación")
            return
        }
        self.delegate?.observationWasAdded(observation: validObservation)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func cancel(_ sender: Any) {
        self.delegate?.observationInputEventWasCancelled?()
        self.dismiss(animated: true, completion: nil)
    }
}

extension UIObservationInputAlertViewController : UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Ingrese su observación"
            textView.textColor = UIColor.lightGray
        }
        self.observation = txtvObservation.text
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
        }
        
        return true
   }
}
