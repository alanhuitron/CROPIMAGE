//
//  AuthorizationTokenBody.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/22/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct AuthorizationTokenBody : Codable {
    
    var userdata : AuthorizationUserData?
    // iss
    var issuer: String?
    // sub
    var subject: String?
    // aud
    var audience: String?
    // exp
    var expiration: Int?
    // nbf
    var notBefore: Int?
    // iat
    var issueAt: Int?
    // jti
    var jwtId: String?

    enum JWTPayloadKeys: String {
        case issuer = "iss"
        case subject = "sub"
        case audience = "aud"
        case expiration = "exp"
        case notBefore = "nbf"
        case issueAt = "iat"
        case jwtId = "jti"
    }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: DynamicKey.self)
        issuer = try container.decodeIfPresent(String.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.issuer.rawValue))
        subject = try container.decodeIfPresent(String.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.subject.rawValue))
        audience = try container.decodeIfPresent(String.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.audience.rawValue))
        expiration = try container.decodeIfPresent(Int.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.expiration.rawValue))
        notBefore = try container.decodeIfPresent(Int.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.notBefore.rawValue))
        issueAt = try container.decodeIfPresent(Int.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.issueAt.rawValue))
        jwtId = try container.decodeIfPresent(String.self, forKey: DynamicKey(stringValue: JWTPayloadKeys.jwtId.rawValue))
        userdata = try container.decodeIfPresent(AuthorizationUserData.self, forKey: DynamicKey(stringValue: "userdata"))
    }
    
    //private enum CodingKeys: String, CodingKey { case userdata }
    public func checkNotBefore(allowNil: Bool) throws {
        try validateDate(key: DynamicKey.init(stringValue: JWTPayloadKeys.notBefore.rawValue), rightCompareResult: .orderedAscending, allowNil: allowNil)
    }

    public func checkExpiration(allowNil: Bool) throws {
        try validateDate(key: DynamicKey.init(stringValue: JWTPayloadKeys.expiration.rawValue), rightCompareResult: .orderedDescending, allowNil: allowNil)
    }

    public func checkIssueAt(allowNil: Bool) throws {
        try validateDate(key: DynamicKey.init(stringValue: JWTPayloadKeys.issueAt.rawValue), rightCompareResult: .orderedAscending, allowNil: allowNil)
    }
    
    private func validateDate(key: DynamicKey, rightCompareResult: ComparisonResult, allowNil: Bool) throws {

        var error: InvalidTokenError
        var value: Int?

        switch key.stringValue {
        case "nbf":
            value = notBefore
            error = InvalidTokenError.invalidNotBefore("\(notBefore ?? 0)")
        case "iat":
            value = issueAt
            error = InvalidTokenError.invalidIssuedAt("\(issueAt ?? 0)")
        case "exp":
            value = expiration
            error = InvalidTokenError.expiredToken("\(expiration ?? 0)")
        default:
            throw InvalidTokenError.invalidOrMissingArgument(key.stringValue)
        }

        if value == nil {
            if allowNil {
                return
            } else {
                throw InvalidTokenError.invalidOrMissingArgument(key.stringValue)
            }
        }

        let date = Date(timeIntervalSince1970: Double(value!))
        if date.compare(Date()) != rightCompareResult {
            throw error
        }
    }
}
