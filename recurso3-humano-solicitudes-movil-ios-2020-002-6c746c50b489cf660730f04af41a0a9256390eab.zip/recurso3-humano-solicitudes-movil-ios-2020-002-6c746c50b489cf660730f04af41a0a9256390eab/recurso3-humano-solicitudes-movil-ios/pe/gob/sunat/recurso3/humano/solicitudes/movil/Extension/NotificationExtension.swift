//
//  NotificationExtension.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/25/19.
//

import Foundation

extension Notification.Name {
    
    static let onMenuOptionCellSelected = Notification.Name("onMenuOptionCellSelected")
    
}
