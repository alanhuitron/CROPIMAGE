//
//  GetPendingResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/4/19.
//

import Foundation
struct GetPendingResponseBody : Codable {
    
    var solicitudes : [Solicitud]?
    var solicitud : Solicitud?
    
}
