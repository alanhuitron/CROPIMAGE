//
//  UserAlerts.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class UserAlerts: NSObject {
    
    typealias acctionSheetCancelar = (()->Void)?
    
    class func mostrarActionSheetConVariosBotones(conTitulo titulo : String?, conMensaje mensaje : String, conNombreBotones arrayBotones : [String], conBotonCancelar botonCancelar : String, enController controller : UIViewController, conCompletionBotones completion : @escaping(_ btnIndex : Int) -> Void, conCompletionCancelar completionCancelar : (() -> ())?) {
        let alertaController = UIAlertController(title: titulo, message: mensaje, preferredStyle: .actionSheet)
        for tituloBoton in arrayBotones {
            let accionBtn = UIAlertAction(title: tituloBoton, style: .default, handler: { (action) in
                completion(arrayBotones.firstIndex(of: tituloBoton)!)
            })
            alertaController.addAction(accionBtn)
        }
        
        let accionBtn = UIAlertAction(title: botonCancelar, style: .cancel, handler: { (action) in
            if completionCancelar != nil {
                completionCancelar!()
            }
        })
        
        alertaController.addAction(accionBtn)
        controller.present(alertaController, animated: true, completion: nil)
    }
    
    
    class func mostrarAlertaConTitulo(titulo : String, conMensaje mensaje : String?, conNombreDeBotonCancelar cancelar : String, enControlador controller : UIViewController?, conCompletion completion : (() -> Void)?){
        let alertaController = UIAlertController(title: titulo, message: mensaje, preferredStyle: UIAlertController.Style.alert)
        let accionCancelar = UIAlertAction(title: cancelar, style: UIAlertAction.Style.cancel) { (action : UIAlertAction) in
            completion?()
        }
        
        alertaController.addAction(accionCancelar)
        if controller == nil {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController?.present(alertaController, animated: true, completion: nil)
        }else{
            controller!.present(alertaController, animated: true, completion: nil)
        }
    }
    
    
    class func mostrarAlertaConTitulo(titulo : String, conMensaje mensaje : String?, conNombreDeBotonCancelar cancelar : String, conNombreDeBotonAceptar aceptar : String, enControlador controller : UIViewController?, conCompletionCancelar completionCancelar : (() -> Void)?, conCompletionAceptar completionAceptar : (() -> Void)?){
        let alertaController = UIAlertController(title: titulo, message: mensaje, preferredStyle: UIAlertController.Style.alert)
        let accionCancelar = UIAlertAction(title: cancelar, style: .cancel) { (action : UIAlertAction) in
            completionCancelar?()
        }
        alertaController.addAction(accionCancelar)
        
        let accionAceptar = UIAlertAction(title: aceptar, style: .default) { (action : UIAlertAction) in
            completionAceptar?()
        }
        
        alertaController.addAction(accionAceptar)
        if controller == nil {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController?.present(alertaController, animated: true, completion: nil)
        }else{
            controller!.present(alertaController, animated: true, completion: nil)
        }
    }
    
    class func showAlertMessage(on viewController : UIViewController, message: String) {
        self.showAlertMessage(on : viewController, title: nil, message: message)
    }
    
    
    class func showAlertMessage(on viewController : UIViewController, title: String?, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            viewController.present(alert, animated: true, completion: nil)
        }
    }
    
    class func showAlertMessageAndLetTakeAction(on viewController : UIViewController, message: String, completion actionToExecute : ((_ stringParameter: String) -> Void)?, stringParameterForAction : String) {
        self.showAlertMessageAndLetTakeAction(on :viewController, title: nil, message: message, completion: actionToExecute, stringParameterForAction : stringParameterForAction)
    }
    
    class func showAlertMessageAndLetTakeAction(on viewController : UIViewController, title: String?, message: String, completion actionToExecute : ((_ stringParameter: String) -> Void)?, stringParameterForAction : String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default) { (action) -> Void in
                actionToExecute?(stringParameterForAction)
            })
            viewController.present(alert, animated: true, completion: nil)
        }
    }
    
    class func showAlertMessageForSecurityAppRequired(on viewController : UIViewController, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default){ (action) -> Void in
                UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
            })
            viewController.present(alert, animated: true, completion: nil)
        }
    }
    
    class func showAlertForUserToServiceAction(on viewController : UIViewController, message: String){
        self.showAlertForUserToServiceAction(on: viewController, title: AlertMessages.UserActions.DEFAULT_TITLE, message: message, configuration: nil)
    }
    
    class func showAlertForUserToServiceAction(on viewController : UIViewController, message: String, configuration : AlertConfiguration?){
        self.showAlertForUserToServiceAction(on: viewController, title: AlertMessages.UserActions.DEFAULT_TITLE, message: message, configuration: configuration)
    }
    
    class func showAlertForUserToServiceAction(on viewController : UIViewController, title: String, message: String, configuration : AlertConfiguration?){
        DispatchQueue.main.async {
            let alertController = UIActionResultAlertViewController(nibName: "UIActionResultAlertViewController", bundle: nil)
            alertController.alertTitle = title
            alertController.alertMessage = message
            alertController.configuration = configuration
            alertController.modalPresentationStyle = .overCurrentContext
            if viewController is UIActionResultAlertViewControllerDelegate{
                alertController.delegate = viewController as? UIActionResultAlertViewControllerDelegate
            }
            
            viewController.present(alertController, animated: false, completion: nil)
        }
    }
    
    class func showTrackingsAlert(on viewController: UIViewController, for renovation: Renovacion) {
        DispatchQueue.main.async {
            let observationController = UITrackingViewController(nibName: "UITrackingViewController", bundle: nil)
            observationController.modalPresentationStyle = .overCurrentContext
            observationController.parametersForRenovationDetail = renovation
            viewController.present(observationController, animated: false, completion: nil)
        }
    }
    
    class func showAlertForRenovationsEditing(on viewController: UIViewController, renovaciones : [Renovacion]) {
        DispatchQueue.main.async {
            let alertForRenovationsApproval = UIAsignarPeriodoAlertViewController(nibName: "UIAsignarPeriodoAlertViewController", bundle: nil)
            alertForRenovationsApproval.modalPresentationStyle = .overCurrentContext
            
            if viewController is UIAsignarPeriodoAlertViewControllerDelegate {
                alertForRenovationsApproval.delegate = viewController as? UIAsignarPeriodoAlertViewControllerDelegate
                alertForRenovationsApproval.renovaciones = renovaciones
            }
            
            viewController.present(alertForRenovationsApproval, animated: false, completion: nil)
        }
    }
    
    class func showAlertForRenovationsApproval(on viewController: UIViewController) {
        DispatchQueue.main.async {
            let alertForRenovationsApproval = UIApproveRenovationAlertViewController(nibName: "UIApproveRenovationAlertViewController", bundle: nil)
            alertForRenovationsApproval.modalPresentationStyle = .overCurrentContext
            
            if viewController is UIApproveRenovationAlertViewControllerDelegate {
                alertForRenovationsApproval.delegate = viewController as? UIApproveRenovationAlertViewControllerDelegate
            }
            
            viewController.present(alertForRenovationsApproval, animated: false, completion: nil)
        }
    }
    
    class func showAlertForRenovationDownload(on viewController: UIViewController, numPeriRenov: Int) {
        DispatchQueue.main.async {
            let alertForRenovationConfirmation = UIDescargarIntencionRenovacionViewController(nibName: "UIDescargarIntencionRenovacionViewController", bundle: nil)
            alertForRenovationConfirmation.modalPresentationStyle = .overCurrentContext
            
            if viewController is UIDescargarIntencionRenovacionAlertViewControllerDelegate {
                alertForRenovationConfirmation.delegate = viewController as? UIDescargarIntencionRenovacionAlertViewControllerDelegate
                alertForRenovationConfirmation.numPeriRenov = numPeriRenov
            }
            
            viewController.present(alertForRenovationConfirmation, animated: false, completion: nil)
        }
    }
    
    class func showAlertForRenovationConfirmation(on viewController: UIViewController, numPeriRenov: Int) {
        DispatchQueue.main.async {
            let alertForRenovationConfirmation = UIConfirmarRenovacionAlertViewController(nibName: "UIConfirmarRenovacionAlertViewController", bundle: nil)
            alertForRenovationConfirmation.modalPresentationStyle = .overCurrentContext
            
            if viewController is UIConfirmarRenovacionAlertViewControllerDelegate {
                alertForRenovationConfirmation.delegate = viewController as? UIConfirmarRenovacionAlertViewControllerDelegate
                alertForRenovationConfirmation.numPeriRenov = numPeriRenov
            }
            
            viewController.present(alertForRenovationConfirmation, animated: false, completion: nil)
        }
    }

    
    
    
    class func showAlertForUserObservation(on viewController : UIViewController){
        DispatchQueue.main.async {
            let observationController = UIObservationInputAlertViewController(nibName: "UIObservationInputAlertViewController", bundle: nil)
            observationController.modalPresentationStyle = .overCurrentContext
            
            if viewController is UIObservationInputAlertViewControllerDelegate {
                observationController.delegate = viewController as? UIObservationInputAlertViewControllerDelegate
            }
            
            viewController.present(observationController, animated: false, completion: nil)
        }
    }
    
    class func showAlertForUserToAcceptCancelAction(on viewController : UIViewController, title: String, message: String, acceptHandler: (() -> Void)?, cancelHandler: (() -> Void)?){
        DispatchQueue.main.async {
            let alertController = UIActionAcceptCancelAlertViewController(nibName: "UIActionAcceptCancelAlertViewController", bundle: nil)
            alertController.alertTitle = title
            alertController.alertMessage = message
            alertController.modalPresentationStyle = .overCurrentContext
            alertController.acceptAction = acceptHandler
            alertController.cancelAction = cancelHandler
            viewController.present(alertController, animated: false, completion: nil)
        }
    }
    
    class func showAlertSimpleAlertToUserAcceptCancelAction(on viewController : UIViewController, message: String, acceptHandler: (() -> Void)?, cancelHandler: (() -> Void)?, btnAcceptTitle : String = "Aceptar"){
        DispatchQueue.main.async {
            let alertController = UISimpleAcceptCancelAlertViewController(nibName: "UISimpleAcceptCancelAlertViewController", bundle: nil)
            alertController.alertMessage = message
            alertController.acceptButtonTitle = btnAcceptTitle
            alertController.modalPresentationStyle = .overCurrentContext
            alertController.acceptAction = acceptHandler
            alertController.cancelAction = cancelHandler
            viewController.present(alertController, animated: false, completion: nil)
        }
    }
    
}
