//
//  UIRenovacionTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import UIKit

@objc protocol UIRenovacionTableViewCellDelegate {
    @objc optional func showRenovationTrack(object: UIRenovacionTableViewCell)
    @objc optional func editRenovationPeriod(object: UIRenovacionTableViewCell)
}


class UIRenovacionTableViewCell: UITableViewCell {
    
    static let NAME = "UIRenovacionTableViewCell"
    static let IDENTIFIER = "UIRenovacionTableViewCell"

    
    @IBOutlet weak var codUOrgaAndDesUOrgaLabel: UILabel!
    @IBOutlet weak var codRegistroAndNombPersonaLabel: UILabel!
    @IBOutlet weak var desPeriodoAndTipContratoLabel: UILabel!
 
    @IBOutlet weak var UIRNSLabel: UILabel!
    @IBOutlet weak var situacionLabel: UILabel!
    var delegate : UIRenovacionTableViewCellDelegate?

    @IBOutlet weak var IconUIImageView: UIImageView!
    
    @IBOutlet weak var isSignedImageView: UIImageView!
    
    @IBOutlet weak var observartionImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        isSignedImageView.image = isSignedImageView.image?.withRenderingMode(.alwaysTemplate)
        isSignedImageView.tintColor = .black
        observartionImage.isHidden = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func handlePressOnShowTrack(sender: UITapGestureRecognizer){
        delegate?.showRenovationTrack?(object: self)
    }
    
    @objc func handlePressOnEditPeriod(sender: UITapGestureRecognizer){
        delegate?.editRenovationPeriod?(object: self)
    }
    
    
}
