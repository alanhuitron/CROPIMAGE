//
//  RenovationOptionEntity.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/18/20.
//

import Foundation

struct RenovationOptionEntity : Codable {
    
    var codOpcion : String?
    var nomOpcion : String?
    var desOpcion : String?
    var isEnabled : Bool?
    
    func isEnable() -> Bool{
        if let isEnabled = isEnabled {
            return isEnabled
        }
        return false
    }
    
    func getShortName() -> String{
        return String(self.nomOpcion?.split(separator: " ")[0] ?? "-")
    }
    
}
