//
//  UIAsignarPeriodoAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/29/20.
//

import UIKit

import UIKit

@objc protocol UIAsignarPeriodoAlertViewControllerDelegate {
    @objc func aceptarAction(codTipoRenov : String, numPeriRenov : Int, obsRenovacion: String)
}

class UIAsignarPeriodoAlertViewController: ParentViewController {


    @IBOutlet weak var renovationStatePickerText: UIPickerText!
    
    @IBOutlet weak var renovationPeriodPickerText: UIPickerText!
    
    @IBOutlet weak var observationTextView: UITextView!
    
    var delegate : UIAsignarPeriodoAlertViewControllerDelegate?
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var observationIsNecesaryLabel: UILabel!
    var renovationStateCode : String?
    var renovationPeriodCode: String?
    var renovationTypes : [CodeValueEntity]? = [CodeValueEntity]()
    var renovationPeriods : [CodeValueEntity]? = [CodeValueEntity]()
    var renovaciones : [Renovacion]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.contentView.layer.cornerRadius = 30
        self.renovationStatePickerText.customizeBorder(color: UIColor(named: "appColor")!, width: 2, cornerRadius: 3)
        self.renovationPeriodPickerText.customizeBorder(color: UIColor(named: "appColor")!, width: 2, cornerRadius: 3)
        observationIsNecesaryLabel.isHidden = true
        getPeriodoYTipoRenovacion()
        self.hideKeyboardWhenTappedAround()
        self.observationTextView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func asignartipoRenovacion() {
        if(self.renovationStateCode != "01" && self.renovationStateCode != nil){
            self.renovationPeriodPickerText.isEnabled = false
            self.renovationPeriodPickerText.backgroundColor = UIColor(named: "disabledPickerColor")
            self.renovationPeriodPickerText.text = ""
            self.renovationPeriodCode = "0"
        } else {
            self.renovationPeriodPickerText.isEnabled = true
            self.renovationPeriodPickerText.backgroundColor = UIColor.white
            //self.renovationPeriodCode = nil
        }
    }
    

    
    func getPeriodoYTipoRenovacion() {
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        
        RenovacionWorker.getRenovationCodes(with: appDelegate.authorizationToken, with: autorizacionbean) { (onSuccessResponse) in
            DispatchQueue.main.async {
                let renovationTypesArray = onSuccessResponse
                for renovationType in renovationTypesArray {
                    let codValue = CodeValueEntity(code: renovationType.t99codigo!, value: renovationType.t99descrip!)
                    self.renovationTypes!.append(codValue)
                }
                self.renovationStatePickerText.loadDropdown(data: self.renovationTypes!)
                self.renovationStatePickerText.customPicker.pickerViewDelegate = self
                if self.renovaciones?.count == 1 {
                    var item = 0
                    for renovationType in self.renovationTypes! {
                        if renovationType.value == self.renovaciones![0].estado {
                            self.renovationStateCode = renovationType.code
                            self.renovationStatePickerText.selectElementAt(index: item)
                            self.renovationStatePickerText.text = renovationType.value
                        }
                        item += 1
                    }
                    self.asignartipoRenovacion()
                } else if self.renovaciones!.count > 1 {
                    self.renovationStatePickerText.text = ""
                    self.renovationPeriodPickerText.text = ""
                    self.renovationPeriodPickerText.isEnabled = true
                    self.renovationPeriodPickerText.backgroundColor = UIColor.white
                    self.renovationStateCode = nil
                    self.renovationPeriodCode = nil
                }
                self.removeSpinner()
            }
        } onFailed: { (onFailed) in
            //
        } onAuthenticationError: { (onFailedResponse) in
            //
        }
        
        
        RenovacionWorker.getRenovationPeriods(with: appDelegate.authorizationToken, with: autorizacionbean) { (onSuccessResponse) in
            DispatchQueue.main.async {
                let renovationPeriodsArray = onSuccessResponse
                for renovationPeriod in renovationPeriodsArray {
                    let codValue = CodeValueEntity(code: String(renovationPeriod.numeroPeriodo!), value: renovationPeriod.nombrePeriodo!)
                    self.renovationPeriods!.append(codValue)
                }
                self.renovationPeriodPickerText.loadDropdown(data: self.renovationPeriods!)
                self.renovationPeriodPickerText.customPicker.pickerViewDelegate = self
                
                if self.renovaciones?.count == 1 {
                    var item = 0
                    for renovationPeriod in self.renovationPeriods! {
                        if renovationPeriod.value == self.renovaciones![0].desPeriodo {
                            self.renovationPeriodCode = renovationPeriod.code
                            self.renovationPeriodPickerText.selectElementAt(index: item)
                            self.renovationPeriodPickerText.text = renovationPeriod.value
                        }
                        item += 1
                    }
                    self.asignartipoRenovacion()
                } else if self.renovaciones!.count > 1 {
                    self.renovationStatePickerText.text = ""
                    self.renovationPeriodPickerText.text = ""
                    self.renovationPeriodPickerText.isEnabled = true
                    self.renovationPeriodPickerText.backgroundColor = UIColor.white
                    self.renovationStateCode = nil
                    self.renovationPeriodCode = nil
                }
                self.asignartipoRenovacion()
                self.removeSpinner()
            }
        } onFailed: { (onFailed) in
            //
        } onAuthenticationError: { (onFailedResponse) in
            //
        }

    }

    @IBAction func confirmarButtonAction(_ sender: Any) {
        if renovationStateCode != "01" && observationTextView.text == "" {
            self.observationIsNecesaryLabel.isHidden = false
        } else {
            if let codTipoRenov = self.renovationStateCode, let renovationPeriodCode = self.renovationPeriodCode, let obsRenovacion = self.observationTextView.text {
                self.delegate?.aceptarAction(codTipoRenov: codTipoRenov, numPeriRenov: Int(renovationPeriodCode)!, obsRenovacion: obsRenovacion)
                self.dismiss(animated: false, completion: nil)
            } else {
                self.observationIsNecesaryLabel.isHidden = false
                self.observationIsNecesaryLabel.text = "* Necesita asignar un periodo"
            }

        }
    }
    
    @IBAction func cancelarButtonAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIAsignarPeriodoAlertViewController : PickerViewDelegate {
    func pickerViewDidSelectRow(_ pickerView: UIPickerView) {
        switch pickerView {
        case self.renovationStatePickerText.customPicker:
            self.renovationStateCode = renovationStatePickerText.customPicker.currentRow.code
            if(self.renovationStateCode != "01"){
                self.renovationPeriodPickerText.isEnabled = false
                self.renovationPeriodPickerText.backgroundColor = UIColor(named: "disabledPickerColor")
                self.renovationPeriodPickerText.text = ""
                self.renovationPeriodCode = "0"
            } else {
                self.renovationPeriodPickerText.isEnabled = true
                self.renovationPeriodPickerText.backgroundColor = UIColor.white
                if let _ = self.renovationPeriodCode {
                    
                } else {
                    self.renovationPeriodCode = nil
                }
            }
        case self.renovationPeriodPickerText.customPicker:
            self.renovationPeriodCode = renovationPeriodPickerText.customPicker.currentRow.code
        default:
            break
        }
    }
}

extension UIAsignarPeriodoAlertViewController : UITextFieldDelegate {
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case renovationPeriodPickerText:
            //criterionData = nil
        break
        case renovationStatePickerText:
            //cr
        break
        default:
            break
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case renovationPeriodPickerText:
            //self.UUOO = textField.text
        break
        case renovationStatePickerText:
            break
        default:
            break
        }
    }
}

extension UIAsignarPeriodoAlertViewController : UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let ACCEPTABLE_CHARACTERS = "[abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789,.;=%!¿?áéíóúÁÉÍÓÚ ]*"
        
        let cs = NSCharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
        let filtered = text.components(separatedBy: cs).joined(separator: "")
        
        return (text == filtered)
        
        
    }
}
