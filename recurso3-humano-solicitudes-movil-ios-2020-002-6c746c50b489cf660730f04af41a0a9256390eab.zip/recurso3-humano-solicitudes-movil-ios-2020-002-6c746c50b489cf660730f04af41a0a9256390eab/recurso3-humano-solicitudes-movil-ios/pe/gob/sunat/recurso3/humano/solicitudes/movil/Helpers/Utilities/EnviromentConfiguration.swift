//
//  EnviromentConfiguration.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/16/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct EnviromentConfiguration{
    
    static let CONFIGURATION_VALUES : [String: Any] = ConfigurationFileReader.read("ConfigurationValues")!
    
    static let KEYCHAIN_APPSKEY = (CONFIGURATION_VALUES ["KeyChainAppsKey"] as? String)!
    static let YAMMER_URL_SCHEME = (CONFIGURATION_VALUES ["YammerUrlScheme"] as? String)!
    static let YAMMER_APP_STORE_DEEP_LINK = (CONFIGURATION_VALUES ["YammerAppStoreDeepLink"] as? String)!
    
    static let AUTHORIZATION_SERVICES_VALUES = (CONFIGURATION_VALUES ["AuthorizationServicesValues"] as? [String : Any])!
    static let AUTHORIZATION_DOMAIN = (AUTHORIZATION_SERVICES_VALUES["Domain"] as? String)!
    static let AUTHORIZATION_TIMEOUT = Int((AUTHORIZATION_SERVICES_VALUES["Timeout"] as? String)!)!
    static let AUTHORIZATION_CLIENT_ID = (AUTHORIZATION_SERVICES_VALUES["Client_Id"] as? String)!
    static let AUTHORIZATION_CLIENT_SECRET = (AUTHORIZATION_SERVICES_VALUES["Client_Secret"] as? String)!
    
    static let RECURSOS_HUMANOS_SERVICES_VALUES = (CONFIGURATION_VALUES ["RecursosHumanosServicesValues"] as? [String : Any])!
    static let RECURSOS_HUMANOS_DOMAIN = (RECURSOS_HUMANOS_SERVICES_VALUES["Domain"] as? String)!
    static let RECURSOS_HUMANOS_TIMEOUT = Int((RECURSOS_HUMANOS_SERVICES_VALUES["Timeout"] as? String)!)!
    
}
