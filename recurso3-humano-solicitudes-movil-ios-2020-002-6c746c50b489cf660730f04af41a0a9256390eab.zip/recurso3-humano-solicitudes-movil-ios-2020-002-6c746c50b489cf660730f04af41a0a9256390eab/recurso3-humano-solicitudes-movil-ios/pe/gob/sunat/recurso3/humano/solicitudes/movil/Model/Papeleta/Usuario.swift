//
//  Usuario.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import Foundation
struct Usuario: Codable {
    
    var login:String?
    var nroRegistro:String?

    
    
}
