//
//  PostMasivaPapeletaResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/15/19.
//

import Foundation

struct PostMasivaPapeletaResponseBody:Codable {

    var papeletaResponse : MasivaPapeleta?

}
