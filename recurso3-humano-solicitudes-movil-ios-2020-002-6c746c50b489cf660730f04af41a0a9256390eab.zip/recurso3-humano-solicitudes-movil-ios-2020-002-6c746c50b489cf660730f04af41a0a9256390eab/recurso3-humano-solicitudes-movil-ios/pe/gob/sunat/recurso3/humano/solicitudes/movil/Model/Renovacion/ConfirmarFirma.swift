//
//  ConfirmarFirma.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/27/20.
//

import Foundation

struct ConfirmarFirma : Codable {
    var numIntencion: String?
    var codTiporenov : String?
    var login: String?
    var clave: String?
}
