//
//  RegistroPapeletaMasivaRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import Foundation
struct RegistroPapeletaMasivaRequest:Codable {
    var usuario: Usuario?
    var papeletas: [Papeleta]?
    var ubicacion : Ubicacion?

}
