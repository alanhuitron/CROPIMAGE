//
//  RechazoSolicitudResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 12/3/19.
//

import Foundation

struct RechazoSolicitudResponseBody : Codable {
    
    var errores : [Errores]?
    
}

