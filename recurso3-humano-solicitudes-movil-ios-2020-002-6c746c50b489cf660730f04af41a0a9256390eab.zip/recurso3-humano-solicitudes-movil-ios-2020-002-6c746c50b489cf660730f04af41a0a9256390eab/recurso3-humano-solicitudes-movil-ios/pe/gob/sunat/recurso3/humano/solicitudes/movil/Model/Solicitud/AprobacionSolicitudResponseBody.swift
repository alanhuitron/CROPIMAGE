//
//  AprobacionSolicitudResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 12/3/19.
//

import Foundation

struct AprobacionSolicitudResponseBody : Codable {
    
    var errores : [Errores]?
    
}
