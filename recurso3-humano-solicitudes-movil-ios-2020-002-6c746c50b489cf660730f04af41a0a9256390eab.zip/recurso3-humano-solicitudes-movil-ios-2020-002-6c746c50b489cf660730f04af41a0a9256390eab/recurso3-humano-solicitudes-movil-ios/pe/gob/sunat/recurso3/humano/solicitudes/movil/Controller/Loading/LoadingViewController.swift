//
//  LoadingDataViewController.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class LoadingViewController: ParentViewController {
    
    var authToken : String?
    var options = [OptionEntity]()
    let notificationCenter = NotificationCenter.default
    var esIntendente : Bool?
    var esResponsable : Bool?
    var renovacionOptions = [RenovationOptionEntity]()
    let userDefaults = UserDefaults.standard
    var UUID : String?
    var locationPermission : Bool = false
    
    // MARK: - LIFE CYCLE SECTION
    override func viewDidLoad() {
        print("print [DBG: \(#function)]: \(self)")
        super.viewDidLoad()
        UUID = userDefaults.string(forKey: "UUID")
        locationPermission = userDefaults.bool(forKey: "locationPermission")
        self.loadDataAndCallSegue()
        notificationCenter.addObserver(self, selector: #selector(LoadingViewController.loadDataAndCallSegue), name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("print [DBG: \(#function)]: \(self)")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        notificationCenter.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    @IBAction func unwindToMe(segue:UIStoryboardSegue) {
        
    }
    
    // MARK: - CONTROLLER SECTION
    func retrieveUserFromToken(with authToken : String){
        let jwtPayLoadString = authToken.split(separator: ".")
        let jsonPayload = self.decode(encodedString: String(jwtPayLoadString[1]))
        let jsonPayloadData = jsonPayload?.data(using: .utf8)
        let authTokenBody = JSONParser.decode(AuthorizationTokenBody.self, from: jsonPayloadData!)
        let userRoles = AuthorizationUserData.retrieveRoles(data: jsonPayloadData!)
        
        let user: UserEntity = UserEntity()
        user.name = authTokenBody!.userdata!.nombreCompleto
        user.email = authTokenBody!.userdata!.correo
        user.userName = authTokenBody!.userdata!.login
        user.registryNumber = authTokenBody!.userdata!.nroRegistro
        user.roles = userRoles
        appDelegate.currentUser = user
    }
    
    func decode(encodedString: String) -> String? {
        if let data = Data(base64Encoded: base64StringWithPadding(encodedString: encodedString)) {
            return String(data: data, encoding: .utf8)
        }
        return nil
    }
    
    public func base64StringWithPadding(encodedString: String) -> String {
        var stringTobeEncoded = encodedString.replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let paddingCount = encodedString.count % 4
        for _ in 0..<paddingCount {
            stringTobeEncoded += "="
        }
        return stringTobeEncoded
    }
    func retrieveMenuOptions(){
        MenuOpcionesWorker.getOptions(with: self.authToken!, forUser : self.appDelegate.currentUser.registryNumber, onSuccess: { (onSuccessResponse) in
            DispatchQueue.main.async {
                print("Se ha recuperado las opciones del menu para el usuario")
                self.options = onSuccessResponse.httpBody.options!
                self.appDelegate.menuOptions = self.options
                if let UUID = self.UUID {
                    self.appDelegate.UUID = UUID
                    if self.locationPermission {
                        self.performSegue(withIdentifier: AppConstants.SEGUE.SIDE_MENU, sender: self)
                    }
                } else {
                    self.performSegue(withIdentifier: AppConstants.SEGUE.ONBOARDING, sender: self)
                }
            }
        }, onFailed: {(onFailed) in
            UserAlerts.showAlertMessageAndLetTakeAction(on: self, title: "Error al configurar la app", message: "No se pudo recuperar los programas para el usuario", completion: RelativeAppsHelper.openRelativeApp, stringParameterForAction: AppDelegate.actionCloseSession)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHENTICATION_TOKEN_KEY)
            
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
        
        
    }
    
    func retrieveRenovationMenuOptions(){
        RenovacionMenuOpcionesWorker.getEsIntendente(with: self.authToken!, forUser: self.appDelegate.currentUser.registryNumber) { (onSuccessResponse) in
            DispatchQueue.main.async {
                print("Se ha recuperado si el usuario es intendente")
                self.esIntendente = onSuccessResponse.httpBody.response
                self.appDelegate.esIntendente = self.esIntendente!
            }
        } onFailed: { (onFailed) in
            UserAlerts.showAlertMessageAndLetTakeAction(on: self, title: "Error al configurar la app", message: "No se pudo verificar si el usuario es intendente", completion: RelativeAppsHelper.openRelativeApp, stringParameterForAction: AppDelegate.actionCloseSession)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHENTICATION_TOKEN_KEY)
        } onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        }
        
        RenovacionMenuOpcionesWorker.getEsResponsable(with: self.authToken!, forUser: self.appDelegate.currentUser.registryNumber) { (onSuccessResponse) in
            DispatchQueue.main.async {
                print("Se ha recuperado si el usuario es responsable")
                self.esResponsable = onSuccessResponse.httpBody.response
                self.appDelegate.esResponsable = self.esResponsable!
            }
        } onFailed: { (onFailed) in
            UserAlerts.showAlertMessageAndLetTakeAction(on: self, title: "Error al configurar la app", message: "No se pudo verificar si el usuario es responsable", completion: RelativeAppsHelper.openRelativeApp, stringParameterForAction: AppDelegate.actionCloseSession)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
            KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHENTICATION_TOKEN_KEY)
        } onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        }
    }
    

    
    @objc func loadDataAndCallSegue(){
        self.authToken = AppInteractorHelper.searchForAuthorizationToken(executeIfTokenNil: RelativeAppsHelper.openSecurityAppIfPosible, on: self)
        
        if self.authToken != nil && !self.authToken!.isEmpty {
            print("El token no es nulo. Iniciando llamado al servidor para la recuperacion de la configuracion del usuario")
            print(self.authToken)
            self.appDelegate.authorizationToken = self.authToken!
            self.retrieveUserFromToken(with: self.authToken!)
            self.retrieveRenovationMenuOptions()
            self.retrieveMenuOptions()
        }
    }
}
