//
//  SeguimientoRenovacionResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import Foundation
struct SeguimientoRenovacionResponse:Codable {

   var httpResponse = BaseResponse()
    var httpBody = GetRenovationTrackingResponseBody()
}
