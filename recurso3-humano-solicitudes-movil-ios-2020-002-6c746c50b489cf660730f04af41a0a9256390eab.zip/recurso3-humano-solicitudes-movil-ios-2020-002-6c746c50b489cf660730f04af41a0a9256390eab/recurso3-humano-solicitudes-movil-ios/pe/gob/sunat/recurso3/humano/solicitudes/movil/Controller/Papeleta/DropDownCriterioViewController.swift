//
//  DropDownCriterioViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import UIKit
import Foundation
@objc protocol DropDownCriterioViewDelegate {
    
    @objc optional func cerrarVentana()
}
class DropDownCriterioViewController: ParentViewController {
    private let reuseIdentifier = "criterioCell"
    @IBOutlet weak var tablecriterioList: UITableView!
    
    @IBOutlet weak var viewDropDown: UIView!
    
      public var delegate: DropDownCriterioViewDelegate!
    var textoSeleccionado : String?
    
    var listaCriterio = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
         viewDropDown.layer.shadowColor = UIColor.gray.cgColor

           viewDropDown.layer.shadowOpacity = 0.3

           viewDropDown.layer.shadowOffset = .zero

            ///viewContenido.layer.shadowRadius = 8

           viewDropDown.layer.cornerRadius = 10

          ///// view.layer.shadowPath = UIBezierPath(rect: view.bounds).cgPath

         viewDropDown.layer.shouldRasterize = true

              viewDropDown.layer.rasterizationScale = UIScreen.main.scale
        
            self.tablecriterioList.delegate = self
            self.tablecriterioList.dataSource = self
            self.tablecriterioList.translatesAutoresizingMaskIntoConstraints = false
            self.tablecriterioList.register(UINib(nibName: DropDownListViewCELLTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: reuseIdentifier)

      ///  self.tablecriterioList.separatorStyle = .none
        
        
        listaCriterio.append("Registro")
        listaCriterio.append("Unidad Organizacional")
        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension DropDownCriterioViewController:UITableViewDelegate,UITableViewDataSource{

    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return self.listaCriterio.count;
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

       
             
                let  cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier ,for: indexPath) as! DropDownListViewCELLTableViewCell
                   let data = self.listaCriterio[indexPath.row]
                    ///setupContent(nombrePersona : String, desPapeleta : String, fechaIngreso:String,horaIngreso:String,desObservacion:String  )

                    cell.setupContent(textCriterio: String(data))
        
        cell.layoutMargins = UIEdgeInsets.zero
        cell.preservesSuperviewLayoutMargins = false
        cell.textLabel?.textColor = UIColor(hexString: "#1976d2", alpha: 0.1)
        //UIColor(rgb: "1976d2")
                        //tableBandejaPapeleta.heightAnchor(equalToConstant: cell.heightAnchor).isActive = true
                 
       
        return cell

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //7    let cell = tableView.cellForRow(at: indexPath) as! BandejaIncidenciaTableViewCell
      
        
       /// let filtroPapeleta = self.storyboard?.instantiateViewController(withIdentifier: "filtroPapeleta") as! FiltroPapeletaaViewController
        //filtroPapeleta.setBotonCriterio( texto :self.listaCriterio[indexPath.row])
       /// self.dismiss(animated: true, completion: nil)
        textoSeleccionado = self.listaCriterio[indexPath.row]
        cerrarmodal()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 35
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
     func cerrarmodal (){
        
        delegate.cerrarVentana?()
        
    }
    
}
