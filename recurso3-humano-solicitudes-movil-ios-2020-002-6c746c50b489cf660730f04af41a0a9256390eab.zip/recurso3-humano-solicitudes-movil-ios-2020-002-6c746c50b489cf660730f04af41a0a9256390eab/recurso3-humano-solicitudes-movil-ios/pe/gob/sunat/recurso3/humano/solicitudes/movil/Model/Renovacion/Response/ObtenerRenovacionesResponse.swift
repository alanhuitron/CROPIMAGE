//
//  RenovacionesResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation

struct ObtenerRenovacionesResponse : Decodable {
    
    var httpResponse = BaseResponse()
    var httpBody = ObtenerRenovacionesResponseBody()
}
