//
//  AppConstants.swift
//  tecnologia3-arquitectura-ejemplo1-ios-clientessunat
//
//  Created by MOJAVE on 10/21/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct AppConstants {
    
    //PERMISSIONS
    static let OPTIONS_ONLY_ALLOWED_TO_SIRH_JEFE = ["01","02"]
    static let OPTIONS_WITH_STORYBOARD_PRESENTATION = ["01","02","03","07"]
    static let OPTIONS_WITH_ALERT_FROM_BOTTON_PRESENTATION = ["06"]
    
    struct MENU_POPUP{
        static let APROBAR_TITLE = "CONFIRMAR APROBACIÓN"
        static let APROBAR_BODY_MASIVO = "¿Estás seguro de que quieres aprobar estas papeletas?"
        static let APROBAR_BODY = "¿Estás seguro de que quieres aprobar esta papeleta?"
        static let APROBAR_BUTTON = "APROBAR"
       
        
        static let RECHAZAR_TITLE = "CONFIRMAR RECHAZO"
        static let RECHAZAR_BODY_MASIVO = "¿Estás seguro de que quieres rechazar estas papeletas?"
        static let RECHAZAR_BODY = "¿Estás seguro de que quieres rechazar esta papeleta?"
        static let RECHAZAR_BUTTON = "RECHAZAR"
        
        static let REGISTRAR_MARCACION_MESSAGE = "¿Estás seguro de que quieres registrar una marcación?"
        static let REGISTRAR_MARCACION_ACCEPT_TITLE = "Registrar"
    }
    
    struct MENU_OPTION_TITLE{
        static let MAIN_MENU = "Menu Principal"
        static let CLOSE_SESSION = "Cerrar Sesión"
    }
    
    struct VIEWCONTROLLER {
        static let MENU = "MenuVC"
        static let LOADING = "Loading"
        static let LOGIN = "LoginVC"
        static let SIDEBAR = "SideBarViewController"
        static let REVEAL = "RevealViewController"
        
        struct TITLE {
            static let MAIN = "Principal"
            static let PENDING_APPLICATION = "Solicitudes Pendientes"
            static let APPLICATION_DETAIL = "Detalle de Solicitud"
            static let TRACKING_DETAIL = "Detalle de Seguimiento"
            static let ATTENDANCE_RECORD = "Marcaciones"
            static let RENOVATION = "Menú Renovaciones"
            static let AUTHORIZE_RENOVATIONS = "Autorizar Renovaciones"
            static let RENOVATION_DETAIL = "Detalle de Autorización"
            static let SIGN_RENOVATIONS = "Mis Renovaciones"
            static let EVALUATE_RENOVATIONS = "Evaluar Renovaciones"
        }
    }
    
    struct STORYBOARD {
        static let MENU              = "Menu"
        static let LOADING           = "Loading"
        static let LOGIN             = "Login"
    }
    
    struct SEGUE{
        static let APPLICATION_DETAIL = "segueApplicationDetail"
        static let APPLICATION_FILTERS = "segueApplicationsFilters"
        static let TRACKING_DETAIL = "segueTrackingDetail"
        static let SIDE_MENU = "segueSideMenu"
        static let MENU = "segueMenu"
        static let RENOVATIONS_MENU = "segueRenovations"
        static let AUTHORIZE_RENOVATIONS = "segueAuthorizeRenovations"
        static let RENOVATION_DETAIL = "segueRenovationDetail"
        static let EVALUATION_DETAIL = "segueRenovationEvaluationDetail"
        static let ONBOARDING = "segueOnBoarding"
    }
    
    struct SECURITY{
        static let AUTHORIZATION_TOKEN_KEY = Bundle.main.infoDictionary?["CFBundleIdentifier"] as! String
        static let AUTHENTICATION_TOKEN_KEY = "authentication_token"
    }
    
    struct MESSAGES {
        static let LOGOUT = "¿Estás seguro de cerrar sesión?"
        static let NO_CONECTION = "No tiene internet"
        static let TITLE_DIALOG = "CanviaAtiende"
        static let EXPIRED_SESSION = "Tiempo de sesión concluido, es necesario volver a loguearse"
        static let CONNECTION_ERROR_TITLE = "Ocurrió un error!"
        static let CONNECTION_ERROR = "Error de conexión, comprueba tu conexión o prueba una diferente e inténtalo más tarde"
        
    }
    
    struct VALUES{
        static let EMPTY = ""
    }
    
    struct BUTTON{
        static let SETTING = "Configuración"
        static let ACCEPT = "Aceptar"
        static let CANCEL = "Cancelar"
        
    }
    
}

struct AppMessages{
    
    struct SYSTEM {
        static let LOCALIZATION_TITLE = "Se requiere tu localización"
        static let LOCALIZATION_MESSAGE = "Con fines de seguridad, por favor activar el GPS en Configuración"
    }
    
    struct SERVICE {
        
        //MARK: CONSTANTES SOLICITUDES
        struct APROBAR_SOLICITUD{
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Solicitud Aprobada exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo aprobar la solicitud"
            
        }
        
        struct RECHAZAR_SOLICITUD{
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Solicitud Rechazada exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo rechazar la solicitud"
            
        }
        
        struct APROBACION_MASIVA_SOLICITUDES{
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Solicitudes Aprobadas exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let WARNING_MESSAGE_PREFIX = "Error en la solicitud Nro: "
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "Error. No se pudo aprobar las solicitudesR"
            
        }
        
        struct RECHAZO_MASIVA_SOLICITUDES{
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Solicitudes Rechazadas exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let WARNING_MESSAGE_PREFIX = "Error en la solicitud Nro: "
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo rechazar las solicitudes"
            
        }
        
        //MARK: CONSTANTES PAPELETA
        struct APROBAR_PAPELETA{
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Papeleta Aprobada exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let WARNING_MESSAGE_PREFIX = "Error en la solicitud Nro: "
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo rechazar las solicitudes"
            
        }
        
        
        struct RECHAZAR_PAPELETA{
            static let SUCCES_MESSAGE = "Papeleta Rechazada exitosamente"
            
        }
        
        
        struct APROBACION_MASIVA_PAPELETAS{
            static let SUCCES_MESSAGE = "Papeletas Aprobadas exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
        }
        
        
        struct RECHAZO_MASIVA_PAPELETAS{
            static let SUCCES_MESSAGE = "Papeletas Rechazadas exitosamente"
            
        }
        
        struct APROBAR_RENOVACION {
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Renovación Aprobada exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let WARNING_MESSAGE_PREFIX = "Error en la solicitud Nro: "
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo rechazar las solicitudes"
            static let NOT_RENOVATION_MESSAGE = "Estimado colaborador, mediante la presente se comunica el término de su contrato. Se requiere suscriba su carta de término mediante el uso de su firma electrónica, para lo cual debe ingresar su usuario y clave de intranet."
            static let NO_RESULTS_MESSAGE = "Sin resultados"
            static let NO_RENOVATIONS_FOR_THE_MOMENT = "Por el momento no hay renovaciones pendientes, puedes probar otros filtros."
        }
        
        struct APROBACION_MASIVA_RENOVACIONES{
            static let SUCCES_MESSAGE = "Renovaciones Aprobadas exitosamente"
            static let WARNING_TITLE = "Incidente encontrado!"
        }
        
        struct REGITRAR_MARCACIONES {
            static let SUCESS_TITLE = "Solicitud Móvil"
            static let SUCCES_MESSAGE = "Marcación realizada correctamente"
            static let WARNING_TITLE = "Incidente encontrado!"
            static let FAIL_TITLE = "Solicitud Móvil"
            static let FAIL_MESSAGE = "No se pudo realizar la marcación"
            
        }
        
    }
    
}
