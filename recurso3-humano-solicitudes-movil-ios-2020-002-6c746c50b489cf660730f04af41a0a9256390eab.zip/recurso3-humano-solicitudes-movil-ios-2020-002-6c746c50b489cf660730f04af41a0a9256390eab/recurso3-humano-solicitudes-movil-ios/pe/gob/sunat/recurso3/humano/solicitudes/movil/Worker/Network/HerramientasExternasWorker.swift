//
//  HerramientasExternasWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

class HerramientasExternasWorker {
    
    static func getExternalToolsParameters(with token: String, forUser userRegistryNum: String,
                               onSuccess success: @escaping (_ response: ObtenerParametrosHerramientasResponse) -> Void,
                               onFailed failed: @escaping (_ response: ObtenerParametrosHerramientasResponse) -> Void ,
                               onAuthenticationError authFailed: @escaping (_ response: ObtenerParametrosHerramientasResponse) -> Void){
       
       let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
       let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(userRegistryNum)/parametrosglosa/043"
       let endpoint = URL(string: endpointURL)

       var request = URLRequest(url: endpoint!)
       request.httpMethod = HttpMethod.POST.rawValue
       request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
       request.addValue("application/json", forHTTPHeaderField: "Accept")
        
       
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=ObtenerParametrosHerramientasResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = ObtenerParametrosHerramientasResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("Se recibio el Http status : \(statusCode)")
                print("Se recibio el Http body" + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.parametros = JSONParser.decode([ParametroHerramientaExterna].self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
               case 401:
                   let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                   response.httpResponse.success = true
                   response.httpResponse.httpCode = String(statusCode)
                   response.httpResponse.error = baseErrorResponse
                   authFailed(response)
                default:
                   var responseFailed=ObtenerParametrosHerramientasResponse()
                   responseFailed.httpResponse.success = false
                   responseFailed.httpResponse.httpCode = String(statusCode)
                   failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
}

