//
//  HeaderView.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

@objc protocol HeaderViewDelegate {
    func actionLeft()
    @objc optional func actionRight()
    @objc optional func actionMore()
    @objc optional func searchOnBar(searchBar: UISearchBar, textDidChange searchText: String)
    @objc optional func searchBarTextDidBeginEditing(searchBar: UISearchBar)
    @objc optional func searchBarCancelButtonClicked(searchBar: UISearchBar)
    @objc optional func searchBarSearchButtonClicked( searchBar: UISearchBar)
}

class HeaderView: UIView {

    @IBOutlet weak var lblTitle:    UILabel!
    @IBOutlet weak var btnLeft:     UIButton!
    @IBOutlet weak var btnRight:    UIButton!
    @IBOutlet weak var ivRight:     UIImageView!
    @IBOutlet weak var ivLeft:      UIImageView!
    @IBOutlet weak var btnRight_0: UIButton!
    @IBOutlet weak var ivRight_0: UIImageView!
    @IBOutlet weak var seachBar: UISearchBar!
    @IBOutlet weak var viewSearch: UIView!
    
    @IBOutlet weak var viewOptionMore: UIView!
    
    @IBOutlet weak var viewSearchBar: UIView!
    
    
    
    
    public var useSearchBar : Bool = false
    public var delegate: HeaderViewDelegate!
    
    struct VALUES {
        static let NIBNAME = "HeaderView"
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
   
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        self.seachBar.isHidden = true
      //  self.seachBar.showsCancelButton = true
        self.seachBar.delegate = self
        
        let txtInsideSearchBar = self.seachBar.value(forKey: "searchField") as? UITextField
        txtInsideSearchBar?.textColor = .white
    }
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: VALUES.NIBNAME, bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }


    public func setTitle(text: String){
        lblTitle.text = text
    }
    
    public func setLeftImage(imageName: String){
        ivLeft.image = UIImage(named: imageName)
    }
    
    public func setRightImage(imageName: String){
        ivRight_0.image = UIImage(named: imageName)
       
      //  ivRight_0.image = UIImage(named: imageName)
    }
    public func setRightImage2(imageName: String){
       // ivRight.image = UIImage(named: imageName)
         ivRight.image = UIImage(named: imageName)
    }
    
    @IBAction func actionRight(_ sender: Any) {
        delegate.actionRight?()
        showElememtonBar()
    }
    
    @IBAction func actionLeft(_ sender: Any) {
        delegate.actionLeft()
    }
    
    
    @IBAction func actionMore(_ sender: Any) {
        delegate.actionMore?()
       
    }
    
    func showElememtonBar(){
        if self.useSearchBar {
            if self.seachBar.isHidden {
                self.seachBar.isHidden = false
                self.lblTitle.isHidden = true
                self.viewSearchBar.isHidden = true
                self.viewSearch.isHidden=true
            } else {
                self.lblTitle.isHidden = false
                self.seachBar.isHidden = true
                  self.viewSearchBar.isHidden = false
                self.viewSearch.isHidden=false
            }
        }
    }
    
    
    
}

extension HeaderView : UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.delegate.searchOnBar?(searchBar: searchBar, textDidChange: searchText)
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.delegate.searchBarTextDidBeginEditing?(searchBar: searchBar)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar){
        self.delegate.searchBarCancelButtonClicked?(searchBar: searchBar)
        showElememtonBar()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}
