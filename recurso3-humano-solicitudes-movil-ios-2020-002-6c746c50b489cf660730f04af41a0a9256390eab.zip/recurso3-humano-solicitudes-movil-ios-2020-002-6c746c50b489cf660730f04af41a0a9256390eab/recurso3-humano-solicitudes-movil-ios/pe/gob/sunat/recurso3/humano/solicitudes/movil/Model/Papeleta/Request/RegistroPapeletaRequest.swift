//
//  RegistroPapeletaRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import Foundation

struct RegistroPapeletaRequest:Codable {
    var usuario: Usuario?
    var papeleta: Papeleta?
    var ubicacion : Ubicacion?

}
