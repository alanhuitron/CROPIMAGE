//
//  PendingApplicationsTrayViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/6/19.
//

import UIKit

class BandejaSolicitudesPendientesViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selectedItemsBarView: UIView!
    @IBOutlet weak var noItemsFoundView: UIView!
    @IBOutlet weak var imgNotFoundItems: UIImageView!
    @IBOutlet weak var lblNotFoundItems: UILabel!
    
    var applications = [Solicitud]() //general
    var applicationsFilteredBySearch = [Solicitud]() //for applications returned by filter. After received, this array become 'applications' array
    var selectedApplication : Solicitud? //application selected by simple touch on cell
    var searchIsActive = false
    var approveApplication = false
    var willBeAMassiveProcess = false
    var userIsInSelectMode = false
    var selectedApplicationsIndexPath = [IndexPath]()
    let refreshControl = UIRefreshControl()
    
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.PENDING_APPLICATION, leftImage: "iconMenu", rightImage: "iconSearch", rightImage2: "iconFilter", useSearchBar: true)
        
        //table view setup
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: UIApplicationTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: UIApplicationTableViewCell.IDENTIFIER)
        self.tableView.tableFooterView = UIView(frame: .zero)
            //adding long press gesture
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        self.tableView.addGestureRecognizer(longPress)
            //adding refresh control for refresh on pull gesture
        self.tableView.refreshControl = refreshControl
        self.refreshControl.addTarget(self, action: #selector(retrievePendingApplications), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.refreshControl.attributedTitle = NSAttributedString(string: "Recuperando solicitudes ...", attributes: attributes)

        
        self.setBotonBarView(self.selectedItemsBarView, viewControllerTitle: AppConstants.VIEWCONTROLLER.TITLE.PENDING_APPLICATION, viewController: self)
        
        self.retrievePendingApplications()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: false)
        }
        print("viewWillAppear indexSelected after clean \(selectedApplicationsIndexPath.count)")
    }
    
    
    // MARK: - Miscellaneous Fuctions
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: self.tableView)
            if let indexPath = self.tableView.indexPathForRow(at: touchPoint) {
                self.selectCellOn(indexPath: indexPath)
                if !self.userIsInSelectMode {
                    self.userIsInSelectMode = true
                }
            }
        }
        print("handleLongPress indexsSelected \(selectedApplicationsIndexPath.count)")
    }
    
    private func selectCellOn(indexPath : IndexPath){
        print("selected :\(indexPath.row)")
        let cell = tableView.cellForRow(at: indexPath)
        if selectedApplicationsIndexPath.contains(indexPath){
            cell?.backgroundColor = .white
            if let index = selectedApplicationsIndexPath.firstIndex(of: indexPath){
                selectedApplicationsIndexPath.remove(at: index)
            }
        } else {
            cell!.backgroundColor = UIColor(netHex: 0xD1D1D6)
            selectedApplicationsIndexPath.append(indexPath)
        }
        
        if selectedApplicationsIndexPath.count == 0 {
            self.userIsInSelectMode = false
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.ocultarBotonAction()
                botonBarView.setLabelSelectTodo()
                botonBarView.checkTotal.isChecked = false
            }
        }else {
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.setLabelTotal(totalFila: String(selectedApplicationsIndexPath.count))
                botonBarView.mostrarBotonAction()
              
            }
        }
    }
    
    func prepareDefaultApplicationRequest()->SolicitudRequest{
        var request = SolicitudRequest()
        request.codPersona=self.appDelegate.currentUser.registryNumber
        return request
    }
    
    @objc func retrievePendingApplications(){
        self.searchIsActive = false
        self.applicationsFilteredBySearch.removeAll()
        self.selectedApplicationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        self.showSpinner(onView: self.view)
        SolicitudWorker.getPendingRequests(with: appDelegate.authorizationToken, parameters: prepareDefaultApplicationRequest(), onSuccess: { (onSuccessResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.applications = onSuccessResponse.httpBody.solicitudes!
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }, onFailed: {(onFailed) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.applicationsFilteredBySearch.removeAll()
                self.applications.removeAll()
                self.tableView.reloadData()
            }
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.showExpiredSessionAlert(on: self)
            }
        })
        
    }
    
    func prepareApplicationsForRequest() -> [Solicitud]?{
        var solicitudes : [Solicitud]?
        print("Applications number:  \(selectedApplicationsIndexPath.count)")
        if selectedApplicationsIndexPath.count > 0 {
            solicitudes = [Solicitud]()
            for indexPath in selectedApplicationsIndexPath{
                let application : Solicitud?
                if searchIsActive {
                    application = applicationsFilteredBySearch[indexPath.row]
                } else {
                    application = applications[indexPath.row]
                }
                
                if let _ = application{
                    solicitudes?.append(application!)
                }
            }
        }
        return solicitudes
    }
    
    func callMassiveApproveService(with request : AprobarSolicitudRequest){
        SolicitudWorker.approveMassivePendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
            if onSuccessResponse.httpBody.indProceso == "1" {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBACION_MASIVA_SOLICITUDES.SUCCES_MESSAGE)
            } else {
                let errorMessage =  "\(AppMessages.SERVICE.APROBACION_MASIVA_SOLICITUDES.WARNING_MESSAGE_PREFIX) \(onSuccessResponse.httpBody.solicitudError?.numSolicitud ?? 0) " + (onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle.")
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBACION_MASIVA_SOLICITUDES.WARNING_TITLE, message: errorMessage, configuration: .Warning)
            }
        }, onFailed: {(onFailedResponse) in
            UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBACION_MASIVA_SOLICITUDES.FAIL_MESSAGE, configuration: .Error)
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    func callApproveService(with request : AprobarSolicitudRequest){
        SolicitudWorker.approvePendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
            if let errores = onSuccessResponse.httpBody.errores {
                if errores.count > 0 {
                    let errorMessage =  onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle."
                    UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBAR_SOLICITUD.WARNING_TITLE,message: errorMessage, configuration: .Warning)
                } else {
                    UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.SUCCES_MESSAGE)
                }
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.SUCCES_MESSAGE)
            }
            
        }, onFailed: {(onFailedResponse) in
            UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.FAIL_MESSAGE, configuration: .Error)
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    func callMassiveRejectService(with request : RechazarSolicitudRequest){
        SolicitudWorker.rejectMassivePendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
            if onSuccessResponse.httpBody.indProceso == "1" {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZO_MASIVA_SOLICITUDES.SUCCES_MESSAGE)
            } else {
                let errorMessage =  "\(AppMessages.SERVICE.RECHAZO_MASIVA_SOLICITUDES.WARNING_MESSAGE_PREFIX) \(onSuccessResponse.httpBody.solicitudError?.numSolicitud ?? 0) " + (onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle.")
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.RECHAZO_MASIVA_SOLICITUDES.WARNING_TITLE, message: errorMessage, configuration: .Warning)
            }
        }, onFailed: {(onFailedResponse) in
            UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZO_MASIVA_SOLICITUDES.FAIL_MESSAGE, configuration: .Error)
        
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    func callRejectService(with request : RechazarSolicitudRequest){
        SolicitudWorker.rejectPendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
            if let errores = onSuccessResponse.httpBody.errores {
                if errores.count > 0 {
                    let errorMessage =  onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle."
                    UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.RECHAZAR_SOLICITUD.WARNING_TITLE, message: errorMessage, configuration: .Warning)
                } else {
                    UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.SUCCES_MESSAGE)
                }
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.SUCCES_MESSAGE)
            }
        }, onFailed: {(onFailedResponse) in
            UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.FAIL_MESSAGE, configuration: .Error)
        
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DetalleSolicitudViewController {
            vc.parametersForApplicationDetail = self.selectedApplication
            vc.delegate = self
            
        } else if let vc = segue.destination as? FiltroSolicitudesPendientesViewController {
            vc.delegate = self
        }
    }

}


// MARK: - EXTENSION TABLEVIEW
extension BandejaSolicitudesPendientesViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if applications.count == 0 {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: false)
        } else {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: true)
        }
        
        if searchIsActive {
            return applicationsFilteredBySearch.count
        }
        return applications.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UIApplicationTableViewCell.IDENTIFIER ,for: indexPath) as! UIApplicationTableViewCell
        cell.selectionStyle = .none
        
        let application : Solicitud?
        if searchIsActive {
            application = applicationsFilteredBySearch[indexPath.row]
        } else {
            application = applications[indexPath.row]
        }
        
        if selectedApplicationsIndexPath.contains(indexPath){
            cell.backgroundColor = UIColor(netHex: 0xD1D1D6)
        } else {
            cell.backgroundColor = UIColor(netHex: 0xFFFFFF)
        }
        
        cell.lblPersonName.text = application?.nomPersona
        let applicationYear = application?.annSolicitud ?? ""
        let applicationNum = String(application?.numSolicitud ?? 0)
        cell.lblApplicationId.text = "\(applicationYear)-\(applicationNum)"
        cell.lblApplicationDescription.text = application?.desSolicitud
        cell.lblApplicationDate.text = DateUtils.convert(dateString: application?.fecSolicitud ?? "", from: DateUtils.dd_MM_yyyy_HH_mm_ss_withSlashFormat, with: .short)
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if userIsInSelectMode {
            self.selectCellOn(indexPath: indexPath)
        } else {
            self.selectedApplication = applications[indexPath.row]
            self.performSegue(withIdentifier: AppConstants.SEGUE.APPLICATION_DETAIL, sender: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let rejectAction =  UIContextualAction(style: .destructive, title: "RECHAZAR", handler: { (action,view,completionHandler ) in
                self.approveApplication = false
                self.willBeAMassiveProcess = false
                UserAlerts.showAlertForUserObservation(on: self)
            })
        rejectAction.title = "RECHAZAR"
        rejectAction.backgroundColor = .red
        let configuration = UISwipeActionsConfiguration(actions: [rejectAction])
        return configuration
    }
    
    func setupHiddenPropertyForNotFoundRelatedViews(isHidden :  Bool){
        self.noItemsFoundView.isHidden = isHidden
        self.imgNotFoundItems.isHidden = isHidden
        self.lblNotFoundItems.isHidden = isHidden
        if !isHidden {
            self.tableView.backgroundColor = .clear
        } else {
            self.tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        }
    }
    
}


// MARK: - EXTENSION HeaderView
extension BandejaSolicitudesPendientesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.openMenu()
    }
    
    func actionMore() {
        self.performSegue(withIdentifier: AppConstants.SEGUE.APPLICATION_FILTERS, sender: nil)
    }
    
    func searchOnBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchIsActive = true;
        if searchText.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            self.searchIsActive = false
        }else{
            self.applicationsFilteredBySearch = applications.filter({ (application) -> Bool in
                self.searchIsActive = true
                let add = (application.nomPersona?.lowercased().contains(searchText.lowercased()) ?? false)
                return add
            })
        }
        self.tableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setValue("Cancelar", forKey: "cancelButtonText")
        searchBar.showsCancelButton = true
        searchBar.enablesReturnKeyAutomatically = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = nil
        searchBar.showsCancelButton = false
        //Remove focus from the search bar.
        searchBar.endEditing(true)
        applicationsFilteredBySearch = []
        searchIsActive = false;
        self.tableView.reloadData()
     }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}


// MARK: - EXTENSION FiltroSolicitudes
extension BandejaSolicitudesPendientesViewController: FiltroSolicitudesPendientesViewControllerDelegate{
    
    func filtersWereApplied(filteredApplications: [Solicitud]?) {
        self.applications = filteredApplications ?? [Solicitud]()
        for indexPath in selectedApplicationsIndexPath {
            let cell = self.tableView.cellForRow(at: indexPath)
            cell?.backgroundColor = .white
        }
        self.selectedApplicationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        self.tableView.reloadData()
    }
    
    func cleanWasApplied() {
        self.retrievePendingApplications()
    }
    
}


// MARK: - EXTENSION BotonBarView
extension BandejaSolicitudesPendientesViewController: BotonBarViewDelegate{
    
    func actionCheckBox() {
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            if botonBarView.getChecked(){
                self.userIsInSelectMode = true
                self.selectedApplicationsIndexPath.removeAll()
                botonBarView.mostrarBotonAction()
                var counter = 0
                if self.searchIsActive{
                    botonBarView.setLabelTotal(totalFila: String (applicationsFilteredBySearch.count))
                    for _ in applicationsFilteredBySearch{
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedApplicationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                } else {
                    botonBarView.setLabelTotal(totalFila: String (applications.count))
                    for _ in applications{
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedApplicationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                }
                
            }else{
                self.userIsInSelectMode = false
                botonBarView.setLabelSelectTodo()
                botonBarView.ocultarBotonAction()
                var counter = 0
                if searchIsActive {
                    for _ in applicationsFilteredBySearch{
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedApplicationsIndexPath.firstIndex(of: index){
                            self.selectedApplicationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                } else {
                    for _ in applications{
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedApplicationsIndexPath.firstIndex(of: index){
                            self.selectedApplicationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                }
            }
        }
        self.tableView.reloadData()
    }
    
    func actionAprobar () {
        print("Se van a aprobar \(self.selectedApplicationsIndexPath.count) solicitudes")
        self.approveApplication = true
        self.willBeAMassiveProcess = true
        UserAlerts.showAlertForUserObservation(on: self)
    }
    
    func actionRechazar() {
        print("Se van a rechazar \(self.selectedApplicationsIndexPath.count) solicitudes")
        self.approveApplication = false
        self.willBeAMassiveProcess = true
        UserAlerts.showAlertForUserObservation(on: self)
    }
    
}


// MARK: - EXTENSION UIObservationInputAlertViewController
extension BandejaSolicitudesPendientesViewController :  UIObservationInputAlertViewControllerDelegate {
    
    func observationWasAdded(observation: String) {
        if self.willBeAMassiveProcess {
            print("Preparando procesamiento masivo...")
            if self.approveApplication {
                var request = AprobarSolicitudRequest()
                request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
                request.codLoginAprobador = appDelegate.currentUser.userName
                request.desMensajeAprobacion = observation
                request.numLatitud = appDelegate.location?.latitude.description
                request.numLongitud = appDelegate.location?.longitude.description
                request.solicitudes = prepareApplicationsForRequest()
                
                self.callMassiveApproveService(with: request)
                
            } else {
                var request = RechazarSolicitudRequest()
                request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
                request.codLoginAprobador = appDelegate.currentUser.userName
                request.desMensajeAprobacion = observation
                request.numLatitud = appDelegate.location?.latitude.description
                request.numLongitud = appDelegate.location?.longitude.description
                request.solicitudes = prepareApplicationsForRequest()
                
                self.callMassiveRejectService(with: request)
            }
        } else {
            print("Preparando procesamiento individual...")
            if self.approveApplication {
                var request = AprobarSolicitudRequest()
                request.codPersonaSolicitud = selectedApplication?.codPersona
                request.annSolicitud = selectedApplication?.annSolicitud
                if let numSolicitud = selectedApplication?.numSolicitud {
                    request.numSolicitud = String(numSolicitud)
                }
                request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
                request.codLoginAprobador = appDelegate.currentUser.userName
                request.desMensajeAprobacion = observation
                request.numLatitud = appDelegate.location?.latitude.description
                request.numLongitud = appDelegate.location?.longitude.description
                
                self.callApproveService(with: request)
                
            } else {
                var request = RechazarSolicitudRequest()
                request.codPersonaSolicitud = selectedApplication?.codPersona
                request.annSolicitud = selectedApplication?.annSolicitud
                if let numSolicitud = selectedApplication?.numSolicitud {
                    request.numSolicitud = String(numSolicitud)
                }
                request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
                request.codLoginAprobador = appDelegate.currentUser.userName
                request.desMensajeAprobacion = observation
                request.numLatitud = appDelegate.location?.latitude.description
                request.numLongitud = appDelegate.location?.longitude.description
                
                self.callRejectService(with: request)
            }
        }
    }
    
    func observationInputEventWasCancelled() {
        self.tableView.reloadData()
    }
}

// MARK: - EXTENSION DetalleSolicitud
extension BandejaSolicitudesPendientesViewController : DetalleSolicitudViewControllerDelegate {
    
    func applicationApprovedOrRejected() {
        self.retrievePendingApplications()
    }
}

// MARK: - EXTENSION UIActionResultAlert
extension BandejaSolicitudesPendientesViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        self.retrievePendingApplications()
    }
}

// MARK: - EXTENSION UIApplicationTableViewCell
extension BandejaSolicitudesPendientesViewController : UIApplicationTableViewCellDelegate {
    
    func approveApplicationByClickOnCheck(object: UIApplicationTableViewCell) {
        self.approveApplication = true
        self.willBeAMassiveProcess = false
        let indexPathOfSelectedByTapOnCheck = self.tableView.indexPath(for: object)
        if let secureIndexPath =  indexPathOfSelectedByTapOnCheck{
            if self.searchIsActive {
                let applicationByIndexPathOnSearch = self.applicationsFilteredBySearch[secureIndexPath.row]
                self.selectedApplication = applicationByIndexPathOnSearch
            } else {
                let applicationByIndexPath = self.applications[secureIndexPath.row]
                self.selectedApplication = applicationByIndexPath
            }
            UserAlerts.showAlertForUserObservation(on: self)
        }
    }
}
