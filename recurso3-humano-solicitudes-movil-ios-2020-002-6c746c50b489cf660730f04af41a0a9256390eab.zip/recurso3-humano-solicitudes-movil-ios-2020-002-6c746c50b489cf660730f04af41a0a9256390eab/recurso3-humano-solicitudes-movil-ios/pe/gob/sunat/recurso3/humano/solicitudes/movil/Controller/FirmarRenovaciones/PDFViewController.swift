//
//  PDFViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/29/20.
//

import UIKit
import PDFKit
import WebKit


class PDFViewController : ParentViewController {

    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var pdfUIView: UIView!
    
    @IBOutlet weak var pdfWebView: WKWebView!
    public var PDFName : String?
    public var blob64 : String?
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeaderViewForPDFDownload(headerView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.SIGN_RENOVATIONS, leftImage: "iconLeft", rightImage: "downloadIcon")
        //createPDFView(pdfName: PDFName!)
        
        let url : URL! = getPDFURL()
        pdfWebView.load(NSURLRequest(url: url) as URLRequest)
    }
    
    func getPDFURL () -> URL? {
        guard var documentsURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last else { return nil }
        if var pdfName = self.PDFName {
            if !pdfName.contains(".pdf") {
                pdfName = pdfName + ".pdf"
            }
            documentsURL.appendPathComponent("\(pdfName)")
        }
        return documentsURL
    }
    
    @available(iOS 11.0, *)
    func savePDF(document: Data) {
        DispatchQueue.global().async {
            DispatchQueue.main.async {
                let activityController = UIActivityViewController(activityItems: [document], applicationActivities: nil)
                self.present(activityController, animated: true, completion: nil)
            }
        }
    }
    
    
    func createPDFView(pdfName: String) {
        let pdfView = PDFView()

        pdfView.translatesAutoresizingMaskIntoConstraints = false
        pdfUIView.addSubview(pdfView)

        pdfView.leadingAnchor.constraint(equalTo: pdfUIView.safeAreaLayoutGuide.leadingAnchor).isActive = true
        pdfView.trailingAnchor.constraint(equalTo: pdfUIView.safeAreaLayoutGuide.trailingAnchor).isActive = true
        pdfView.topAnchor.constraint(equalTo: pdfUIView.safeAreaLayoutGuide.topAnchor).isActive = true
        pdfView.bottomAnchor.constraint(equalTo: pdfUIView.safeAreaLayoutGuide.bottomAnchor).isActive = true
        
        guard var documentsURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last else { return }
        if var pdfName = self.PDFName {
            if !pdfName.contains(".pdf") {
                pdfName = pdfName + ".pdf"
            }
            documentsURL.appendPathComponent("\(pdfName)")
            if let document = PDFDocument(url: documentsURL) {
                pdfView.document = document
            }
        }

        //name your file however you prefer

        
    }
    
}


// MARK: - EXTENSION HeaderView
extension PDFViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.openMenu()
    }
    
    func actionMore() {
        guard let convertedData = Data(base64Encoded: self.blob64!) else { return }
        self.savePDF(document: convertedData)
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setValue("Cancelar", forKey: "cancelButtonText")
        searchBar.showsCancelButton = true
        searchBar.enablesReturnKeyAutomatically = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        //
     }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}
