//
//  UITrackingTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/11/19.
//

import UIKit

class UITrackingTableViewCell: UITableViewCell {
    
    static let NAME = "UITrackingTableViewCell"
    static let IDENTIFIER = "UITrackingTableViewCell"

    @IBOutlet weak var lblReceptionDate: UILabel!
    @IBOutlet weak var lblIssuerName: UILabel!
    @IBOutlet weak var lblAddressee: UILabel!
    @IBOutlet weak var lblActionDescription: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
