//
//  SeguimientoRenovacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import Foundation

struct SeguimientoRenovacion : Codable {
    var numIntencion : Int?
    var numSeguimiento: Int?
    var numPerirenov: Int?
    var obsRenovacion: String?
    var codRegistro: String?
    var situacion: String?
    var nombPersona: String?
    var estado: String?
    var desPeriodo: String?
    var fecRegistro: String?
}
