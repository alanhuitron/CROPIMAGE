//
//  PapeletaWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation
struct PapeletaWorker {
    
    static func getPendingPapeletaRequest(with token: String,
                                parameters: PapeletaRequest,
                                onSuccess success: @escaping (_ response: PapeletaResponse) -> Void,
                                onFailed failed: @escaping (_ response: PapeletaResponse) -> Void ,
                                onAuthenticationError authFailed: @escaping (_ response: PapeletaResponse) -> Void){
          let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
          let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.codPersona ?? "")/papeletasPendientes"
          let endpoint = URL(string: endpointURL)

          var request = URLRequest(url: endpoint!)
          request.httpMethod = HttpMethod.POST.rawValue
          request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
          request.addValue("application/json", forHTTPHeaderField: "Content-Type")
          request.addValue("application/json", forHTTPHeaderField: "Accept")
          //request.encodeBodyParameters(parameters:  parameters.toDictionary() as! [String : String])
          
        request.httpBody=JSONParser.encode(parameters)
         print(String(data: request.httpBody!, encoding: .utf8) ?? "")

         let configuration  = URLSessionConfiguration.default
         let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
         let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
             if(response == nil){
                 var responseFailed=PapeletaResponse()
                 responseFailed.httpResponse.success = false
                 failed(responseFailed)
             }else{
                 let httpResponse = response as! HTTPURLResponse
                 let statusCode = httpResponse.statusCode
                 var response = PapeletaResponse()
                 let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                 print("llega Papeletas" + dataAsString)
                 switch statusCode {
                 case 200:
                     response.httpBody.papeletas = JSONParser.decode([Papeleta].self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     success(response)
                 case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                 default:
                    var responseFailed=PapeletaResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    failed(responseFailed)
                 }
             }
         })
         task.resume()
     }
    
    static func getAcceptPapeletaRequest(with token: String,
                                   parameters: RegistroPapeletaRequest,
                                 onSuccess success: @escaping (_ response: PapeletaResponse) -> Void,
                                 onFailed failed: @escaping (_ response: PapeletaResponse) -> Void,
                                 onAuthenticationError authFailed: @escaping (_ response: PapeletaResponse) -> Void){
            
            let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
            let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.usuario?.nroRegistro ?? "")/papeletas/aprobar"
            let endpoint = URL(string: endpointURL)

             var request = URLRequest(url: endpoint!)
             request.httpMethod = HttpMethod.POST.rawValue
             request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
             request.addValue("application/json", forHTTPHeaderField: "Content-Type")
             request.addValue("application/json", forHTTPHeaderField: "Accept")
             //request.encodeBodyParameters(parameters:  parameters.toDictionary() as! [String : String])
             
            request.httpBody=JSONParser.encode(parameters)
            print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=PapeletaResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = PapeletaResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("llega Papeletas" + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.papeletas = JSONParser.decode([Papeleta].self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        success(response)
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                    default:
                       var responseFailed=PapeletaResponse()
                       responseFailed.httpResponse.success = false
                       responseFailed.httpResponse.httpCode = String(statusCode)
                       failed(responseFailed)
                    }
                }
            })
            task.resume()
        }
       
    
    static func getRejectPapeletaRequest(with token: String,
                                    parameters: RegistroPapeletaRequest,
                                  onSuccess success: @escaping (_ response: PapeletaResponse) -> Void,
                                  onFailed failed: @escaping (_ response: PapeletaResponse) -> Void,
                                  onAuthenticationError authFailed: @escaping (_ response: PapeletaResponse) -> Void){
              let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
              let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.usuario?.nroRegistro ?? "")/papeletas/rechazar"
              let endpoint = URL(string: endpointURL)

              var request = URLRequest(url: endpoint!)
              request.httpMethod = HttpMethod.POST.rawValue
              request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
              request.addValue("application/json", forHTTPHeaderField: "Content-Type")
              request.addValue("application/json", forHTTPHeaderField: "Accept")
              //request.encodeBodyParameters(parameters:  parameters.toDictionary() as! [String : String])
              
             request.httpBody=JSONParser.encode(parameters)
              print(String(data: request.httpBody!, encoding: .utf8) ?? "")

             let configuration  = URLSessionConfiguration.default
             let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
             let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                 if(response == nil){
                     var responseFailed=PapeletaResponse()
                     responseFailed.httpResponse.success = false
                     failed(responseFailed)
                 }else{
                     let httpResponse = response as! HTTPURLResponse
                     let statusCode = httpResponse.statusCode
                     var response = PapeletaResponse()
                     let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                     print("llega Papeletas" + dataAsString)
                     switch statusCode {
                     case 200:
                         response.httpBody.papeletas = JSONParser.decode([Papeleta].self, from: data!)!
                         response.httpResponse.success = true
                         response.httpResponse.httpCode = String(statusCode)
                         success(response)
                     case 400:
                         let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                         response.httpResponse.success = true
                         response.httpResponse.httpCode = String(statusCode)
                         response.httpResponse.error = baseErrorResponse
                         failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                     default:
                        var responseFailed=PapeletaResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                     }
                 }
             })
             task.resume()
         }
    
    
    static func getAcceptMasivaPapeletaRequest(with token: String,
                                    parameters: RegistroPapeletaMasivaRequest,
                                  onSuccess success: @escaping (_ response: PapeletaMasivaResponse) -> Void,
                                  onFailed failed: @escaping (_ response: PapeletaMasivaResponse) -> Void,
                                  onAuthenticationError authFailed: @escaping (_ response: PapeletaMasivaResponse) -> Void){
             
              let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
              let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.usuario?.nroRegistro ?? "")/papeletas/aprobarmasiva"
              let endpoint = URL(string: endpointURL)

              var request = URLRequest(url: endpoint!)
              request.httpMethod = HttpMethod.POST.rawValue
              request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
              request.addValue("application/json", forHTTPHeaderField: "Content-Type")
              request.addValue("application/json", forHTTPHeaderField: "Accept")
              //request.encodeBodyParameters(parameters:  parameters.toDictionary() as! [String : String])
              
            request.httpBody=JSONParser.encode(parameters)
              print(String(data: request.httpBody!, encoding: .utf8) ?? "")

             let configuration  = URLSessionConfiguration.default
             let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
             let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                 if(response == nil){
                     var responseFailed=PapeletaMasivaResponse()
                     responseFailed.httpResponse.success = false
                     failed(responseFailed)
                 }else{
                     let httpResponse = response as! HTTPURLResponse
                     let statusCode = httpResponse.statusCode
                     var response = PapeletaMasivaResponse()
                     let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                     print("llega Papeletas" + dataAsString)
                     switch statusCode {
                     case 200:
                         response.httpBody.papeletaResponse =  JSONParser.decode(MasivaPapeleta.self, from: data!)!
                         response.httpResponse.success = true
                         response.httpResponse.httpCode = String(statusCode)
                         success(response)
                     case 400 :
                         let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                         response.httpResponse.success = true
                         response.httpResponse.httpCode = String(statusCode)
                         response.httpResponse.error = baseErrorResponse
                         failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                     default:
                        var responseFailed=PapeletaMasivaResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                     }
                 }
             })
             task.resume()
         }
    
    
    
     static func getRejectMasivaPapeletaRequest(with token: String,
                                   parameters: RegistroPapeletaMasivaRequest,
                                   onSuccess success: @escaping (_ response: PapeletaMasivaResponse) -> Void,
                                   onFailed failed: @escaping (_ response: PapeletaMasivaResponse) -> Void,
                                   onAuthenticationError authFailed: @escaping (_ response: PapeletaMasivaResponse) -> Void){
        
                let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
                let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.usuario?.nroRegistro ?? "")/papeletas/rechazarmasiva"
                let endpoint = URL(string: endpointURL)

               var request = URLRequest(url: endpoint!)
               request.httpMethod = HttpMethod.POST.rawValue
               request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
               request.addValue("application/json", forHTTPHeaderField: "Content-Type")
               request.addValue("application/json", forHTTPHeaderField: "Accept")
               //request.encodeBodyParameters(parameters:  parameters.toDictionary() as! [String : String])
               
               request.httpBody=JSONParser.encode(parameters)
               print(String(data: request.httpBody!, encoding: .utf8) ?? "")

              let configuration  = URLSessionConfiguration.default
              let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
              let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                  if(response == nil){
                      var responseFailed=PapeletaMasivaResponse()
                      responseFailed.httpResponse.success = false
                      failed(responseFailed)
                  }else{
                      let httpResponse = response as! HTTPURLResponse
                      let statusCode = httpResponse.statusCode
                      var response = PapeletaMasivaResponse()
                      let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                      print("llega Papeletas" + dataAsString)
                      switch statusCode {
                      case 200:
                          response.httpBody.papeletaResponse =  JSONParser.decode(MasivaPapeleta.self, from: data!)!
                          response.httpResponse.success = true
                          response.httpResponse.httpCode = String(statusCode)
                          success(response)
                      case 400:
                          let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                          response.httpResponse.success = true
                          response.httpResponse.httpCode = String(statusCode)
                          response.httpResponse.error = baseErrorResponse
                          failed(response)
                        case 401:
                           let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                           response.httpResponse.success = true
                           response.httpResponse.httpCode = String(statusCode)
                           response.httpResponse.error = baseErrorResponse
                           authFailed(response)
                      default:
                         var responseFailed=PapeletaMasivaResponse()
                         responseFailed.httpResponse.success = false
                         responseFailed.httpResponse.httpCode = String(statusCode)
                         failed(responseFailed)
                      }
                  }
              })
              task.resume()
          }
}
