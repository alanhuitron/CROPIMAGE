//
//  DateExtension.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 12/1/20.
//

import Foundation

extension Date {
    func timeAgoDisplay() -> String {

        let calendar = Calendar.current
        let minuteAgo = calendar.date(byAdding: .minute, value: -1, to: Date())!
        let hourAgo = calendar.date(byAdding: .hour, value: -1, to: Date())!
        let dayAgo = calendar.date(byAdding: .day, value: -1, to: Date())!
        let weekAgo = calendar.date(byAdding: .day, value: -7, to: Date())!

        if minuteAgo < self {
            let diff = Calendar.current.dateComponents([.second], from: self, to: Date()).second ?? 0
            var dateString = String()
            if diff == 1 {
                dateString = "Hace \(diff) segundo"
            } else {
                dateString = "Hace \(diff) segundos"
            }
            return dateString
        } else if hourAgo < self {
            let diff = Calendar.current.dateComponents([.minute], from: self, to: Date()).minute ?? 0
            var dateString = String()
            if diff == 1 {
                dateString = "Hace \(diff) minuto"
            } else {
                dateString = "Hace \(diff) minutos"
            }
            return dateString
        } else if dayAgo < self {
            let diff = Calendar.current.dateComponents([.hour], from: self, to: Date()).hour ?? 0
            var dateString = String()
            if diff == 1 {
                dateString = "Hace \(diff) hora"
            } else {
                dateString = "Hace \(diff) horas"
            }
            return dateString
        } else if weekAgo < self {
            let diff = Calendar.current.dateComponents([.day], from: self, to: Date()).day ?? 0
            var dateString = String()
            if diff == 1 {
                dateString = "Hace \(diff) día"
            } else {
                dateString = "Hace \(diff) días"
            }
            return dateString
        }
        let diff = Calendar.current.dateComponents([.weekOfYear], from: self, to: Date()).weekOfYear ?? 0
        var dateString = String()
        if diff == 1 {
            dateString = "Hace \(diff) semana"
        } else {
            dateString = "Hace \(diff) semanas"
        }
        return dateString
    }
}
