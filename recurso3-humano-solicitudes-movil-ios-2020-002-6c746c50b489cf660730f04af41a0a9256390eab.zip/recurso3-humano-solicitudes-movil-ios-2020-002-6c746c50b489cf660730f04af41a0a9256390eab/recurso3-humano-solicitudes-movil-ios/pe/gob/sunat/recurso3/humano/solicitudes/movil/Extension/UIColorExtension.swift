//
//  UIColor.swift
//  TemplateSwift
//
//  Created by Johann Samamé Rodríguez on 17/04/18.
//  Copyright © 2018 Fernando Mateo Ramos. All rights reserved.
//

import UIKit

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(netHex:Int) {
        self.init(red:(netHex >> 16) & 0xff, green:(netHex >> 8) & 0xff, blue:netHex & 0xff)
    }
    
    convenience init(hexString: String, alpha: CGFloat = 1.0) {
        let hexString: String = hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
    
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        return String(format:"#%06x", rgb)
    }

    struct FlatColor {
        static let PrimaryColor = UIColor(netHex: 0x007AFF)
        static let StandardColor = UIColor(netHex: 0x9A9A9A)
        static let LightStandardColor = UIColor(netHex: 0xEFEFF4)
        static let AccentColor = UIColor(netHex: 0xE71C53)
        
        struct Green {
            static let Fern = UIColor(netHex: 0x6ABB72)
            static let MountainMeadow = UIColor(netHex: 0x3ABB9D)
            static let ChateauGreen = UIColor(netHex: 0x4DA664)
            static let PersianGreen = UIColor(netHex: 0x2CA786)
            static let ColorBackgroundProject = UIColor(netHex: 0xd6e886)
            static let ColorTextProject = UIColor(netHex: 0x9bbe00)
        }
        
        struct Blue {
            static let gmdBlue = UIColor(netHex: 0x003F91)
            
            static let PictonBlue = UIColor(netHex: 0x5CADCF)
            static let Mariner = UIColor(netHex: 0x3585C5)
            static let CuriousBlue = UIColor(netHex: 0x4590B6)
            static let Denim = UIColor(netHex: 0x2F6CAD)
            static let Chambray = UIColor(netHex: 0x485675)
            static let BlueWhale = UIColor(netHex: 0x29334D)
            static let CornflowerBlue = UIColor(netHex: 0x62ABFB)
            static let PaleCornflowerBlue = UIColor(netHex: 0x62ABFB)
            static let IconP = UIColor(netHex: 0x005196)
            static let ColorBackgroundClient = UIColor(netHex: 0xade4fa)
            static let ColorTextClient = UIColor(netHex: 0x00a0e0)
            static let ColorTextLimit = UIColor(netHex: 0x00A0E1)
        }
        
        struct Violet {
            static let Wisteria = UIColor(netHex: 0x9069B5)
            static let BlueGem = UIColor(netHex: 0x533D7F)
        }
        
        struct Yellow {
            static let Energy = UIColor(netHex: 0xF2D46F)
            static let Turbo = UIColor(netHex: 0xF7C23E)
            static let Banner = UIColor(netHex: 0xFDB918)
        }
        
        struct Orange {
            static let NeonCarrot = UIColor(netHex: 0xF79E3D)
            static let Sun = UIColor(netHex: 0xEE7841)
            static let IconC = UIColor(netHex: 0xff5b01)
            static let TextMenu = UIColor(netHex: 0xFF6700)
            static let backgroundView = UIColor(netHex: 0xFF5800)
        }
        
        struct Red {
            static let TerraCotta = UIColor(netHex: 0xE66B5B)
            static let Valencia = UIColor(netHex: 0xCC4846)
            static let Cinnabar = UIColor(netHex: 0xDC5047)
            static let WellRead = UIColor(netHex: 0xB33234)
        }
        
        struct Gray {
            static let DimGrey = UIColor(netHex: 0x666666)
            static let DarkGrey = UIColor(netHex: 0xC7C7CC)
            static let LightGray = UIColor(netHex: 0xEFEFF4)
            static let UltraLightGray = UIColor(netHex: 0xF9F9F9)
            static let AlmondFrost = UIColor(netHex: 0xA28F85)
            static let WhiteSmoke = UIColor(netHex: 0xEFEFEF)
            static let Iron = UIColor(netHex: 0xD1D5D8)
            static let IronGray = UIColor(netHex: 0x75706B)
            static let SilverGray = UIColor(netHex: 0xDEDEE1)
            static let Aluminium = UIColor(netHex: 0x8A8D8F)
            static let White = UIColor(netHex: 0xffffff)
            static let BorderGray = UIColor(netHex: 0xD2D2DB)
            static let ButtonTitleGray = UIColor(netHex: 0x9B9B9B)
            static let TextReclamo = UIColor(netHex: 0xB6BEC9)
            static let colorTrasparent = UIColor.black.withAlphaComponent(0.2)
            static let textColor = UIColor(netHex: 0x4B4C4F)
            static let textDisable = UIColor(netHex: 0x8F96B0)
        }
    }
}

