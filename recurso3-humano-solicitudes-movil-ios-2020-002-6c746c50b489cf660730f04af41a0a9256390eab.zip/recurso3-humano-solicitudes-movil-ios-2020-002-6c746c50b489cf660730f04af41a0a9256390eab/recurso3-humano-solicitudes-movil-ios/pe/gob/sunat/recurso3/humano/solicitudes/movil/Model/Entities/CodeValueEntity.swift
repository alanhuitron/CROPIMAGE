//
//  CodigoValorEntity.swift
//  AppPrecintos
//
//  Created by MOJAVE on 10/5/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class CodeValueEntity: NSObject {

    var code: String = ""
    var value: String = ""
    
    init(code : String, value :String) {
        self.code = code
        self.value = value
    }

}
