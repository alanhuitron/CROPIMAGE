//
//  RelativeAppsHelper.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/7/19.
//

import Foundation
import UIKit

class RelativeAppsHelper {
    
    class func openSecurityAppIfPosible(using viewController: UIViewController){
        DispatchQueue.main.async {
            //try calling security app with close session dummy url
            let securityAppURLForTest = URL(string: AppDelegate.authenticationAppURL+"?"+AppDelegate.clientIdParam+"&"+AppDelegate.clientSecretParam+"&"+AppDelegate.actionCloseSession)
            if !UIApplication.shared.canOpenURL(securityAppURLForTest!) {
                //If is not posible call security app, show alert to download it
                //TODO: define message as constants
                UserAlerts.showAlertMessageForSecurityAppRequired(on: viewController, message: "Favor de instalar el App Seguridad SUNAT desde Microsoft Intune")
            } else {
                self.openRelativeApp(for: AppDelegate.actionCreateAuthorizeToken)
            }
            
        }
    }
    
    class func openRelativeApp(for action :String) {
        var urlScheme = String()
        urlScheme.append(AppDelegate.authenticationAppURL)
        urlScheme.append("?")
        urlScheme.append(AppDelegate.clientIdParam)
        urlScheme.append("&")
        urlScheme.append(AppDelegate.clientSecretParam)
        urlScheme.append("&")
        urlScheme.append(action)
        self.openCustomURLScheme(customURLScheme: urlScheme)
    }
    
    class func openCustomURLScheme(customURLScheme: String) {
        let customURL = URL(string: customURLScheme)!
        if UIApplication.shared.canOpenURL(customURL) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(customURL)
            } else {
                UIApplication.shared.openURL(customURL)
            }
        }
    }
}
