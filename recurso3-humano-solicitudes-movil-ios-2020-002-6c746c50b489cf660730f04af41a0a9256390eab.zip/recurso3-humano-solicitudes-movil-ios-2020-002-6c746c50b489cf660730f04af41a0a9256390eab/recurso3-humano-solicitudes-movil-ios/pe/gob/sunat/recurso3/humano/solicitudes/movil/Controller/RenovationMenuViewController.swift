//
//  RenovationMenuViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/10/20.
//

import UIKit

private let reuseIdentifier = "RenovacionOptionCell"

class RenovationMenuCollectionViewController: ParentViewController {
    

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var authToken : String?
    var options = [RenovationOptionEntity]()
    var enabledOptions = [RenovationOptionEntity]()
    private let spacing:CGFloat = 8.0
    var enabledOptionsIndexes : [Int] = [Int]()

    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate.controllerWithObservers.append(self)
        appDelegate.controllerToClean.append(self)
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        print("Es responsable:" +  String(appDelegate.esResponsable))
        print("Es intendente:" + String(appDelegate.esIntendente))
        
        setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.RENOVATION, leftImage: "iconMenu")
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        }
        
        
        // Register cell classes
        self.collectionView!.register(UINib(nibName: UIRenovacionOptionCollectionViewCell.NAME, bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
        
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        self.collectionView?.collectionViewLayout = layout
        
        let firstOption = RenovationOptionEntity(codOpcion: "01", nomOpcion: "Mis Renovaciones", desOpcion: "", isEnabled: true)
        var intendenteOption = RenovationOptionEntity(codOpcion: "02", nomOpcion: "Evaluar Renovaciones", desOpcion: "", isEnabled: false)
        var responsableOption = RenovationOptionEntity(codOpcion: "03", nomOpcion: "Autorizar Renovaciones", desOpcion: "", isEnabled: false)
        
        if appDelegate.esIntendente {
            intendenteOption.isEnabled = true
        }
        if appDelegate.esResponsable {
            responsableOption.isEnabled = true
        }

        self.options.append(firstOption)
        self.options.append(intendenteOption)
        self.options.append(responsableOption)

        print(appDelegate.renovationOptions)
        
        for option in options {
            if option.isEnabled! {
                self.enabledOptions.append(option)
            }
        }
        
        self.collectionView.reloadData()
        
    }
    

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("print from menu viewDidAppear")
    }
    
    func goToSegue(_ segue: String){
        if canPerformSegue(withIdentifier: segue){
            self.performSegue(withIdentifier: segue, sender: self)
        }else{
            print("Storyboard not exist or not implemented for segue")
        }
    }
}

extension RenovationMenuCollectionViewController : UICollectionViewDelegate , UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    // MARK: UICollectionViewDataSource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print(self.enabledOptions)
        return self.enabledOptions.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! UIRenovacionOptionCollectionViewCell

        let data = self.enabledOptions[indexPath.row]
        
        
        guard let nombreOption = data.nomOpcion , let codOpcion = data.codOpcion else {
            return cell
        }
        let nombreImage = "renovationOption"  + codOpcion
        self.setupContent(cell: cell, title: nombreOption, image: nombreImage)
        return cell
    }
    
    
    func setupContent(cell: UIRenovacionOptionCollectionViewCell, title : String, image : String){
        cell.lblTitleOption.text = title
        var optionImage = UIImage(named: "notificationCircle")
        var tintedImage = optionImage?.withRenderingMode(.alwaysTemplate)
        cell.circleImgOption.image = tintedImage
        if(title == "Autorizar Renovaciones") {
            cell.circleImgOption.tintColor = UIColor(named: "autorizarRenovacionesColor")
        } else if title == "Mis Renovaciones" {
            cell.circleImgOption.tintColor = UIColor(named: "misRenovacionesColor")
        } else if title == "Evaluar Renovaciones" {
            cell.circleImgOption.tintColor = UIColor(named: "evaluarRenovacionesColor")
        }
        
        optionImage = UIImage(named: image)
        tintedImage = optionImage?.withRenderingMode(.alwaysTemplate)
        cell.imgOption.image = tintedImage
        cell.imgOption.tintColor = .white
        if(title == "Autorizar Renovaciones") {
            let parameters = setRenovacionNumberRequest()
            cell.notificationNumberLabel.isHidden = true
            cell.notificationCircle.isHidden = true
            setUpNotificationNumber(parameters: parameters, notificationLabel: cell.notificationNumberLabel, notificationCircle: cell.notificationCircle)
        } else if title == "Evaluar Renovaciones" {
            let parameters = setEvaluarRenovacionNumberRequest()
            cell.notificationNumberLabel.isHidden = true
            cell.notificationCircle.isHidden = true
            setUpNotificationNumber(parameters: parameters, notificationLabel: cell.notificationNumberLabel, notificationCircle: cell.notificationCircle)
        } else {
            cell.notificationNumberLabel.isHidden = true
            cell.notificationCircle.isHidden = true
        }
        
        cell.view.layer.shadowColor = UIColor.gray.cgColor
        cell.view.layer.shadowOpacity = 0.3
        cell.view.layer.shadowOffset = .zero
        //viewContenido.layer.shadowRadius = 8
        cell.view.layer.cornerRadius = 8
        // view.layer.shadowPath = UIBezierPath(rect: view.bounds).cgPath
        cell.view.layer.shouldRasterize = true
        cell.view.layer.rasterizationScale = UIScreen.main.scale
    }
    
    func setUpNotificationNumber(parameters: ObtenerNumeroRenovacionesRequest, notificationLabel: UILabel, notificationCircle: UIImageView) {
        RenovacionMenuOpcionesWorker.getNotificationNumber(with: appDelegate.authorizationToken, parameters: parameters) { (onSuccessResponse) in
            if let cantidadRegistros = onSuccessResponse.httpBody.cantidadregistros {
                if let registros = Int(cantidadRegistros){
                    if registros < 1 {
                        DispatchQueue.main.async {
                            //
                        }
                    } else if (registros > 0 && registros <= 99) {
                        DispatchQueue.main.async {
                            notificationLabel.isHidden = false
                            notificationCircle.isHidden = false
                            notificationLabel.text = String(registros)
                        }
                    } else {

                        DispatchQueue.main.async {
                            notificationLabel.isHidden = false
                            notificationCircle.isHidden = false
                            notificationLabel.text = "+99"
                        }
                    }
                }
            }
        } onFailed: { (onFailed) in
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        } onAuthenticationError: { (onFailedResponse) in
            //
        }

    }
    
    func setRenovacionNumberRequest() -> ObtenerNumeroRenovacionesRequest {
        var request = ObtenerNumeroRenovacionesRequest()
        request.codUOrga = "TODOS"
        request.situaciones = ["03", "08", "09", "10"]
        request.dependencias = "1"
        return request
    }
    
    func setEvaluarRenovacionNumberRequest() -> ObtenerNumeroRenovacionesRequest {
        var request = ObtenerNumeroRenovacionesRequest()
        request.codUOrga = "TODOSINTEN"
        request.situaciones = ["04"]
        request.dependencias = "0"
        return request
    }

    // MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let numberOfItemsPerRow:CGFloat = 2
        let spacingBetweenCells:CGFloat = 8
        
        let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
        
        if let collection = self.collectionView{
            let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
            return CGSize(width: width, height: width * 1.15)
        }else{
            return CGSize(width: 0, height: 0)
        }
    }
    
    // MARK: UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedOption = self.enabledOptions[indexPath.row]
        print(selectedOption.isEnabled!)
        if  selectedOption.isEnabled! {
            print("Se seleccionó una opción")
            switch selectedOption.nomOpcion {
            case "Mis Renovaciones":
                let storyboard = UIStoryboard(name: "FirmarRenovaciones", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "FirmarRenovacionesViewController")
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)
                break
            case "Autorizar Renovaciones":
                let storyboard = UIStoryboard(name: "AutorizarRenovaciones", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "AutorizarRenovacionesViewController") as! AutorizarRenovacionesViewController
                vc.delegate = self
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)
                break
            case "Evaluar Renovaciones":
                let storyboard = UIStoryboard(name: "EvaluarRenovaciones", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "EvaluarRenovaciones") as! EvaluarRenovacionesViewController
                vc.delegate = self
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)
                break
            default:
                break
            }
            
        } else if AppConstants.OPTIONS_WITH_ALERT_FROM_BOTTON_PRESENTATION.contains(selectedOption.codOpcion ?? AppConstants.VALUES.EMPTY) {
            let selectedOptionAsEnum = MenuOptionEnum(rawValue: MenuOption(stringLiteral: (selectedOption.codOpcion ?? "") + ",_"))
            switch selectedOptionAsEnum {
            default:
                break
            }
        }
    }
}

//MARK: EXTENSIONS - HeaderViewDelegate
extension RenovationMenuCollectionViewController: HeaderViewDelegate {
    
    func actionLeft() {
        self.openMenu()
    }
    
}


extension RenovationMenuCollectionViewController: AutorizarRenovacionesViewControllerDelegate {
    func windowWasClosed() {
        print("reloaded data")
        self.collectionView.reloadData()
    }
}

extension RenovationMenuCollectionViewController: EvaluarRenovacionesViewControllerDelegate {
    func evaluateFinished() {
        print("reloaded data")
        self.collectionView.reloadData()
    }
}

extension RenovationMenuCollectionViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        //self.retrieveRenovations()
    }
}
