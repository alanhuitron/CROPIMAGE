//
//  GetSituacionesResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/28/20.
//

import Foundation

struct GetSituacionesResponse : Decodable {
    var httpResponse = BaseResponse()
    var httpBody = GetSituacionesResponseBody()
}
