//
//  CellEntity.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class CellEntity: NSObject {
    
    let code: String!
    let name: String!
    let img: UIImage!
    
    public var selected = false
    
    init(code: String, name: String, img: UIImage) {
        self.code = code
        self.name = name
        self.img = img
    }
}
