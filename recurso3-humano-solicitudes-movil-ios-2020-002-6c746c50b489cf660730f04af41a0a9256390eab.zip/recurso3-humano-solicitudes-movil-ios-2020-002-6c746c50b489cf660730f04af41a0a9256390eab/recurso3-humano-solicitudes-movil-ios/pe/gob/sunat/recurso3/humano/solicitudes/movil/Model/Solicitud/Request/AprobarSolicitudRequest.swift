//
//  AprobarSolicitudRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/12/19.
//

import Foundation

struct AprobarSolicitudRequest : Codable {
    
    var codPersonaSolicitud : String?
    var annSolicitud : String?
    var numSolicitud : String?
    var nroRegistroAprobador : String?
    var codLoginAprobador : String?
    var desMensajeAprobacion : String?
    var numLatitud : String?
    var numLongitud : String?
    var solicitudes : [Solicitud]?
}

