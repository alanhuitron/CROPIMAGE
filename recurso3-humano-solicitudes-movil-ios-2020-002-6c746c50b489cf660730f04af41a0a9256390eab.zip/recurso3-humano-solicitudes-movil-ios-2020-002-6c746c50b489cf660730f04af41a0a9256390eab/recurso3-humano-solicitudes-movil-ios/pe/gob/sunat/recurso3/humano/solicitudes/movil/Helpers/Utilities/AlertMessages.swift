//
//  AlertMessages.swift
//  TemplateSwift
//
//  Created by Fernando Mateo Ramos on 12/04/17.
//  Copyright © 2017 Fernando Mateo Ramos. All rights reserved.
//

import UIKit

class AlertMessages: NSObject {
    
    
    struct Alert {
        
        static let NOINTERNET = "No tiene conexión a internet"
        
        /*static let TITLE = "TemplateSwift"
        static let QUESTION = "¿Seguro que desea realizar esta llamada?"
        static let CANCEL = "Cancelar"
        static let ACCEPTCALL = "Llamar"
        static let ACCEPT = "Aceptar"
        static let OK = "Ok"
        static let DENIED = "No"
        static let APPROVE = "Si"
        
        static let MS_CLOSESESSION = "Desea cerrar sesión"
        */
        
    }
    struct UserActions {
        static let DEFAULT_TITLE = "Solicitud Móvil"
    }
    
}
