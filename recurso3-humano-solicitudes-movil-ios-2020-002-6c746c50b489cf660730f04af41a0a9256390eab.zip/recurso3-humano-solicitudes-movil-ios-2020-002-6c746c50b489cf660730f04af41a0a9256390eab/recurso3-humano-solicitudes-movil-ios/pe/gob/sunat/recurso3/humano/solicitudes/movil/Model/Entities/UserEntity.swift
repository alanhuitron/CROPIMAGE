//
//  UserEntity.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class UserEntity: NSObject {
    var name :  String = ""
    var email:  String = ""
    var registryNumber = ""
    var userName = ""
    var roles = [String:String]()
}
