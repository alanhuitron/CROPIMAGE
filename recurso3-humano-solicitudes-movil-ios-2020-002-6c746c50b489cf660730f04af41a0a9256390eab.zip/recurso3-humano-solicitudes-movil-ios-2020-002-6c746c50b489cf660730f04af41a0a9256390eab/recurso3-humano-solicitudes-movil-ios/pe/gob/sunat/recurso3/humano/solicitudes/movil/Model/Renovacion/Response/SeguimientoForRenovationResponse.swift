//
//  SeguimientoForRenovationResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/27/20.
//

import Foundation

struct SeguimientoForRenovationResponse : Codable {
    var httpResponse = BaseResponse()
    var httpBody = SeguimientoForRenovationResponseBody()
}
