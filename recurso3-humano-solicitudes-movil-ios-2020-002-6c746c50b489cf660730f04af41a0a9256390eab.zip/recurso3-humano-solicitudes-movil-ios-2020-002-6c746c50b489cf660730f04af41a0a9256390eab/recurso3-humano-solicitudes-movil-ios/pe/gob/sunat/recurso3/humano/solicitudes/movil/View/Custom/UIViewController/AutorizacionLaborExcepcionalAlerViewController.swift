//
//  AutorizacionLaborExcepcionalAlerViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 1/8/20.
//

import UIKit

class AutorizacionLaborExcepcionalAlerViewController: UIViewController {

    @IBOutlet weak var lblFechaAutorizacion: UILabel!
    @IBOutlet weak var lblHoraInicio: UILabel!
    @IBOutlet weak var lblHoraFin: UILabel!
    @IBOutlet weak var lblAsunto: UILabel!
    @IBOutlet weak var viewContainer: BorderView!
    @IBOutlet var viewParent: UIView!
    
    var fechaAutorizacion : String?
    var horaInicio : String?
    var horaFin : String?
    var asunto : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.viewContainer.layer.cornerRadius = 20
        
        let tapGestureRecognizerForNoAction = UITapGestureRecognizer(target: self, action: #selector(singleTapNoAction))
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(singleTap))
        self.viewParent.addGestureRecognizer(tapGestureRecognizer)
        self.viewContainer.addGestureRecognizer(tapGestureRecognizerForNoAction)
        
        self.setup()
    }
    
    func setup(){
        self.lblAsunto.text = self.asunto
        self.lblHoraFin.text = self.horaFin
        self.lblHoraInicio.text = self.horaInicio
        self.lblFechaAutorizacion.text = self.fechaAutorizacion
    }

    @objc func singleTap(recognizer: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func singleTapNoAction(recognizer: UITapGestureRecognizer) { }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
