//
//  TrackingDetailViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/6/19.
//

import UIKit

class DetalleSeguimientoViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var lblIssuer: UILabel!
    @IBOutlet weak var lblAddressee: UILabel!
    @IBOutlet weak var lblReceptionDate: UILabel!
    @IBOutlet weak var lblActionDescription: UILabel!
    @IBOutlet weak var lblObservation: UILabel!
    
    var applicationParametersForTrackingDetail : Solicitud?
    var trackingParametersForTrackingDetail : Seguimiento?
    var tracking : Seguimiento?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.TRACKING_DETAIL, leftImage: "iconLeft")
        
        if let trackingParameters = trackingParametersForTrackingDetail, let applicationParameters = applicationParametersForTrackingDetail {
            let request = prepareTrackingRequestForDetail(trackingParams: trackingParameters, applicationParams: applicationParameters)
            self.retrieveTrackingDetail(using: appDelegate.authorizationToken, forUser: self.appDelegate.currentUser.registryNumber, with: request)
            
        }
    }
    
    func prepareTrackingRequestForDetail(trackingParams : Seguimiento, applicationParams : Solicitud) -> SeguimientoRequest{
        var request = SeguimientoRequest()
        request.codPersona=applicationParams.codPersona
        request.numSolicitud=String(applicationParams.numSolicitud!)
        request.annSolicitud=applicationParams.annSolicitud
        request.numSeguimiento=String(trackingParams.numSeguimiento!)
        return request
    }
    
    func retrieveTrackingDetail(using token: String, forUser userRegistryNum : String ,with request: SeguimientoRequest){
        self.showSpinner(onView: self.view)
        SeguimientoWorker.getDetailTracking(with: token, forUser: userRegistryNum, parameters: request, onSuccess: { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.tracking = onSuccessResponse.httpBody.seguimiento!
                self.lblIssuer.text = self.tracking?.nomRemitente
                self.lblAddressee.text = self.tracking?.nomDestinatario
                self.lblReceptionDate.text = self.tracking?.fecRecepcion
                self.lblObservation.text = self.tracking?.desObservacion
                self.lblActionDescription.text = self.tracking?.desAccion
                self.removeSpinner()
                
            }
        }, onFailed: {(onFailed) in
            //FIXME: implement action
            self.removeSpinner()
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        })
    }

}

extension DetalleSeguimientoViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goBackMore()
    }
    
}
