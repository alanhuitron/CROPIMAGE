//
//  UIPickerText.swift
//  AppPrecintos
//
//  Created by MOJAVE on 10/5/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

protocol UIPickerTextFieldDelegate {
    
     func pickerTextFieldDidBeginEditing(_ textField: UITextField)
}
extension UIView
{
    func copyView() -> UIView?
    {
        return NSKeyedUnarchiver.unarchiveObject(with: NSKeyedArchiver.archivedData(withRootObject: self)) as? UIView
    }
}
class UIPickerText: UITextField, UITextFieldDelegate{

    var customPicker : PickerView!
    var pickerTextDelegate : UIPickerTextFieldDelegate?
    
    //MARK: LIFECYCLE
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        //self.placeholder = "Seleccione"
        self.setupPickerIcon()
    }
    
    //MARK: DELEGATE METHODS
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
    
    //MARK: METHODS
    func loadDropdown(data: [CodeValueEntity]) {
        customPicker = PickerView(pickerData: data, dropdownField: self)
        self.inputView = customPicker
    }
    
    func selectElementAt(index: Int) {
        customPicker.selectRow(index, inComponent: 0, animated: true)
    }

    func getValueSelected() -> CodeValueEntity {
        return customPicker.currentRow
    }
    
    func setupPickerIcon() {
        /*let frameWidth = self.frame.height
        
        let pickerIcon = UIImage(named: "iconDown");
        let imageView = UIImageView();
        
        
        // set frame on image before adding it to the uitextfield
        imageView.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(5), height: CGFloat(5))
        //imageView.backgroundColor = UIColor.green
        
        imageView.clipsToBounds = true
        imageView.contentMode = UIView.ContentMode.scaleAspectFit
        
        imageView.image = pickerIcon;
        
        self.tintColor = .black
        self.rightViewMode = UITextField.ViewMode.always
        self.rightView = imageView
        imageView.image = self.resizeImage(image: pickerIcon!, targetSize: CGSize(width: frameWidth-2, height: frameWidth-2));
        
        */
        
    }
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size

        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height

        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }

        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
    
    
    func customizeBorder(color : UIColor, width : CGFloat){
        customizeBorder(color : color, width : width, cornerRadius : nil)
    }
    
    func customizeBorder(color : UIColor, width : CGFloat, cornerRadius : CGFloat?){
        if let corner = cornerRadius {
            self.layer.cornerRadius = corner
        }
        self.layer.borderColor = color.cgColor
        self.layer.borderWidth = width
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if let _ = self.pickerTextDelegate {
            self.pickerTextDelegate?.pickerTextFieldDidBeginEditing(textField)
        }
    }
    
    
}

