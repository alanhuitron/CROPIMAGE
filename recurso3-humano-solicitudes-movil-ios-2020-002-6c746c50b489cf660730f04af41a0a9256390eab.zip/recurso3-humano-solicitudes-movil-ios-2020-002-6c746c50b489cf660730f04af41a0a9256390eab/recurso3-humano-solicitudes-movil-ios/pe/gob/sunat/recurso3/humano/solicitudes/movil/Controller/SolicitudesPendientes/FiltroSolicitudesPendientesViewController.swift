//
//  FiltroSolicitudesPendientesViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/13/19.
//

import UIKit

protocol FiltroSolicitudesPendientesViewControllerDelegate {
    
    func filtersWereApplied(filteredApplications : [Solicitud]?)
    func cleanWasApplied()
    
}

class FiltroSolicitudesPendientesViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var txtCriterionData: UITextField!
    @IBOutlet weak var txtCriterionDataDate: UITextField!
    @IBOutlet weak var cbxApplicationType: UIPickerText!
    @IBOutlet weak var cbxCriterionType: UIPickerText!
    @IBOutlet weak var btnApply: UIButton!
    @IBOutlet weak var btnClean: UIButton!
    
    var delegate : FiltroSolicitudesPendientesViewControllerDelegate?
    var applicationTypeCode : String?
    var criterionCode : String?
    var criterionData : String?
    
    let datePickerFecha = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeaderView(self.headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.PENDING_APPLICATION, leftImage: "iconLeft")
        
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0.0, y: 75 - 1, width: 300, height: 1.0)
        bottomLine.backgroundColor = UIColor.white.cgColor
        txtCriterionData.borderStyle = .none
        txtCriterionData.layer.addSublayer(bottomLine)
        txtCriterionData.delegate = self
        txtCriterionDataDate.delegate = self
        
        self.cbxApplicationType.customizeBorder(color: UIColor(netHex: 0x1976D2), width: 2, cornerRadius: 3)
        self.cbxCriterionType.customizeBorder(color: UIColor(netHex: 0x1976D2), width: 2, cornerRadius: 3)
        
        initDatePicker(fechaDatePicker: datePickerFecha,  textFecha : txtCriterionDataDate)
        datePickerFecha.addTarget(self , action: #selector(self.dateChanged(datePicker:)    ), for: .valueChanged)
        
        self.setup()
    }
    
    @IBAction func applyFilters(_ sender: Any) {
        self.txtCriterionData.resignFirstResponder()
        self.txtCriterionDataDate.resignFirstResponder()
        var haveFilters = false
        if let _ = applicationTypeCode {
            haveFilters = true
        } else if let _ = criterionCode , let _ = criterionData {
            if !criterionData!.isEmpty {
                haveFilters = true
            }
        }
        
        if !haveFilters {
            UserAlerts.showAlertMessage(on: self, message: "Debe ingresar un filtro de búsqueda")
        }else{
            let request = prepareApplicationRequest()
            self.retrieveFilteredPendingApplications(using: appDelegate.authorizationToken, with: request)
        }
    }
    
    @IBAction func cleanFilters(_ sender: Any) {
        self.cbxApplicationType.text = nil
        self.applicationTypeCode = nil
        self.cbxCriterionType.text = nil
        self.criterionCode = nil
        self.cleanCriteriaData()
        self.delegate?.cleanWasApplied()
        self.goBackMore()
    }
    
    func cleanCriteriaData(){
        self.txtCriterionData.text = nil
        self.txtCriterionDataDate.text = nil
        self.criterionData = nil
    }
    
    func initDatePicker (fechaDatePicker : UIDatePicker , textFecha : UITextField ){
        let localeID = Locale.preferredLanguages.first
        fechaDatePicker.locale = Locale(identifier: localeID!)
        fechaDatePicker.datePickerMode = .date
        textFecha.inputView = fechaDatePicker
        _ = UITapGestureRecognizer(target: self, action: #selector(tapGestureDone))
      
    }
    
    @objc func tapGestureDone () {
      view.endEditing(true)
    }
    
    @objc func dateChanged (datePicker : UIDatePicker ) {
        let dateFormatter = DateFormatter ()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        txtCriterionDataDate.text = dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    func setup() {
        var applicationTypes = [CodeValueEntity]()
        let applicationCriteria = [
            CodeValueEntity(code: ApplicationCriterion.numSolicitud.rawValue, value: "Número"),
            CodeValueEntity(code: ApplicationCriterion.desAsunto.rawValue, value: "Asunto"),
            CodeValueEntity(code: ApplicationCriterion.fecRegistroAntes.rawValue, value: "Registrada antes del"),
            CodeValueEntity(code: ApplicationCriterion.codEmisor.rawValue, value: "Emisor (Código de registro)"),
            CodeValueEntity(code: ApplicationCriterion.fecDerivadaAntes.rawValue, value: "Derivada antes del"),
            CodeValueEntity(code: ApplicationCriterion.codUltimoResponsable.rawValue, value: "Último Responsable")
        ]
        
        self.cbxCriterionType.loadDropdown(data: applicationCriteria)
        self.cbxCriterionType.customPicker.pickerViewDelegate = self
        
        
        self.showSpinner(onView: self.view)
        SolicitudWorker.getApplicationTypes(with: appDelegate.authorizationToken, forUser: self.appDelegate.currentUser.registryNumber, onSuccess: { (onSuccessResponse) in
            DispatchQueue.main.async {
                let types = onSuccessResponse.httpBody.tiposSolicitud!
                for type in types {
                    let codValue = CodeValueEntity(code: type.codDataParametro!, value: type.desParametro!)
                    applicationTypes.append(codValue)
                }
                self.cbxApplicationType.loadDropdown(data: applicationTypes)
                self.cbxApplicationType.customPicker.pickerViewDelegate = self
                self.removeSpinner()
            }
        }, onFailed: {(onFailed) in
            self.removeSpinner()
                //FIXME: implement action
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    func prepareApplicationRequest()->SolicitudRequest{
        var request = SolicitudRequest()
        request.codPersona=self.appDelegate.currentUser.registryNumber
        
        var parametrosDeBusqueda = ParametrosBusqueda()
        parametrosDeBusqueda.codTipo = applicationTypeCode
        if let _ = criterionCode {
            let criterion = ApplicationCriterion.init(rawValue: criterionCode!)
            switch criterion {
            case .numSolicitud : parametrosDeBusqueda.numSolicitud = criterionData
            case .desAsunto : parametrosDeBusqueda.desAsunto = criterionData
            case .fecRegistroAntes : parametrosDeBusqueda.fecRegistroAntes = criterionData
            case .fecDerivadaAntes : parametrosDeBusqueda.fecDerivadaAntes = criterionData
            case .codEmisor : parametrosDeBusqueda.codEmisor = criterionData
            case .codUltimoResponsable : parametrosDeBusqueda.codUltimoResponsable = criterionData
            default:
                break
            }
        }
        
        request.parametrosBusqueda = parametrosDeBusqueda
        return request
    }
    
    func retrieveFilteredPendingApplications(using token: String, with request: SolicitudRequest){
        SolicitudWorker.getPendingRequests(with: token, parameters: request, onSuccess: { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.delegate?.filtersWereApplied(filteredApplications: onSuccessResponse.httpBody.solicitudes)
                self.goBackMore()
            }
        }, onFailed: {(onFailedResponse) in
            //FIXME: implement
            
        }, onAuthenticationError: {(onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        })
    }
}


extension FiltroSolicitudesPendientesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goBackMore()
    }
    
}

extension FiltroSolicitudesPendientesViewController : PickerViewDelegate {
    func pickerViewDidSelectRow(_ pickerView: UIPickerView) {
        switch pickerView {
        case self.cbxApplicationType.customPicker:
            self.applicationTypeCode = cbxApplicationType.customPicker.currentRow.code
        case self.cbxCriterionType.customPicker:
            self.criterionCode = cbxCriterionType.customPicker.currentRow.code
            let criterion = ApplicationCriterion.init(rawValue: criterionCode!)
            switch criterion {
            case .numSolicitud :
                self.txtCriterionData.keyboardType = .numberPad
                self.txtCriterionData.isHidden = false
                self.txtCriterionDataDate.isHidden = true
                self.cleanCriteriaData()
            case .desAsunto, .codEmisor, .codUltimoResponsable :
                self.txtCriterionData.keyboardType = .default
                self.txtCriterionData.isHidden = false
                self.txtCriterionDataDate.isHidden = true
                self.cleanCriteriaData()
            case .fecRegistroAntes, .fecDerivadaAntes :
                self.txtCriterionData.isHidden = true
                self.txtCriterionDataDate.isHidden = false
                self.cleanCriteriaData()
            default:
                break
            }
        default:
            break
        }
    }
}

extension FiltroSolicitudesPendientesViewController : UITextFieldDelegate {
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case txtCriterionData, txtCriterionDataDate:
            criterionData = nil
        default:
            break
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case txtCriterionData, txtCriterionDataDate:
            criterionData = textField.text
        default:
            break
        }
    }
}


enum ApplicationCriterion : String{
    case numSolicitud = "numSolicitud"
    case desAsunto = "desAsunto"
    case fecRegistroAntes = "fecRegistroAntes"
    case fecDerivadaAntes = "fecDerivadaAntes"
    case codEmisor = "codEmisor"
    case codUltimoResponsable = "codUltimoResponsable"
    
}
