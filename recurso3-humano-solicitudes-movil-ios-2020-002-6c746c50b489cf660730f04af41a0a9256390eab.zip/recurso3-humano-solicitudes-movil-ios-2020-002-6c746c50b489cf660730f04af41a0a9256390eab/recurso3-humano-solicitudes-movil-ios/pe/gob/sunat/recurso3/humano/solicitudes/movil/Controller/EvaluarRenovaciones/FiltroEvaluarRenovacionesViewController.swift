//
//  FiltroEvaluarRenovaciones.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/30/20.
//

import Foundation
import UIKit

protocol FiltroEvaluarRenovacionesViewControllerDelegate {
    
    func filtersWereApplied(filteredRenovations : [Renovacion]?)
    
    func cleanFiltersRenovacion()
    
}

class FiltroEvaluarRenovacionesViewController : ParentViewController {
    
    @IBOutlet weak var headerNavigationBarView: UIView!
    
    @IBOutlet weak var cbxUUOO: UIPickerText!
    
    @IBOutlet weak var checkBox: UICheckboxControl!
    
    @IBOutlet weak var UUOOLabel: UILabel!
    
    @IBOutlet weak var applyFiltersButton: UIButton!
    var UUOOCode: String?
    var incluirUUOODependientes: String?
    var UUOOs = [CodeValueEntity]()
    
    var delegate : FiltroEvaluarRenovacionesViewControllerDelegate?
    let alerts = ToastAlerts()
    
    override func viewDidLoad() {
    super.viewDidLoad()
        self.UUOOCode = "TODOSINTEN"
        self.setHeaderView(self.headerNavigationBarView, viewController: self, title: "Evaluar Renovaciones", leftImage: "iconLeft")
        self.UUOOLabel.isHidden = true
        self.cbxUUOO.delegate = self
        self.cbxUUOO.resignFirstResponder()
        self.cbxUUOO.customizeBorder(color: UIColor(named: "appColor")!, width: 2, cornerRadius: 3)
        
        self.cbxUUOO.text = "TODAS LAS UNIDADES ORGÁNICAS"
        self.checkBox.borderStyle = .square
        self.checkBox.style = .tick
        self.checkBox.isChecked = false
        self.checkBox.isHidden = true
        self.setup()
        self.hideKeyboardWhenTappedAround()
    }
    
    func cleanData(){
        self.cbxUUOO.text = nil
        self.UUOOCode = nil
    }
    
    
    @IBAction func aplicarFiltro(_ sender: Any) {
        
        var haveFilters = false
        if let _ = UUOOCode {
            haveFilters = true
        }

        
        if !haveFilters {
            UserAlerts.showAlertMessage(on: self, message: "Debe ingresar un filtro de búsqueda")
        }else{
            let request = prepareRenovationRequest()
            self.retrieveFilteredRenovations(using: appDelegate.authorizationToken, with: request)
        }
        
        DispatchQueue.main.async {
            self.applyFiltersButton.isEnabled = false
        }
    }
    
    
    func setup() {
        
        let codValue = CodeValueEntity(code: "TODOSINTEN", value: "TODAS LAS UNIDADES ORGÁNICAS")
        self.UUOOs.append(codValue)
        
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionWorker.getIntendenteUUOO(with: appDelegate.authorizationToken, with: autorizacionbean, with: appDelegate.currentUser.registryNumber) { (onSuccessResponse) in
            DispatchQueue.main.async {
                let UUOOsArray = onSuccessResponse
                for UUOO in UUOOsArray {
                    let codValue = CodeValueEntity(code: UUOO.t12codUorga!, value: UUOO.t12desUorga!)
                    self.UUOOs.append(codValue)
                }
                self.cbxUUOO.loadDropdown(data: self.UUOOs)
                self.cbxUUOO.customPicker.pickerViewDelegate = self
                self.removeSpinner()
            }
        } onFailed: { (onFailed) in
            self.removeSpinner()
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        } onAuthenticationError: { (onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }
    
    
    func prepareRenovationRequest()->ObtenerRenovacionesRequest{
        var request = ObtenerRenovacionesRequest()
        if let codUOrga = UUOOCode {
            request.codUOrga = codUOrga
        }
        request.codSituacion = "04"
        
        if checkBox.isChecked {
            request.dependencias = "1"
        } else {
            request.dependencias = "0"
        }
        
        return request
    }
    
    
    func retrieveFilteredRenovations(using token: String, with request: ObtenerRenovacionesRequest){
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        
        RenovacionWorker.getRenovations(with: token, with: autorizacionbean, parameters: request) { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.delegate?.filtersWereApplied(filteredRenovations: onSuccessResponse.httpBody.renovaciones)
                
                    self.applyFiltersButton.isEnabled = true
                
                self.goBackMore()
            }
        } onFailed: { (onFailedResponse) in
            DispatchQueue.main.async {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                self.applyFiltersButton.isEnabled = true
            }
        } onAuthenticationError: { (onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension FiltroEvaluarRenovacionesViewController : UITextFieldDelegate {
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case cbxUUOO:
            //criterionData = nil
        break
        default:
            break
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case cbxUUOO:
            //self.UUOO = textField.text
        break
        default:
            break
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
}

extension FiltroEvaluarRenovacionesViewController : PickerViewDelegate {
    func pickerViewDidSelectRow(_ pickerView: UIPickerView) {
        switch pickerView {
        case self.cbxUUOO.customPicker:
            self.UUOOCode = cbxUUOO.customPicker.currentRow.code
            if cbxUUOO.customPicker.currentRow.code != "TODOSINTEN" {
                DispatchQueue.main.async {
                    self.checkBox.isHidden = false
                    self.UUOOLabel.isHidden = false
                }
            } else {
                DispatchQueue.main.async {
                    self.checkBox.isHidden = true
                    self.UUOOLabel.isHidden = true
                }
            }
            break
        default:
            break
        }
    }
}


extension FiltroEvaluarRenovacionesViewController: HeaderViewDelegate{

    func actionLeft() {
       self.goBackMore()
    }
}
