//
//  UserData.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/22/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct AuthorizationUserData : Codable{
    
    var nroRegistro = String()
    var nombreCompleto = String()
    var correo = String()
    var login = String()
    
    private enum CodingKeys: String, CodingKey {
        case nroRegistro
        case nombreCompleto
        case correo
        case login
    }
    
    static func retrieveRoles(data : Data) -> [String : String]{
        var roles = [String : String]()
        do {
            let responseJSON = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as AnyObject?
            let objDic : [String: AnyObject] = responseJSON as! [String: AnyObject]
            
            //TODO: Refactor
            if let mapValue = objDic["userdata"] as?  [String: AnyObject]{
                for item in mapValue {
                    if item.key == "map" {
                        if let mapValue = item.value as?  [String: AnyObject] {
                            for item  in mapValue {
                                if item.key == "roles" {
                                    if let rolValue = item.value as?  [String: AnyObject] {
                                        for item in rolValue {
                                            roles[item.key] = item.value as? String ?? ""
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                print ("El usuario no tiene roles")
            }
        } catch {
            print (": Error al parsear JSON de la respuesta")
        }
        return roles
    }
    
   
}
