//
//  MenuCell.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class MenuCell: UITableViewCell {

    @IBOutlet weak var menuDescription: UILabel!
    @IBOutlet weak var menuIcon:        UIImageView!
    @IBOutlet weak var viewIcon:        UIView!
    var menuCode : String?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    public func setUpCell(entity: CellEntity){
        self.menuCode = entity.code
        self.menuDescription!.text = entity.name
        self.menuIcon.image = entity.img
        if(entity.selected){
            self.selectDefaultRow(image: entity.img)
        }else{
            self.deselectRow(image: entity.img)
        }
    }
    
    public func selectDefaultRow(image: UIImage) {
        self.menuIcon.image = image
        self.menuIcon.tintColor = UIColor(hexString: "#1976D2")
        self.menuDescription.textColor = UIColor(hexString: "#1976D2")
        self.backgroundColor = UIColor(hexString: "#DCDCDC")
        //self.menuIcon.tintColor = UIColor.FlatColor.Red.Cinnabar
        //self.menuDescription.textColor = UIColor.FlatColor.Red.Cinnabar
    }
    
    public func deselectRow(image: UIImage) {
        self.menuIcon.image = image
        self.menuIcon.tintColor = UIColor.gray
        self.menuDescription.textColor = UIColor.black
        self.backgroundColor = .white
    }
}
