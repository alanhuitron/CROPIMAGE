//
//  DateUtils.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/15/19.
//

import Foundation

class DateUtils {
    
    static let dd_MM_yyyy_HH_mm_ss_withSlashFormat = "dd/MM/yyyy HH:mm:ss"
    static let dd_MM_yyyy_withSlashFormat = "dd/MM/yyyy"
    static let yyyy_MM_dd_withHyphenFormat = "yyyy-MM-dd"
    
    static func convert(dateString: String?, from originalFormat: String) -> Date?{
        guard let safeDateString = dateString else {
            return nil
        }
        let dateStringFormatter = DateFormatter()
        dateStringFormatter.dateFormat = originalFormat
             
        guard let dateWithOriginalFormat = dateStringFormatter.date(from: safeDateString) else {
            return nil
        }
        return dateWithOriginalFormat
    }
    
    static func convert(dateString: String, from originalFormat: String, to newFormat: String) -> String?{
        let dateStringFormatter = DateFormatter()
        dateStringFormatter.dateFormat = originalFormat
             
        guard let dateWithOriginalFormat = dateStringFormatter.date(from: dateString) else {
            return nil
        }
        
        dateStringFormatter.dateFormat = newFormat
        return dateStringFormatter.string(from: dateWithOriginalFormat)
        
    }
    
    static func convert(dateString: String, from originalFormat: String, with style: DateFormatter.Style) -> String?{
        let dateStringFormatter = DateFormatter()
        dateStringFormatter.dateFormat = originalFormat
             
        guard let dateWithOriginalFormat = dateStringFormatter.date(from: dateString) else {
            return nil
        }
        dateStringFormatter.dateStyle = style;
        dateStringFormatter.doesRelativeDateFormatting = true;

        return dateStringFormatter.string(from: dateWithOriginalFormat)
        
    }
    
    @available(iOS 13.0, *)
    static func convert(dateString: String, from originalFormat: String, with style: RelativeDateTimeFormatter.DateTimeStyle) -> String?{
        let dateStringFormatter = DateFormatter()
        dateStringFormatter.dateFormat = originalFormat
             
        guard let dateWithOriginalFormat = dateStringFormatter.date(from: dateString) else {
            return nil
        }
        
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale.init(identifier: "es_ES")
        formatter.dateTimeStyle = style

        return formatter.localizedString(for: dateWithOriginalFormat, relativeTo: Date())
        
    }
    
    static func interval(ofComponent comp: Calendar.Component, fromDate date: Date) -> Int {

        let currentCalendar = Calendar.current

        guard let start = currentCalendar.ordinality(of: comp, in: .era, for: date) else { return 0 }
        guard let end = currentCalendar.ordinality(of: comp, in: .era, for: Date()) else { return 0 }

        return end - start
    }

    static func interval(ofComponent comp: Calendar.Component, futureDate date: Date) -> Int {

        let currentCalendar = Calendar.current

        guard let start = currentCalendar.ordinality(of: comp, in: .era, for: Date()) else { return 0 }
        guard let end = currentCalendar.ordinality(of: comp, in: .era, for: date) else { return 0 }

        return end - start
    }
    
    
}
