//
//  SeguimientoRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation

struct SeguimientoRequest:Codable {

    var codPersona : String?
    var annSolicitud : String?
    var numSolicitud : String?
    var numSeguimiento : String?
}
