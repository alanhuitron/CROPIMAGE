//
//  ParentViewController.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

import MapKit
import CoreLocation

class ParentViewController: UIViewController {

    public let appDelegate = UIApplication.shared.delegate as! AppDelegate
    public let locationManager = CLLocationManager()
    
    var vSpinner : UIView?
    var isShowingSpinner = false
    var defaults = UserDefaults.standard
    var goneToMainScreen : Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default .addObserver(self, selector: #selector(statusManager), name: .flagsChanged, object: nil)
        goneToMainScreen = defaults.bool(forKey: "goneToMainScreen")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.startLocalizationServiceListener()
    }
    
    
    func startLocalizationServiceListener(){
        if CLLocationManager.locationServicesEnabled() {
            print("starting location service from parent")
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
    func checkLocalizationServiceAndTakeActions(){
        if CLLocationManager.locationServicesEnabled() {
            let alertController = UIAlertController(title: AppMessages.SYSTEM.LOCALIZATION_TITLE, message: AppMessages.SYSTEM.LOCALIZATION_MESSAGE, preferredStyle: .alert)
            let settingsAction = UIAlertAction(title: AppConstants.BUTTON.SETTING, style: .default) { (_) -> Void in
                guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                    return
                }
                if UIApplication.shared.canOpenURL(settingsUrl) {
                    UIApplication.shared.open(settingsUrl, completionHandler: { (success) in })
                }
            }
            let cancelAction = UIAlertAction(title: AppConstants.BUTTON.CANCEL, style: .default, handler: nil)
            alertController.addAction(cancelAction)
            alertController.addAction(settingsAction)

            switch(CLLocationManager.authorizationStatus()) {
                case .authorizedAlways, .authorizedWhenInUse:
                    print("Ya se cuenta con servicios de localizacion.")

                case .notDetermined, .restricted, .denied:
                    print("No se cuenta con servicios de localizacion, lanzando alerta ...")
                    self.present(alertController, animated: true, completion: nil)
            @unknown default:
                break
            }
        }
    }
    
    func areLocationServicesEnableToThisApp() -> Bool{
        var areEnable = false
        if CLLocationManager.locationServicesEnabled() {
            switch(CLLocationManager.authorizationStatus()) {
                case .authorizedAlways, .authorizedWhenInUse:
                    areEnable = true
                case .notDetermined, .restricted, .denied:
                    break;
            @unknown default:
                break
            }
        }
        return areEnable
    }
    
    func preferredStatusBarStyle() -> UIStatusBarStyle  {
        return UIStatusBarStyle.default
    }
    
    
    func updateUserInterfaceOwn() {
        switch Network.reachability.status {
        case .unreachable:
            //showDialogMessage(title: "Error", message: AlertMessages.Alert.NOINTERNET)
            let alert = UIAlertController(title: "Error", message: AlertMessages.Alert.NOINTERNET, preferredStyle: .alert)
            let action = UIAlertAction(title: "Cerrar", style: .default) { (action) -> Void in
                self.navigationController?.popToRootViewController(animated: true)
            }
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
        case .wwan, .wifi:
            break
        }

    }
    @objc func statusManagerOwn(_ notification: Notification) {
        updateUserInterfaceOwn()
    }
    
    public func openMenu(){
        if let drawerController = self.parent as? KYViewController {
            drawerController.setDrawerState(.opened, animated: true)
        } else if let drawerController = self.parent?.parent as? KYViewController {
            drawerController.setDrawerState(.opened, animated: true)
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    
    public func goSearch(){
        
        
    }
    
    
    public func goBack() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    public func goBackMore(){
        self.dismiss(animated: true,completion: nil)
    }

    public func moreOptions(){
        print("Entró al método moreOptions")
    }

    public func setHeaderView(_ childView: UIView, viewController: UIViewController, title: String, leftImage: String){
        let headerView = HeaderView.instanceFromNib() as! HeaderView
        headerView.frame = childView.bounds
        headerView.delegate = (viewController as! HeaderViewDelegate)
        headerView.setTitle(text: title)
        headerView.setLeftImage(imageName: leftImage)
        headerView.setRightImage(imageName: "")
        headerView.setRightImage2(imageName: "")
        childView.addSubview(headerView)
    }
    
    
    public func setHeaderView(_ childView: UIView, viewController: UIViewController, title: String, leftImage: String, rightImage: String, rightImage2: String){
        let headerView = HeaderView.instanceFromNib() as! HeaderView
        headerView.frame = childView.bounds
        headerView.delegate = (viewController as! HeaderViewDelegate)
        headerView.setTitle(text: title)
        headerView.setLeftImage(imageName: leftImage)
        headerView.setRightImage(imageName: rightImage)
        headerView.setRightImage2(imageName: rightImage2)
        headerView.viewOptionMore.isHidden = true
            
        
        childView.addSubview(headerView)
    }
    
    
    public func setHeaderViewForPDFDownload(_ childView: UIView, viewController: UIViewController, title: String, leftImage: String, rightImage: String){
        let headerView = HeaderView.instanceFromNib() as! HeaderView
        headerView.frame = childView.bounds
        headerView.delegate = (viewController as! HeaderViewDelegate)
        headerView.setTitle(text: title)
        headerView.setLeftImage(imageName: leftImage)
        let originalImage = UIImage(named: rightImage)
        let tintedImage = originalImage?.withRenderingMode(.alwaysTemplate)
        headerView.ivRight.image = tintedImage
        headerView.ivRight.tintColor = .white
        headerView.viewOptionMore.isHidden = false
        headerView.ivRight_0.isUserInteractionEnabled = false
        headerView.ivRight_0.isHidden = true
        
        childView.addSubview(headerView)
    }
    
    public func setHeaderView(_ childView: UIView, viewController: UIViewController, title: String, leftImage: String, rightImage: String, rightImage2: String, useSearchBar : Bool){
        let headerView = HeaderView.instanceFromNib() as! HeaderView
        headerView.frame = childView.bounds
        headerView.delegate = (viewController as! HeaderViewDelegate)
        headerView.setTitle(text: title)
        headerView.setLeftImage(imageName: leftImage)
        headerView.setRightImage(imageName: rightImage)
        headerView.setRightImage2(imageName: rightImage2)

        headerView.useSearchBar = useSearchBar
        childView.addSubview(headerView)
    }
    
    public func setHeaderViewForEvaluation(_ childView: UIView, viewController: UIViewController, title: String, leftImage: String, rightImage: String, useSearchBar : Bool){
        let headerView = HeaderView.instanceFromNib() as! HeaderView
        headerView.frame = childView.bounds
        headerView.delegate = (viewController as! HeaderViewDelegate)
        headerView.setTitle(text: title)
        headerView.setLeftImage(imageName: leftImage)
        headerView.setRightImage(imageName: rightImage)
        headerView.btnRight.isHidden = true
        headerView.btnRight.isEnabled = false
        headerView.useSearchBar = useSearchBar
        childView.addSubview(headerView)
    }
    
    public func setBotonBarView(_ childView: UIView, viewControllerTitle: String, viewController: UIViewController){
        let headerView = BotonBarView.instanceFromNib() as! BotonBarView
        headerView.frame = childView.bounds
        headerView.frame.size.height = childView.frame.size.height
        headerView.frame.size.width = childView.frame.size.width
        if(viewControllerTitle == AppConstants.VIEWCONTROLLER.TITLE.EVALUATE_RENOVATIONS) {
            DispatchQueue.main.async {
                headerView.objectButtonAcepta.isHidden = true
                headerView.objectButtonAcepta.isEnabled = false
            }
            headerView.objectButtonRechaza.setTitle("Autorizar", for: .normal)
        }
        
        if(viewControllerTitle == AppConstants.VIEWCONTROLLER.TITLE.AUTHORIZE_RENOVATIONS) {
            headerView.objectButtonAcepta.setTitle("Editar", for: .normal)
            headerView.objectButtonRechaza.setTitle("Autorizar", for: .normal)
        }
        
        headerView.delegate = (viewController as! BotonBarViewDelegate)
        childView.addSubview(headerView)
    }
    
    public func showDialogMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    public func showExpiredSessionAlert(on viewController : UIViewController){
        UserAlerts.showAlertMessageAndLetTakeAction(on: viewController, message: AppConstants.MESSAGES.EXPIRED_SESSION, completion: RelativeAppsHelper.openRelativeApp, stringParameterForAction: AppDelegate.actionCloseSession)
        KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
        KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHENTICATION_TOKEN_KEY)
    }
    
    func showSpinner(onView : UIView) {
        DispatchQueue.main.async {
            if !self.isShowingSpinner {
                let spinnerView = UIView.init(frame: onView.bounds)
                let effectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
                let activityIndicator = UIActivityIndicatorView.init(style: .white)
                var strLabel = UILabel()
                
                spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
                
                strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 60))
                strLabel.text = "Por favor espere..."
                strLabel.font = .systemFont(ofSize: 14, weight: .medium)
                strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)
                
                activityIndicator.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
                activityIndicator.startAnimating()
                
                effectView.frame = CGRect(x: self.view.frame.midX - 90, y: self.view.frame.midY - strLabel.frame.height/2 , width: 180, height: 60)
                effectView.layer.cornerRadius = 15
                effectView.layer.masksToBounds = true
                
                
                effectView.contentView.addSubview(activityIndicator)
                effectView.contentView.addSubview(strLabel)
                spinnerView.addSubview(effectView)
                onView.addSubview(spinnerView)
                
                
                self.vSpinner = spinnerView
                self.isShowingSpinner = true
                print("Colocando spinner")
            }
        }
    }
    
    func removeSpinner() {
        DispatchQueue.main.async {
            if self.isShowingSpinner {
                self.vSpinner?.removeFromSuperview()
                self.vSpinner = nil
                self.isShowingSpinner = false
                print("Quitando spinner")
            }  else {
                print("No hay spinner que remover")
            }
        }
    }
    
    /*func activityIndicator(_ title: String) {
        let messageFrame = UIView()
        var activityIndicator = UIActivityIndicatorView()
        var strLabel = UILabel()
        
        strLabel.removeFromSuperview()
        activityIndicator.removeFromSuperview()
        effectView.removeFromSuperview()

        strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 46))
        strLabel.text = title
        strLabel.font = .systemFont(ofSize: 14, weight: UIFontWeightMedium)
        strLabel.textColor = UIColor(white: 0.9, alpha: 0.7)

        effectView.frame = CGRect(x: view.frame.midX - strLabel.frame.width/2, y: view.frame.midY - strLabel.frame.height/2 , width: 160, height: 46)
        effectView.layer.cornerRadius = 15
        effectView.layer.masksToBounds = true

        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 46, height: 46)
        activityIndicator.startAnimating()

        effectView.addSubview(activityIndicator)
        effectView.addSubview(strLabel)
        view.addSubview(effectView)
    }*/
}
extension ParentViewController : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        self.appDelegate.location = locValue
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways, .authorizedWhenInUse:
            if self.restorationIdentifier == "onBoardingViewController" {
                self.performSegue(withIdentifier: "segueSideMenu", sender: self)
            }
        case .notDetermined, .restricted, .denied:
            break;
        @unknown default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways, .authorizedWhenInUse:
            if self.restorationIdentifier == "onBoardingViewController" {
                self.performSegue(withIdentifier: "segueSideMenu", sender: self)
            }
        case .notDetermined, .restricted, .denied:
            break;
        @unknown default:
            break
        }
    }
    

}
