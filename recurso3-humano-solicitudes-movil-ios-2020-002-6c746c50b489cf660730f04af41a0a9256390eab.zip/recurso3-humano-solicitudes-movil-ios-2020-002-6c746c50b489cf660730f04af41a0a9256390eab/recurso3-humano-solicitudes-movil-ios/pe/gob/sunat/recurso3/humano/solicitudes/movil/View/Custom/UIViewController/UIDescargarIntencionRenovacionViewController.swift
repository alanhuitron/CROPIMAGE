//
//  UIDescargarIntencionRenovacionViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import UIKit

@objc protocol UIDescargarIntencionRenovacionAlertViewControllerDelegate {
    @objc func confirmarRenovacion(username: String, password: String)
    @objc func downloadNotRenovationLetter()
}


class UIDescargarIntencionRenovacionViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var textLabel: UILabel!
    
    @IBOutlet weak var userTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var delegate : UIDescargarIntencionRenovacionAlertViewControllerDelegate?
    var numPeriRenov : Int?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.containerView.layer.cornerRadius = 30
        self.hideKeyboardWhenTappedAround()

        self.textLabel.text = AppMessages.SERVICE.APROBAR_RENOVACION.NOT_RENOVATION_MESSAGE
        // Do any additional setup after loading the view.
    }


    @IBAction func acceptAction(_ sender: Any) {
        if let username = self.userTextField.text, let password = self.passwordTextField.text {
            if username != "" && password != "" {
                self.delegate?.confirmarRenovacion(username: username, password: password)
                self.dismiss(animated: false, completion: nil)
            } else {
                // Mostrar mensaje de que no hay alguno de los campos
                print("No hay usuario y/o contraseña y no se ha llamado ni al servicio ")
            }
        }
    }
    
    @IBAction func downloadNotRenovationLetter(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
        self.delegate?.downloadNotRenovationLetter()
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
}
