//
//  UIConfirmarRenovacionAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import UIKit

@objc protocol UIConfirmarRenovacionAlertViewControllerDelegate {
    @objc func acceptAction(username: String, password: String, codTipoRenov: String, numPeriRenov: Int)
}

class UIConfirmarRenovacionAlertViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var siRenuevoRadioButton: RadioButton!
    
    @IBOutlet weak var noRenuevoRadioButton: RadioButton!
   
    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    var isSiRenuevoButtonSelected = false
    
    var isNoRenuevoButtonSelected = false
    
    var delegate : UIConfirmarRenovacionAlertViewControllerDelegate?
    var numPeriRenov : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.containerView.layer.cornerRadius = 30
        self.hideKeyboardWhenTappedAround()

        // Do any additional setup after loading the view.
    }


    @IBAction func acceptButtonAction(_ sender: Any) {
        var codTipoRenov : String? = nil
        
        if(self.isNoRenuevoButtonSelected){
            codTipoRenov = "04"
        } else if (self.isSiRenuevoButtonSelected) {
            codTipoRenov = "01"
        }
        
        if let username = self.usernameTextField.text, let password = self.passwordTextField.text, let codTipoRenov = codTipoRenov, let numPeriRenov = numPeriRenov {
            if username != "" && password != "" {
                self.delegate?.acceptAction(username: username, password: password, codTipoRenov: codTipoRenov, numPeriRenov: numPeriRenov)
                self.dismiss(animated: false, completion: nil)
            } else {
                // Mostrar mensaje de que no hay alguno de los campos
                print("No hay usuario y/o contraseña y no se ha llamado ni al servicio ")
            }
        }
    }
    
    @IBAction func cancelButtonAction(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func siRenuevoButtonSelected(_ sender: RadioButton) {
        sender.isSelected = !sender.isSelected
        isSiRenuevoButtonSelected = sender.isSelected
        if(isNoRenuevoButtonSelected) {
            self.noRenuevoRadioButton.isSelected = false
            self.isNoRenuevoButtonSelected = self.noRenuevoRadioButton.isSelected
        }
    }
    
    @IBAction func noRenuevoButtonSelected(_ sender: RadioButton) {
        sender.isSelected = !sender.isSelected
        isNoRenuevoButtonSelected = sender.isSelected
        if(isSiRenuevoButtonSelected) {
            self.siRenuevoRadioButton.isSelected = false
            self.isSiRenuevoButtonSelected = self.siRenuevoRadioButton.isSelected
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

