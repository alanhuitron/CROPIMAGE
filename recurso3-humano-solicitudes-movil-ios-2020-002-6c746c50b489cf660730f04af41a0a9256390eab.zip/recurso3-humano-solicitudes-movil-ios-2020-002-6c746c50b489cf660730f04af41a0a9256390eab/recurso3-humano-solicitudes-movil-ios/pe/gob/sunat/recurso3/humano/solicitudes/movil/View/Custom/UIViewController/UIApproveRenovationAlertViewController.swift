//
//  UIApproveRenovationAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import UIKit

@objc protocol UIApproveRenovationAlertViewControllerDelegate {
    @objc func authorizeAction()
}

class UIApproveRenovationAlertViewController: ParentViewController {

    @IBOutlet var alertView: UIView!
    
    var delegate : UIApproveRenovationAlertViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.alertView.layer.cornerRadius = 30
        self.hideKeyboardWhenTappedAround()
    }
    
    @IBAction func authorizeButton(_ sender: Any) {
        self.delegate?.authorizeAction()
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
}
