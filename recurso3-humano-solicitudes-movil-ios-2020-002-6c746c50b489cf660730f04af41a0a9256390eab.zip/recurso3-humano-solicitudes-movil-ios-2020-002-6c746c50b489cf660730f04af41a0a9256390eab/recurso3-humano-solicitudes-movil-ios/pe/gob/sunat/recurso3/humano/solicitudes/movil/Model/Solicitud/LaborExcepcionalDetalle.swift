//
//  LaborExcepcionalDetalle.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 12/2/19.
//

import Foundation

struct LaborExcepcionalDetalle : Codable {
    
    var codPersona: String?
    var numDetalle: Int?
    var fecPermiso: String?
    var fecPermisoDate : Int?
    var horInicio: String?
    var horFin: String?
    var desSustento : String?
    
    
}
