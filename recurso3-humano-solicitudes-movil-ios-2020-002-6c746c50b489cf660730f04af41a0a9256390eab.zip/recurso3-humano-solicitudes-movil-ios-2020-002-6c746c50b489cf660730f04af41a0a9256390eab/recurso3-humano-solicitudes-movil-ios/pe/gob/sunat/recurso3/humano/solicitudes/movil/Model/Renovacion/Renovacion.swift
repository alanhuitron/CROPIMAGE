//
//  Renovacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation

class Renovacion : Decodable {
    var numIntencion : String?
    var codUOrga : String?
    var desUOrga : String?
    var codTipContrato : String?
    var tipContrato : String?
    var codRegistro : String?
    var nombPersona : String?
    var desTiempoServ : String?
    var codSituacion : String?
    var situacion : String?
    var desPeriodo : String?
    var estado : String?
    var observacion : String?
    var codPDF : String?
    var tipFirma : String?
    var fecIniPeriodo : Int?
    var fecFinPeriodo : Int?
    var fecFirmaGGE : Int?
}
