//
//  RechazoMasivoSolicitudesResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/28/19.
//

import Foundation

struct RechazoMasivoSolicitudesResponse : Codable {
    
    var httpResponse = BaseResponse()
    var httpBody = RechazoMasivoSolicitudesResponseBody()
}
