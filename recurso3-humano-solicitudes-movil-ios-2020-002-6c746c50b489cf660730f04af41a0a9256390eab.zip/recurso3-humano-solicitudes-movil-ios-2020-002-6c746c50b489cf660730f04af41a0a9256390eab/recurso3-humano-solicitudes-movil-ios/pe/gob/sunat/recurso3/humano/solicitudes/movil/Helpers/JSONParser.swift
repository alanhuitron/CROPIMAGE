//
//  JSONParser.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/16/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

class JSONParser{
    
    static let jsonEncoder = JSONEncoder()
    static let jsonDecoder = JSONDecoder()
    
    static func encode<T>(_ value: T) -> Data? where T : Encodable{
        var jsonData:Data?
        do {
            jsonData = try jsonEncoder.encode(value)
        } catch { print(error) }
        return jsonData
    }
    
    static func encodeAsString<T>(_ value: T) -> String where T : Encodable{
        let data = encode(value)
        let jsonData=String(data: data!, encoding: .utf8)!
        return jsonData
    }
    
    static func decode<T>(_ type: T.Type, from data: Data) -> T? where T : Decodable{
        var response:T?
        do{
            response = try jsonDecoder.decode(type, from: data)
        } catch { print(error) }
        return response
    }
}
