//
//  ObtenerRenovacionesResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation

struct ObtenerRenovacionesResponseBody : Decodable {
    
    var renovaciones : [Renovacion]?
    
}
