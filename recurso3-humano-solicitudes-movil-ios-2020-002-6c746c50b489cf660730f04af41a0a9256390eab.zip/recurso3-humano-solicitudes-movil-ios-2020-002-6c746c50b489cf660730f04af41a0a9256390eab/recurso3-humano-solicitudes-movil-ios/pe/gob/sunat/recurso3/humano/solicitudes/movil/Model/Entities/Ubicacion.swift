//
//  Ubicacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import Foundation
struct Ubicacion: Codable {
    
    var numLatitud:String?
    var numLongitud:String?

    
    
    
}
