//
//  FirmarRenovacionWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import Foundation
class FirmarRenovacionWorker {

    static func getPendingSignRenovations(with token: String, with auditoriaBean: String,
                                          with userRegistryNumber: String,
                                          onSuccess success: @escaping (_ response: ObtenerRenovacionesPorFirmarResponse) -> Void,
                                          onFailed failed: @escaping (_ response: ObtenerRenovacionesPorFirmarResponse) -> Void,
                                          onAuthenticationError authFailed: @escaping (_ response: ObtenerRenovacionesPorFirmarResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/firmadocumento/listardocumentos?codPersona=\(userRegistryNumber)" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=ObtenerRenovacionesPorFirmarResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = ObtenerRenovacionesPorFirmarResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(ObtenerRenovacionesPorFirmarResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    print(response)
                    success(response)
                    
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    authFailed(response)
                default:
                    var responseFailed=ObtenerRenovacionesPorFirmarResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    print(response)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func downloadRenovation(with token: String, with auditoriaBean: String, with parameters: DescargarRenovacionRequest, onSuccess success: @escaping (_ response: DescargarRenovacionResponse) -> Void,
                                     onFailed failed: @escaping (_ response: DescargarRenovacionResponse) -> Void,
                                     onAuthenticationError authFailed: @escaping (_ response: DescargarRenovacionResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/documentos/descargaPDF" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=DescargarRenovacionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = DescargarRenovacionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(DescargarRenovacionResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    print(response)
                    success(response)
                    
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    authFailed(response)
                default:
                    var responseFailed=DescargarRenovacionResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    print(response)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func guardarSeguimiento(with token: String, with auditoriaBean: String, with parameters: [SeguimientoForRenovation], onSuccess success: @escaping (_ response: SeguimientoForRenovationResponseBody) -> Void,
                                     onFailed failed: @escaping (_ response: SeguimientoForRenovationResponseBody) -> Void,
                                     onAuthenticationError authFailed: @escaping (_ response: SeguimientoForRenovationResponseBody) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/periodos/saveSeguimiento" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        print(auditoriaBean)
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                let responseFailed=SeguimientoForRenovationResponseBody()
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = SeguimientoForRenovationResponseBody()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode(SeguimientoForRenovationResponseBody.self, from: data!)!

                    success(response)
                    
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!

                    print(response)
                    failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!

                    print(response)
                    authFailed(response)
                default:
                    let responseFailed=SeguimientoForRenovationResponseBody()

                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func confirmarRenovacion(with token: String, with auditoriaBean: String, with parameters: ConfirmarRenovacion, onSuccess success: @escaping (_ response: ConfirmarRenovacionResponse) -> Void,
                                     onFailed failed: @escaping (_ response: ConfirmarRenovacionResponse) -> Void,
                                     onAuthenticationError authFailed: @escaping (_ response: ConfirmarRenovacionResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/firmadocumento/confirmardescargarfirma" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=ConfirmarRenovacionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = ConfirmarRenovacionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(ConfirmarRenovacionResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    print(response)
                    success(response)
                    
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    authFailed(response)
                default:
                    var responseFailed=ConfirmarRenovacionResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    print(response)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func descargarCartaNoRenovacion(with token: String, with auditoriaBean: String, with numIntencion: String, onSuccess success: @escaping (_ response: CartaNoRenovacion) -> Void,
                                           onFailed failed: @escaping (_ response: CartaNoRenovacion) -> Void,
                                           onAuthenticationError authFailed: @escaping (_ response: CartaNoRenovacion) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/documentos/pdfCartaTermino?numIntencion=\(numIntencion)" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
                
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                _ = CartaNoRenovacion()
                
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = CartaNoRenovacion()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode(CartaNoRenovacion.self, from: data!)!
                    print(response)
                    success(response)
                    
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    
                    print(response)
                    failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    print(response)
                    authFailed(response)
                default:
                    let responseFailed=CartaNoRenovacion()
                    
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    
    static func confirmarFirma(with token: String, with auditoriaBean: String, with parameters: ConfirmarFirma, onSuccess success: @escaping (_ response: ConfirmarFirmaResponse) -> Void,
                                     onFailed failed: @escaping (_ response: ConfirmarFirmaResponse) -> Void,
                                     onAuthenticationError authFailed: @escaping (_ response: ConfirmarFirmaResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/firmadocumento/confirmarfirma" //TODO: validar y crear constantes
        
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=ConfirmarFirmaResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = ConfirmarFirmaResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(ConfirmarFirmaResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    print(response)
                    success(response)
                    
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    authFailed(response)
                default:
                    var responseFailed=ConfirmarFirmaResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    print(response)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
}
