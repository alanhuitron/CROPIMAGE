//
//  UIMarcacionTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import UIKit

class UIMarcacionTableViewCell: UITableViewCell {
    
    static let IDENTIFIER = "UIMarcacionTableViewCell"
    
    @IBOutlet weak var lblHour: UILabel!
    @IBOutlet weak var lblDescripcion: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

