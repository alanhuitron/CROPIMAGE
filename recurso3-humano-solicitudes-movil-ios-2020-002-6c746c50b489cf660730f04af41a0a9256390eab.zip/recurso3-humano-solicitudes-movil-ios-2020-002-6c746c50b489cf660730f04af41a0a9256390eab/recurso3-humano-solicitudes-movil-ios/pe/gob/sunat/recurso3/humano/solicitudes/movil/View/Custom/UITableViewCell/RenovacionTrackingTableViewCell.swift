//
//  RenovacionTrackingTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import UIKit

class RenovacionTrackingTableViewCell: UITableViewCell {
    
    static let NAME = "RenovacionTrackingTableViewCell"
    static let IDENTIFIER = "RenovacionTrackingTableViewCell"

    @IBOutlet weak var situacionLabel: UILabel!
    @IBOutlet weak var fechaLabel: UILabel!
    @IBOutlet weak var codeAndNameLabel: UILabel!
    @IBOutlet weak var estadoAndDesPeriodoLabel: UILabel!
    @IBOutlet weak var observacionLabel: UILabel!
    @IBOutlet weak var horaLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    /*override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }*/
    
    @objc func handlePress(sender: UITapGestureRecognizer){
    }
    
}
