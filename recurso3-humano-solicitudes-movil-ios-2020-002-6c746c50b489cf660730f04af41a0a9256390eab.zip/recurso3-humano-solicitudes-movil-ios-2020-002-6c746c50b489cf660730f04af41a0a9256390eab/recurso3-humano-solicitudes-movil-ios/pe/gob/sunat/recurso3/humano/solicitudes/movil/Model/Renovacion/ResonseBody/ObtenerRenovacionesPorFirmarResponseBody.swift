//
//  ObtenerRenovacionesPorFirmar.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import Foundation

class ObtenerRenovacionesPorFirmarResponseBody : Decodable {
    var exito : Bool?
    var lista : [RenovacionPorFirmar]?
}
