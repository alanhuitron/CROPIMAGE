//
//  DescargarRenovacionResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import Foundation

struct DescargarRenovacionResponse : Decodable {
    var httpResponse = BaseResponse()
    var httpBody = DescargarRenovacionResponseBody()
}
