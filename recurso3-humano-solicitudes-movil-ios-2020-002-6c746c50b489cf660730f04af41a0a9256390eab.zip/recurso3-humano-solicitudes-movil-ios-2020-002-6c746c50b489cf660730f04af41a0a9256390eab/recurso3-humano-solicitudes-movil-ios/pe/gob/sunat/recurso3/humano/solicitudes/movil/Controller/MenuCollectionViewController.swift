//
//  MenuCollectionViewController.swift
//  test-rh
//
//  Created by MOJAVE on 10/31/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import UIKit

private let reuseIdentifier = "OptionCell"

class MenuCollectionViewController: ParentViewController {
    

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var authToken : String?
    var options = [OptionEntity]()
    var externalToolOption : ExternalToolOption?
    
    private let spacing:CGFloat = 8.0

    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate.controllerWithObservers.append(self)
        appDelegate.controllerToClean.append(self)
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.MAIN, leftImage: "iconMenu")
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        }
        
        
        // Register cell classes
        self.collectionView!.register(UINib(nibName: UIOptionCollectionViewCell.NAME, bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
        
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        self.collectionView?.collectionViewLayout = layout
    
        

        self.options=appDelegate.menuOptions
        self.collectionView.reloadData()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("print from menu viewDidAppear")
    }
    
    func goToSegue(_ segue: String){
        if canPerformSegue(withIdentifier: segue){
            self.performSegue(withIdentifier: segue, sender: self)
        }else{
            print("Storyboard not exist or not implemented for segue")
        }
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? HerramientasExternasViewController {
            vc.externalToolURL = self.externalToolOption?.serviceLink
        }
    }

}

extension MenuCollectionViewController : UICollectionViewDelegate , UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    // MARK: UICollectionViewDataSource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.options.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! UIOptionCollectionViewCell
        let data = self.options[indexPath.row]
        
        guard let nombreOption = data.nomOpcion, let descriptionOption = data.desOpcion  , let codOpcion = data.codOpcion else {
            return cell
        }
        let nombreImage = "iconMenu"  + codOpcion
        cell.setupContent(title: nombreOption, description: descriptionOption , image: nombreImage)
        
        return cell
    }

    // MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let numberOfItemsPerRow:CGFloat = 2
        let spacingBetweenCells:CGFloat = 8
        
        let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
        
        if let collection = self.collectionView{
            let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
            return CGSize(width: width, height: width * 1.15)
        }else{
            return CGSize(width: 0, height: 0)
        }
    }
    
    // MARK: UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedOption = self.options[indexPath.row]
        if  selectedOption.isEnable() && AppConstants.OPTIONS_WITH_STORYBOARD_PRESENTATION.contains(selectedOption.codOpcion ?? AppConstants.VALUES.EMPTY){
            print("print from didSelectItemAt")
            print("print [DBG: \(#function)]: \(self)")
            NotificationCenter.default.post(name: .onMenuOptionCellSelected, object: nil, userInfo: ["code":selectedOption.codOpcion ?? ""])
            
        } else if AppConstants.OPTIONS_WITH_ALERT_FROM_BOTTON_PRESENTATION.contains(selectedOption.codOpcion ?? AppConstants.VALUES.EMPTY) {
            let selectedOptionAsEnum = MenuOptionEnum(rawValue: MenuOption(stringLiteral: (selectedOption.codOpcion ?? "") + ",_"))
            switch selectedOptionAsEnum {
            case .externalTools:
                self.obtenerParametrosHerramientasExternas()
            default:
                break
            }
        }
    }
    
    
}

//MARK: ExternalToolServices
extension MenuCollectionViewController {
    
    func obtenerParametrosHerramientasExternas(){
        self.showSpinner(onView: self.view)
        HerramientasExternasWorker.getExternalToolsParameters(with: appDelegate.authorizationToken, forUser: appDelegate.currentUser.registryNumber, onSuccess: { (onSuccessResponse) in
            self.removeSpinner()
            var availableOptions = [String : ExternalToolOption]()
            if let params = onSuccessResponse.httpBody.parametros {
                for param in params {
                    if let safeDataParamCode = param.codDataParametro, let safeParamAbreviatura = param.desAbreviatura, let safeParamDesGlosa = param.desGlosa {
                        availableOptions[safeDataParamCode] = ExternalToolOption(code: safeDataParamCode, description: safeParamAbreviatura, serviceLink: safeParamDesGlosa)
                    }
                }
            }
            
            DispatchQueue.main.async {
                let externalToolsAlertController = UIExternalToolsAlertViewController(nibName: UIExternalToolsAlertViewController.IDENTIFIER, bundle: nil)
                externalToolsAlertController.modalPresentationStyle = .overCurrentContext
                externalToolsAlertController.modalTransitionStyle = .coverVertical
                externalToolsAlertController.delegate = self
                externalToolsAlertController.externalToolOptions = availableOptions
                self.present(externalToolsAlertController, animated: false, completion: nil)
            }
        }, onFailed: { (ObtenerParametrosHerramientasResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                let externalToolsAlertController = UIExternalToolsAlertViewController(nibName: UIExternalToolsAlertViewController.IDENTIFIER, bundle: nil)
                externalToolsAlertController.modalPresentationStyle = .overCurrentContext
                externalToolsAlertController.modalTransitionStyle = .coverVertical
                externalToolsAlertController.delegate = self
                self.present(externalToolsAlertController, animated: false, completion: nil)
            }
        }, onAuthenticationError: { (ObtenerParametrosHerramientasResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        })
    }
    
}

//MARK: EXTENSIONS - HeaderViewDelegate
extension MenuCollectionViewController: HeaderViewDelegate{
    
    func actionLeft() {
        self.openMenu()
    }
    
}

//MARK: EXTENSIONS - HeaderViewDelegate
extension MenuCollectionViewController: UIExternalToolsAlertViewControllerDelegate {
    
    func openChatBot(option: ExternalToolOption) {
        DispatchQueue.main.async {
            self.externalToolOption = option
            self.performSegue(withIdentifier: MenuOptionEnum.externalTools.rawValue.value, sender: nil)
        }
    }
    
    func openYammerComunicadosInternos(option: ExternalToolOption) {
        DispatchQueue.main.async {
            self.externalToolOption = option
            let comunicadosInternosURL = URL(string: self.externalToolOption!.serviceLink!)
            if let safeYammerUniversalLink = comunicadosInternosURL {
                self.openYammerOnApp(for: safeYammerUniversalLink)
            }
        }
    }
    
    func openYammerComunicandonosEnLinea(option: ExternalToolOption) {
        DispatchQueue.main.async {
            self.externalToolOption = option
            let comunicandonosURL = URL(string: self.externalToolOption!.serviceLink!)
            if let safeYammerUniversalLink = comunicandonosURL {
                self.openYammerOnApp(for: safeYammerUniversalLink)
            }
        }
    }
    
    private func openYammerOnApp(for yammerChatUniversalLink : URL){
        let yammerAppStore = URL(string: EnviromentConfiguration.YAMMER_APP_STORE_DEEP_LINK)
        let isItPossibleToOpenYammerApp = UIApplication.shared.canOpenURL(URL(string: AppDelegate.yammerURLScheme)!)
        if isItPossibleToOpenYammerApp {
            if UIApplication.shared.canOpenURL(yammerChatUniversalLink) {
                UIApplication.shared.open(yammerChatUniversalLink, completionHandler: { (success) in })
            }
        } else {
            if let safeURL = yammerAppStore, UIApplication.shared.canOpenURL(safeURL) {
                UIApplication.shared.open(safeURL, completionHandler: { (success) in })
            }
        }
    }
}


