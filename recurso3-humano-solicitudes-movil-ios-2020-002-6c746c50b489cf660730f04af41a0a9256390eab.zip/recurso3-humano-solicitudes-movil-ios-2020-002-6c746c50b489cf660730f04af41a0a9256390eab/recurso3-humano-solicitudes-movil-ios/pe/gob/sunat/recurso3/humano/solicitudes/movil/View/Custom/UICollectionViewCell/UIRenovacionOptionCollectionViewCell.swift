//
//  UIRenovacionOptionCollectionViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import UIKit

class UIRenovacionOptionCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var circleImgOption: UIImageView!
    @IBOutlet weak var lblTitleOption: UILabel!
    @IBOutlet weak var imgOption: UIImageView!
    @IBOutlet weak var notificationNumberLabel: UILabel!
    @IBOutlet weak var notificationCircle: UIImageView!
    @IBOutlet weak var view: UIView!
    var token : String = ""
    static let NAME = "UIRenovacionOptionCollectionViewCell"

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
}
