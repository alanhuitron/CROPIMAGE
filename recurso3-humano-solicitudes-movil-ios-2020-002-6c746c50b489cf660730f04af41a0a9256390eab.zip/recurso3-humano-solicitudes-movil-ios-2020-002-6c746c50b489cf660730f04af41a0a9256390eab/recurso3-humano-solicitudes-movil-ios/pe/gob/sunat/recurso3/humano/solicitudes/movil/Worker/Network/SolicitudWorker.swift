//
//  SolicitudWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/4/19.
//

import Foundation
class SolicitudWorker {

    static func getPendingRequests(with token: String,
                                  parameters: SolicitudRequest,
                                onSuccess success: @escaping (_ response: GetPendingResponse) -> Void,
                                onFailed failed: @escaping (_ response: GetPendingResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: GetPendingResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.codPersona ?? "")/pendientes" //TODO: validar y crear constantes
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
            
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=GetPendingResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = GetPendingResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("El servicio respondio con un http status ->",statusCode)
                    print("Se recibieron las siguientes solicitudes : " + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.solicitudes = JSONParser.decode([Solicitud].self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        success(response)
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                    default:
                        var responseFailed=GetPendingResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                    }
               }
           })
           task.resume()
       }

    static func getDetailRequest(with token: String,
                                  parameters: SolicitudRequest,
                                onSuccess success: @escaping (_ response: GetPendingResponse) -> Void,
                                onFailed failed: @escaping (_ response: GetPendingResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: GetPendingResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.codPersona ?? "")/solicitud"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
            
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=GetPendingResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = GetPendingResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("El servicio respondio con un http status ->",statusCode)
                    print("Detalle de Solicitud : " + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.solicitud = JSONParser.decode(Solicitud.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        success(response)
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                    default:
                        var responseFailed=GetPendingResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                   }
               }
           })
           task.resume()
       }
    
    static func approvePendingApplication(with token: String, parameters: AprobarSolicitudRequest,
                                onSuccess success: @escaping (_ response: AprobarSolicitudResponse) -> Void,
                                onFailed failed: @escaping (_ response: AprobarSolicitudResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: AprobarSolicitudResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.nroRegistroAprobador ?? "")/aprobar"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=AprobarSolicitudResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = AprobarSolicitudResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.errores = JSONParser.decode([Errores].self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     authFailed(response)
                default:
                     var responseFailed=AprobarSolicitudResponse()
                     responseFailed.httpResponse.success = false
                     responseFailed.httpResponse.httpCode = String(statusCode)
                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func approveMassivePendingApplication(with token: String, parameters: AprobarSolicitudRequest,
                                onSuccess success: @escaping (_ response: AprobacionMasivaSolicitudesResponse) -> Void,
                                onFailed failed: @escaping (_ response: AprobacionMasivaSolicitudesResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: AprobacionMasivaSolicitudesResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.nroRegistroAprobador ?? "")/aprobarmasiva"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=AprobacionMasivaSolicitudesResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = AprobacionMasivaSolicitudesResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Masiva de Solicitudes : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(AprobacionMasivaSolicitudesResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                default:
                    var responseFailed=AprobacionMasivaSolicitudesResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func rejectPendingApplication(with token: String, parameters: RechazarSolicitudRequest,
                                onSuccess success: @escaping (_ response: RechazarSolicitudResponse) -> Void,
                                onFailed failed: @escaping (_ response: RechazarSolicitudResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: RechazarSolicitudResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.nroRegistroAprobador ?? "")/rechazar"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=RechazarSolicitudResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = RechazarSolicitudResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Rechazo Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.errores = JSONParser.decode([Errores].self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     authFailed(response)
                default:
                     var responseFailed=RechazarSolicitudResponse()
                     responseFailed.httpResponse.success = false
                     responseFailed.httpResponse.httpCode = String(statusCode)
                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func rejectMassivePendingApplication(with token: String, parameters: RechazarSolicitudRequest,
                                onSuccess success: @escaping (_ response: RechazoMasivoSolicitudesResponse) -> Void,
                                onFailed failed: @escaping (_ response: RechazoMasivoSolicitudesResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: RechazoMasivoSolicitudesResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.nroRegistroAprobador ?? "")/rechazarmasiva"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=RechazoMasivoSolicitudesResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = RechazoMasivoSolicitudesResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Rechazo Masivo de Solicitudes : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(RechazoMasivoSolicitudesResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400, 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                default:
                      var responseFailed=RechazoMasivoSolicitudesResponse()
                      responseFailed.httpResponse.success = false
                      responseFailed.httpResponse.httpCode = String(statusCode)
                      failed(responseFailed)
                   }
               }
           })
        task.resume()
        
    }
    
    static func getApplicationTypes(with token: String, forUser userRegistryNum: String,
                                onSuccess success: @escaping (_ response: GetTiposSolicitudResponse) -> Void,
                                onFailed failed: @escaping (_ response: GetTiposSolicitudResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: GetTiposSolicitudResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(userRegistryNum)/parametros/681"
        let endpoint = URL(string: endpointURL)
        print("Retrieving application types from URL : \(endpoint?.absoluteString ?? "")")

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=GetTiposSolicitudResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = GetTiposSolicitudResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Tipos de solicitud recuperados del servicio : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.tiposSolicitud = JSONParser.decode([Parametro].self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     authFailed(response)
                default:
                     var responseFailed=GetTiposSolicitudResponse()
                     responseFailed.httpResponse.success = false
                     responseFailed.httpResponse.httpCode = String(statusCode)
                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
}
