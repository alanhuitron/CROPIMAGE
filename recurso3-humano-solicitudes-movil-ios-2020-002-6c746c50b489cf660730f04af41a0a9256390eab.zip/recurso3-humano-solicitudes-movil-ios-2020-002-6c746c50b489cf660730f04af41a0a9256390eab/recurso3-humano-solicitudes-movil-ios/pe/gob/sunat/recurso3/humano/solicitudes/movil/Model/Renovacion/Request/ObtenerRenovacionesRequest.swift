//
//  ObtenerRenovaciones.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation

struct ObtenerRenovacionesRequest : Codable {
    var codUOrga : String?
    var codSituacion : String?
    var dependencias : String?
    var parametrosBusqueda : ParametrosBusqueda?
}
