//
//  DescargarRenovacionResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import Foundation

struct DescargarRenovacionResponseBody : Decodable {
    var desMimeType: String?
    var nomArchivo: String?
    var blobBase64: String?
}
