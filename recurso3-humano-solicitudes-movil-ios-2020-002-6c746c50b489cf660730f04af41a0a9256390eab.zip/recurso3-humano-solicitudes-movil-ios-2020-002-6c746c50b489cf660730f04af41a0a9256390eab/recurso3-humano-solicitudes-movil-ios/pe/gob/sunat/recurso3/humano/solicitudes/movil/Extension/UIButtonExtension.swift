//
//  UIButtonExtension.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation
import UIKit

extension UIButton {
    
    func roundBorders(corner : CGFloat){
        self.layer.cornerRadius = corner
    }
    
}
