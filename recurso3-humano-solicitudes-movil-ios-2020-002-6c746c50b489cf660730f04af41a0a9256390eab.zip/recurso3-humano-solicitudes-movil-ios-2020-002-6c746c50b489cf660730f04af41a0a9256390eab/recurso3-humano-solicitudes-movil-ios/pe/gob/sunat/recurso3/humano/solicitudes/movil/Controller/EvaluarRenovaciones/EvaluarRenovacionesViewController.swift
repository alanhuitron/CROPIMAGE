//
//  EvaluarRenovacionesViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/25/20.
//

import UIKit

protocol EvaluarRenovacionesViewControllerDelegate {
    func evaluateFinished()
}


private let reuseIdentifier = "RenovationTableViewCell"
class EvaluarRenovacionesViewController: ParentViewController {
    
    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var selectedItemsBarView: UIView!
    @IBOutlet weak var gifImageView: UIImageView!
    @IBOutlet weak var noResultsLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    var delegate : EvaluarRenovacionesViewControllerDelegate?
    
    var renovations = [Renovacion]() //general
    var renovationsFilteredBySearch = [Renovacion]() //for applications returned by filter. After received, this array become 'applications' array
    var UUOOArray: [String] = [String] ()
    var selectedRenovation : Renovacion? //application selected by simple touch on cell
    var searchIsActive = false
    var approveApplication = false
    var willBeAMassiveProcess = false
    var userIsInSelectMode = false
    var selectedRenovationsIndexPath = [IndexPath]()
    let refreshControl = UIRefreshControl()
    var vistaFiltro = FiltroEvaluarRenovacionesViewController()
    var alerts = ToastAlerts()
    var expectedResponses = 0
    var currentResponses = 0
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.EVALUATE_RENOVATIONS, leftImage: "iconLeft", rightImage: "iconSearch", rightImage2: "iconFilter", useSearchBar: true)
        
        let gif = UIImage.gif(name: "emptyBox")
        gifImageView.image = gif
        gifImageView.isHidden = true
        noResultsLabel.isHidden = true
        messageLabel.isHidden = true
        //table view setup
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: UIRenovacionTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: UIRenovacionTableViewCell.IDENTIFIER)
        self.tableView.tableFooterView = UIView(frame: .zero)
            //adding long press gesture
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        self.tableView.addGestureRecognizer(longPress)
            //adding refresh control for refresh on pull gesture
        self.tableView.refreshControl = refreshControl
        self.refreshControl.addTarget(self, action: #selector(retrieveRenovations), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.refreshControl.attributedTitle = NSAttributedString(string: "Recuperando renovaciones ...", attributes: attributes)

        
        self.setBotonBarView(self.selectedItemsBarView, viewControllerTitle: AppConstants.VIEWCONTROLLER.TITLE.EVALUATE_RENOVATIONS, viewController: self)
    
        self.retrieveRenovations()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: false)
        }
        print("viewWillAppear indexSelected after clean \(selectedRenovationsIndexPath.count)")
    }
    
    
    // MARK: - Miscellaneous Fuctions
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: self.tableView)
            if let indexPath = self.tableView.indexPathForRow(at: touchPoint) {
                self.selectCellOn(indexPath: indexPath)
                if !self.userIsInSelectMode {
                    self.userIsInSelectMode = true
                }
            }
        }
        print("handleLongPress indexsSelected \(selectedRenovationsIndexPath.count)")
    }
    
    private func selectCellOn(indexPath : IndexPath){
        print("selected :\(indexPath.row)")
        let cell = tableView.cellForRow(at: indexPath)
        if selectedRenovationsIndexPath.contains(indexPath){
            cell?.backgroundColor = .white
            if let index = selectedRenovationsIndexPath.firstIndex(of: indexPath){
                selectedRenovationsIndexPath.remove(at: index)
            }
        } else {
            cell!.backgroundColor = UIColor(named: "selectedColor")
            selectedRenovationsIndexPath.append(indexPath)
        }
        
        if selectedRenovationsIndexPath.count == 0 {
            self.userIsInSelectMode = false
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.ocultarBotonAction()
                botonBarView.setLabelSelectTodo()
                botonBarView.checkTotal.isChecked = false
            }
        }else {
            if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
                botonBarView.setLabelTotal(totalFila: String(selectedRenovationsIndexPath.count))
                    botonBarView.mostrarRenovationEvaluationBotonAction()
            }
        }
    }
    
    func prepareDefaultRenovationRequest()->ObtenerRenovacionesRequest{
        var request = ObtenerRenovacionesRequest()
        request.codUOrga = "TODOSINTEN"
        request.codSituacion = "04"
        request.dependencias = "1"
        return request
    }
    
    @objc func retrieveRenovations(){
        self.searchIsActive = false
        self.renovationsFilteredBySearch.removeAll()
        self.selectedRenovationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        self.showSpinner(onView: self.view)
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionWorker.getRenovations(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: self.prepareDefaultRenovationRequest(), onSuccess: { (onSuccessResponse) in
            
            DispatchQueue.main.async {
                self.renovations = onSuccessResponse.httpBody.renovaciones!
                if self.renovations.count == 0 {
                    self.gifImageView.isHidden = false
                    self.messageLabel.isHidden = false
                    self.noResultsLabel.isHidden = false
                } else {
                    self.gifImageView.isHidden = true
                    self.messageLabel.isHidden = true
                    self.noResultsLabel.isHidden = true
                    self.tableView.isHidden = false
                }
                self.removeSpinner()
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()

            }
        }, onFailed: {(onFailed) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.renovationsFilteredBySearch.removeAll()
                print("falló la obtención")
                self.renovations.removeAll()
                self.tableView.reloadData()
                self.gifImageView.isHidden = false
                self.messageLabel.isHidden = false
                self.noResultsLabel.isHidden = false
            }
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                print("falló la autenticación")
                self.refreshControl.endRefreshing()
                self.showExpiredSessionAlert(on: self)
            }
        })
        
    }
    
    func prepareRenovationsForRequest() -> [AprobarRenovacion]? {
        var renovaciones : [AprobarRenovacion]?
        
        if selectedRenovation != nil {
            var renovationsForChecking = [Renovacion]()
            renovationsForChecking.append(selectedRenovation!)
            let errorMessage = validateRenovations(renovations: renovationsForChecking)
            if(errorMessage.count == 0){
                if searchIsActive {
                    renovaciones = [AprobarRenovacion]()
                    let renovation = AprobarRenovacion()
                    renovation.numIntencion = selectedRenovation?.numIntencion
                    renovation.codSituacion =  selectedRenovation?.codSituacion
                    if let codSituacion = renovation.codSituacion {
                        let newSituacionInt = Int(codSituacion)! + 1
                        renovation.codSituacion = formatSituation(situationInt: newSituacionInt)
                    }
                    renovaciones!.append(renovation)
                } else {
                    renovaciones = [AprobarRenovacion]()
                    let renovation = AprobarRenovacion()
                    renovation.numIntencion = selectedRenovation?.numIntencion
                    renovation.codSituacion =  selectedRenovation?.codSituacion
                    if let codSituacion = renovation.codSituacion {
                        let newSituacionInt = Int(codSituacion)! + 1
                        renovation.codSituacion = formatSituation(situationInt: newSituacionInt)
                    }
                    renovaciones!.append(renovation)
                }
                
            } else {
                self.alerts.showToastAlert(vc: self, message: errorMessage)
                return nil
            }
        }
        
        if selectedRenovationsIndexPath.count > 0 {
            var renovationsForChecking = [Renovacion]()
            for indexPath in selectedRenovationsIndexPath {
                if searchIsActive {
                    renovationsForChecking.append(renovationsFilteredBySearch[indexPath.row])
                } else {
                    renovationsForChecking.append(renovations[indexPath.row])
                }
            }
            let errorMessage = validateRenovations(renovations: renovationsForChecking)
            
            if errorMessage.count == 0 {
                renovaciones = [AprobarRenovacion]()
                for indexPath in selectedRenovationsIndexPath{
                    var renovation : AprobarRenovacion?
                    if searchIsActive {
                        renovation = AprobarRenovacion()
                        renovation?.codSituacion =  renovationsFilteredBySearch[indexPath.row].codSituacion
                        renovation?.numIntencion =  renovationsFilteredBySearch[indexPath.row].numIntencion
                        if let codSituacion = renovation?.codSituacion {
                            let newSituacionInt = Int(codSituacion)! + 1
                            renovation!.codSituacion = formatSituation(situationInt: newSituacionInt)
                        }
                        
                    } else {
                        renovation = AprobarRenovacion()
                        renovation?.codSituacion =  renovations[indexPath.row].codSituacion
                        renovation?.numIntencion =  renovations[indexPath.row].numIntencion
                        if let codSituacion = renovation?.codSituacion {
                            let newSituacionInt = Int(codSituacion)! + 1
                            renovation!.codSituacion = formatSituation(situationInt: newSituacionInt)
                        }
                    }
                    
                    if let _ = renovation{
                        renovaciones?.append(renovation!)
                    }
                }
            } else {
                self.alerts.showToastAlert(vc: self, message: errorMessage)
                return nil
            }
        }
        return renovaciones!
    }
    
    func validateRenovations( renovations : [Renovacion]) -> String {
        var thereIsAProblem = ""
        
        for renovation in renovations {
            if(renovation.codSituacion == "09" && (renovation.estado == "NO RENUEVA" || renovation.estado == "RENUEVA") && (renovation.codPDF == nil || renovation.codPDF!.count < 4)) {
                thereIsAProblem = "No puede finalizar si el colaborador no firmó electrónicamente o se cargó un documento"
            } else if (renovation.codSituacion == "03" && (renovation.estado == nil || renovation.estado!.count < 3)){
                thereIsAProblem = "Un registro seleccionado no cuenta con un estado renovación"
            }
        }
        
        return thereIsAProblem
    }
    
    func formatSituation(situationInt : Int) -> String {
        var newString = ""
        if situationInt < 10 {
            newString = "0\(situationInt)"
        }
        return newString
    }
    
    
    func callApproveService(with request : [AprobarRenovacion]){
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        self.showSpinner(onView: self.view)
        RenovacionWorker.approveRenovation(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: request) { (onSuccessResponse) in

            if let exito = onSuccessResponse.httpBody.exito {
                if exito == false {
                    let errorMessage =  onSuccessResponse.httpBody.mensaje ?? "No hay detalle."
                    DispatchQueue.main.async {
                        self.alerts.showToastAlert(vc: self, message: errorMessage)
                        self.retrieveRenovations()
                        self.removeSpinner()
                    }
                } else {
                    
                    DispatchQueue.main.async {
                        self.alerts.showToastAlert(vc: self, message: "Se autorizó correctamente")
                        self.retrieveRenovations()
                        self.removeSpinner()
                    }
                  
                }
            } else {
                DispatchQueue.main.async {
                    self.alerts.showToastAlert(vc: self, message: AppMessages.SERVICE.APROBAR_RENOVACION.SUCCES_MESSAGE)
                    self.retrieveRenovations()
                    self.removeSpinner()
                }
            }
        } onFailed: { (onFailedResponse) in
            
            DispatchQueue.main.async {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                self.retrieveRenovations()
                self.removeSpinner()
            }
        } onAuthenticationError: { (onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        }
    }
    
    func divideArray(approveRenovationsArray : [AprobarRenovacion]) -> [[AprobarRenovacion]] {
        let arrays =  approveRenovationsArray.chunked(into: 100)
        /*var arrays = [[AprobarRenovacion]]()
        var e = approveRenovationsArray.count/100
        if e > Int(e) {
            e = Int(e) + 1
        } else {
            e = Int(e)
        }
        
        for _ in 0...(e - 1) {
            if i + 99 < approveRenovationsArray.count - 1 {
                var subarray = [AprobarRenovacion]()
                for _ in 0...99 {
                    subarray.append(approveRenovationsArray[i])
                    i += 1
                }
                arrays.append(subarray)
            } else {
                var subarray = [AprobarRenovacion]()
                for _ in i...approveRenovationsArray.count - 1 {
                    subarray.append(approveRenovationsArray[i])
                    i += 1
                }
                arrays.append(subarray)
            }
        }*/
        expectedResponses = arrays.count
        return arrays
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DetalleEvaluacionViewController {
            vc.parametersForRenovationDetail = self.selectedRenovation
        } else if let vc = segue.destination as? FiltroEvaluarRenovacionesViewController {
            vc.delegate = self
        }
    }

}


// MARK: - EXTENSION TABLEVIEW
extension EvaluarRenovacionesViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if renovations.count == 0 {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: false)
        } else {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: true)
        }
        
        if searchIsActive {
            return renovationsFilteredBySearch.count
        }
        return renovations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UIRenovacionTableViewCell.IDENTIFIER ,for: indexPath) as! UIRenovacionTableViewCell
        cell.selectionStyle = .none
        
        let renovation : Renovacion?
        if searchIsActive {
            renovation = renovationsFilteredBySearch[indexPath.row]
        } else {
            renovation = renovations[indexPath.row]
        }
        
        if selectedRenovationsIndexPath.contains(indexPath){
            cell.backgroundColor = UIColor(named: "selectedColor")
        } else {
            cell.backgroundColor = .white
        }
        
        if let codUOrga = renovation?.codUOrga, let desUOrga = renovation?.desUOrga {
            cell.codUOrgaAndDesUOrgaLabel.text = codUOrga + " - " + desUOrga
        }
        if let codRegistro = renovation?.codRegistro, let nombPersona = renovation?.nombPersona {
            cell.codRegistroAndNombPersonaLabel.text = codRegistro + " - " + nombPersona
        }
        if let situacion = renovation?.situacion {
            cell.situacionLabel.text = situacion
        }
        
        // validar el estado -> RENUEVA, NO RENUEVA O NULL
        
        if let estado = renovation?.estado {
            cell.desPeriodoAndTipContratoLabel.text = "\(estado) - "
            let image = UIImage(named: "notificationCircle")
            let tintedImage = image?.withRenderingMode(.alwaysTemplate)
            cell.IconUIImageView.image = tintedImage
            cell.IconUIImageView.tintColor = UIColor(named: "renovationCircleColor")
            cell.UIRNSLabel.text = estado.first?.uppercased()
            if estado == "RENUEVA" {
                if let periodo = renovation?.desPeriodo {
                    cell.desPeriodoAndTipContratoLabel.text! +=  "\(periodo) - "
                }
            }
        } else {
            cell.desPeriodoAndTipContratoLabel.text = "SIN ESTADO - "
            let image = UIImage(named: "notificationCircle")
            let tintedImage = image?.withRenderingMode(.alwaysTemplate)
            cell.IconUIImageView.image = tintedImage
            cell.IconUIImageView.tintColor = UIColor(named: "renovationCircleColor")
            cell.UIRNSLabel.text = "S"
        }
        
        
        if let tipContrato = renovation?.tipContrato {
            cell.desPeriodoAndTipContratoLabel.text! += tipContrato
        }
        
        
        if let codPdf = renovation?.codPDF {
            if (codPdf.count == 0 ){
                cell.isSignedImageView.isHidden = true
            } else {
                cell.isSignedImageView.isHidden = false
            }
        } else  {
            cell.isSignedImageView.isHidden = true
        }
        
        if let observacion = renovation?.observacion {
            if (observacion.count == 0 ){
                cell.observartionImage.isHidden = true
            } else {
                cell.observartionImage.isHidden = false
            }
        } else  {
            cell.observartionImage.isHidden = true
        }
        
        cell.delegate = self

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if userIsInSelectMode {
            self.selectCellOn(indexPath: indexPath)
        } else {
            if renovationsFilteredBySearch.count > 0 {
                self.selectedRenovation = renovationsFilteredBySearch[indexPath.row]
            } else {
                self.selectedRenovation = renovations[indexPath.row]
            }
            self.performSegue(withIdentifier: AppConstants.SEGUE.EVALUATION_DETAIL, sender: nil)
        }
    }
    
    /*
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let rejectAction =  UIContextualAction(style: .destructive, title: "RECHAZAR", handler: { (action,view,completionHandler ) in
                self.approveApplication = false
                self.willBeAMassiveProcess = false
            UserAlerts.showAlertForRenovationsApproval(on: self)
            })
        rejectAction.title = "APROBAR"
        rejectAction.backgroundColor = .systemBlue
        if searchIsActive {
            self.selectedRenovation = renovationsFilteredBySearch[indexPath.row]
        } else {
            self.selectedRenovation = renovations[indexPath.row]
        }
        let configuration = UISwipeActionsConfiguration(actions: [rejectAction])
        return configuration
    }
 */
    
    func setupHiddenPropertyForNotFoundRelatedViews(isHidden :  Bool){
        /*self.noItemsFoundView.isHidden = isHidden
        self.imgNotFoundItems.isHidden = isHidden
        self.lblNotFoundItems.isHidden = isHidden*/
        if !isHidden {
            self.tableView.backgroundColor = .clear
        } else {
            self.tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


// MARK: - EXTENSION HeaderView
extension EvaluarRenovacionesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goToMenu()
    }
    
    func goToMenu() {
        self.delegate?.evaluateFinished()
        self.dismiss(animated: true, completion: nil)
    }
    
    func actionMore() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "filtroEvaluarRenovaciones") as! FiltroEvaluarRenovacionesViewController
        vc.modalPresentationStyle = .fullScreen
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
        vistaFiltro = vc
    }
    
    func searchOnBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchIsActive = true;
        if searchText.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
            self.searchIsActive = false
        }else{
            self.renovationsFilteredBySearch = renovations.filter({ (renovation) -> Bool in
                self.searchIsActive = true
                let add = (renovation.codRegistro?.lowercased().contains(searchText.lowercased()) ?? false || (renovation.nombPersona?.lowercased().contains(searchText.lowercased()) ?? false))
                return add
            })
        }
        self.tableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setValue("Cancelar", forKey: "cancelButtonText")
        searchBar.showsCancelButton = true
        searchBar.enablesReturnKeyAutomatically = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = nil
        searchBar.showsCancelButton = false
        //Remove focus from the search bar.
        searchBar.endEditing(true)
        renovationsFilteredBySearch = []
        searchIsActive = false;
        self.tableView.reloadData()
     }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}


// MARK: - EXTENSION FiltroSolicitudes
extension EvaluarRenovacionesViewController: FiltroEvaluarRenovacionesViewControllerDelegate {

    func filtersWereApplied(filteredRenovations: [Renovacion]?) {
        self.renovations = filteredRenovations ?? [Renovacion]()

        for indexPath in selectedRenovationsIndexPath {
            let cell = self.tableView.cellForRow(at: indexPath)
            cell?.backgroundColor = .white
        }
        self.tableView.isHidden = false

        self.tableView.isUserInteractionEnabled = true

        self.selectedRenovationsIndexPath.removeAll()
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        if (self.renovations.count == 0) {
            DispatchQueue.main.async {
                self.gifImageView.isHidden = false
                self.messageLabel.isHidden = false
                self.noResultsLabel.isHidden = false
            }
        } else {
            DispatchQueue.main.async {
                self.gifImageView.isHidden = true
                self.messageLabel.isHidden = true
                self.noResultsLabel.isHidden = true
                self.tableView.isHidden = false
                self.tableView.reloadData()
            }

        }
    }
    
    func cleanFiltersRenovacion() {
        vistaFiltro.dismiss(animated: true, completion: nil)
        var contRenovacion = 0
        for _ in renovations{
            let index = IndexPath(row: contRenovacion, section: 0)
            if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                    self.selectedRenovationsIndexPath.remove(at: indexPosition)
            }
            contRenovacion  = contRenovacion  + 1
        }
        retrieveRenovations()
    }
    
}


// MARK: - EXTENSION BotonBarView
extension EvaluarRenovacionesViewController: BotonBarViewDelegate {
    
    func actionCheckBox() {
        if let botonBarView = self.selectedItemsBarView.subviews[0] as? BotonBarView {
            if botonBarView.getChecked(){
                self.userIsInSelectMode = true
                self.selectedRenovationsIndexPath.removeAll()
                botonBarView.mostrarRenovationEvaluationBotonAction()
                var counter = 0
                if self.searchIsActive{
                    botonBarView.setLabelTotal(totalFila: String (renovationsFilteredBySearch.count))
                    for _ in renovationsFilteredBySearch{
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedRenovationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                } else {
                    botonBarView.setLabelTotal(totalFila: String (renovations.count))
                    for _ in renovations {
                        let index = IndexPath(row: counter, section: 0)
                        self.selectedRenovationsIndexPath.append(index)
                        counter = counter  + 1
                    }
                }
                
            }else{
                self.userIsInSelectMode = false
                botonBarView.setLabelSelectTodo()
                botonBarView.ocultarBotonAction()
                var counter = 0
                if searchIsActive {
                    for _ in renovationsFilteredBySearch {
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                            self.selectedRenovationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                } else {
                    for _ in renovations {
                        let index = IndexPath(row: counter, section: 0)
                        if let indexPosition = selectedRenovationsIndexPath.firstIndex(of: index){
                            self.selectedRenovationsIndexPath.remove(at: indexPosition)
                        }
                        counter  = counter  + 1
                    }
                }
            }
        }
        self.tableView.reloadData()
    }
    
    func actionAprobar () {
        print("Se van a aprobar \(self.selectedRenovationsIndexPath.count) solicitudes")
        /*self.approveApplication = true
        self.willBeAMassiveProcess = true*/
        //UserAlerts.showAlertForRenovationsApproval(on: self)
    }
    
    func actionRechazar() {
        
        if selectedRenovationsIndexPath.count > 0 {
            UserAlerts.showAlertForRenovationsApproval(on: self)
        }  else {
            alerts.showToastAlert(vc: self, message: "Debe seleccionar renovaciones para autorizarlas")
        }
        
        
        /*print("Se van a rechazar \(self.selectedRenovationsIndexPath.count) solicitudes")
        self.approveApplication = false
        self.willBeAMassiveProcess = true
        UserAlerts.showAlertForUserObservation(on: self)*/
    }
    
}

extension EvaluarRenovacionesViewController : UIRenovacionTableViewCellDelegate {
    func showRenovationTrack(object: UIRenovacionTableViewCell) {
        let indexPathOfSelectedByTapOnCheck = self.tableView.indexPath(for: object)
        if let secureIndexPath =  indexPathOfSelectedByTapOnCheck{
            if self.searchIsActive {
                let renovationByIndexPathOnSearch = self.renovationsFilteredBySearch[secureIndexPath.row]
                self.selectedRenovation = renovationByIndexPathOnSearch
            } else {
                let renovationByIndexPath = self.renovations[secureIndexPath.row]
                self.selectedRenovation = renovationByIndexPath
            }
            UserAlerts.showTrackingsAlert(on: self, for: selectedRenovation!)
        }
    }
    /*
    func approveApplicationByClickOnCheck(object: UIApplicationTableViewCell) {
        self.approveApplication = true
        self.willBeAMassiveProcess = false
        
    }*/
}



// MARK: - EXTENSION UIObservationInputAlertViewController
extension EvaluarRenovacionesViewController : UIApproveRenovationAlertViewControllerDelegate {
    func authorizeAction() {
        var request = [AprobarRenovacion]()
        if let renovations = self.prepareRenovationsForRequest() {
            request = renovations
        }
        if request.count > 0 {
            let arrays = self.divideArray(approveRenovationsArray: request)
            self.showSpinner(onView: self.view)
            for array in arrays {
                var autorizacionbean = "ios-"
                if let uuid = appDelegate.UUID {
                    autorizacionbean += uuid + "|"
                }
                
                if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
                    autorizacionbean += "\(latitude)|\(longitude)"
                }
                RenovacionWorker.approveRenovation(with: appDelegate.authorizationToken, with: autorizacionbean, parameters: array) { (onSuccessResponse) in
                    
                    if let exito = onSuccessResponse.httpBody.exito {
                        if exito == false {
                            let errorMessage =  onSuccessResponse.httpBody.mensaje ?? "No hay detalle."
                            DispatchQueue.main.async {
                                self.removeSpinner()
                                self.alerts.showToastAlert(vc: self, message: errorMessage)
                                self.retrieveRenovations()
                            }
                        } else {
                            self.currentResponses += 1
                            if self.currentResponses == self.expectedResponses {
                                DispatchQueue.main.async {
                                    self.removeSpinner()
                                    self.alerts.showToastAlert(vc: self, message: "Se autorizó correctamente")
                                    self.retrieveRenovations()
                                }
                                self.currentResponses = 0
                                self.expectedResponses = 0
                            }
                        }
                    } else {
                        //UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_RENOVACION.SUCCES_MESSAGE)
                    }
                } onFailed: { (onFailedResponse) in
                    
                    DispatchQueue.main.async {
                        self.removeSpinner()
                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                        self.retrieveRenovations()
                    }
                    
                    
                } onAuthenticationError: { (onFailedResponse) in
                    self.showExpiredSessionAlert(on: self)
                }
            }
            //self.callApproveService(with: request)
            self.selectedRenovation = nil
        }
        
        //self.callApproveService(with: request)
        //self.selectedRenovation = nil
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
}
// MARK: - EXTENSION DetalleSolicitud
extension EvaluarRenovacionesViewController : DetalleSolicitudViewControllerDelegate {
    
    func applicationApprovedOrRejected() {
        self.retrieveRenovations()
    }
}

// MARK: - EXTENSION UIActionResultAlert
extension EvaluarRenovacionesViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        //self.retrieveRenovations()
    }
}



