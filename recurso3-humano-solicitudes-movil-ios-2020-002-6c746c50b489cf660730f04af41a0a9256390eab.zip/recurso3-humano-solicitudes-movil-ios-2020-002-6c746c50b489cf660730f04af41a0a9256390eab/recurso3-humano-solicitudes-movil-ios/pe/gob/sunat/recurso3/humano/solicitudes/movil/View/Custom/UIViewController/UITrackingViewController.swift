//
//  UITrackingViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/23/20.
//

import UIKit

class UITrackingViewController: ParentViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var viewParent: BorderView!
    @IBOutlet weak var firstView: BorderView!
    var trackings = [SeguimientoRenovacion]()
    var parametersForRenovationDetail : Renovacion?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: RenovacionTrackingTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: RenovacionTrackingTableViewCell.IDENTIFIER)
        
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.viewParent.layer.cornerRadius = 30
        self.firstView.layer.cornerRadius = 30

        

        if let parameters = parametersForRenovationDetail {
            let request = prepareRenovationRequestForDetail(parameters: parameters)
            self.retrieveTracking(using: appDelegate.authorizationToken, with: request)
        }else{
            
        }
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func closeAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func retrieveTracking(using token: String, with request : SeguimientoRenovacionRequest) {
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        
        RenovacionTrackingWorker.getRenovationTracking(with: token, with: autorizacionbean, parameters: request) { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.trackings = onSuccessResponse.httpBody.lista!
                self.tableView.reloadData()
               
            }
        } onFailed: { (onFailed) in
            if onFailed.httpResponse.httpCode.isEmpty{
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            }
        } onAuthenticationError: { (onFailedResponse) in

            
        }
    }


    func prepareRenovationRequestForDetail(parameters : Renovacion)->SeguimientoRenovacionRequest{
        var request = SeguimientoRenovacionRequest()
        request.numIntencion = Int.init(parameters.numIntencion!)
        return request
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UITrackingViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trackings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let cell = tableView.dequeueReusableCell(withIdentifier: RenovacionTrackingTableViewCell.IDENTIFIER ,for: indexPath) as! RenovacionTrackingTableViewCell
            let tracking = trackings[indexPath.row]
            
        if let situacion = tracking.situacion {
            cell.situacionLabel.text = situacion
        }
        if let codRegistro = tracking.codRegistro, let nombPersona = tracking.nombPersona {
            cell.codeAndNameLabel.text = "\(codRegistro) - \(nombPersona)"
        }
        if let estado = tracking.estado {
            cell.estadoAndDesPeriodoLabel.text = "\(estado) "
        }
        if let desPeriodo = tracking.desPeriodo {
            cell.estadoAndDesPeriodoLabel.text = cell.estadoAndDesPeriodoLabel.text! + "- \(desPeriodo)"
        }
        if tracking.obsRenovacion != nil {
            cell.observacionLabel.text = "Observación: \(tracking.obsRenovacion!)"
        } else {
            cell.observacionLabel.text = "No hay observación"
        }
        if let fecha = tracking.fecRegistro {
            var fech = fecha.split(separator: " ")
            cell.fechaLabel.text = String(fech[0])
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*if tableView == self.tableView {
            self.selectedTracking = trackings[indexPath.row]
            self.performSegue(withIdentifier: AppConstants.SEGUE.TRACKING_DETAIL, sender: nil)
        } else if tableView == self.tableExceptional {
            let selectedDetalleLabor = exceptionalWorksDetails[indexPath.row]
            self.showLaborExcepcionalDetalle(detalleLaborExcepcional: selectedDetalleLabor)
        }
 */
    }
    
}
