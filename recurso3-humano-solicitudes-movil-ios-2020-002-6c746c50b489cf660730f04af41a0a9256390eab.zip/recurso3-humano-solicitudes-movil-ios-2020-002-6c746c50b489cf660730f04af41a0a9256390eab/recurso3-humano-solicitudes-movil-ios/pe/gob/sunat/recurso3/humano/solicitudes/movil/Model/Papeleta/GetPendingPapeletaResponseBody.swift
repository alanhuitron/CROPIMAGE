//
//  GetPendingPapeletaResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation
struct GetPendingPapeletaResponseBody:Codable {
    
    var papeletas : [Papeleta]?
 
}
