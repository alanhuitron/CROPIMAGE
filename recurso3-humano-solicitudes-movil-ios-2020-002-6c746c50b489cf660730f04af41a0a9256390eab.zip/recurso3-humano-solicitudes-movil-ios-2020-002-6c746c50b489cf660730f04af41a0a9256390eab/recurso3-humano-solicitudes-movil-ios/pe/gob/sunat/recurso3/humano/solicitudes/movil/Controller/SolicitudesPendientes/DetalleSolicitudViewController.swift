//
//  ApplicationDetailViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/6/19.
//

import UIKit

protocol DetalleSolicitudViewControllerDelegate {
    
    func applicationApprovedOrRejected()

}

class DetalleSolicitudViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var lblApplicationDescription: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableExceptional: UITableView!
    @IBOutlet weak var lblApplicationId: UILabel!
    @IBOutlet weak var lblApplicant: UILabel!
    @IBOutlet weak var lblIssueDate: UILabel!
    @IBOutlet weak var lblObservartions: UILabel!
    @IBOutlet weak var btnReject: UIButton!
    @IBOutlet weak var btnApprove: UIButton!
    
    //
    @IBOutlet weak var lblValueOneTitle: UILabel!
    @IBOutlet weak var lblValueTwoTitle: UILabel!
    @IBOutlet weak var imvValueOneIcon: UIImageView!
    @IBOutlet weak var imvValueTwoIcon: UIImageView!
    @IBOutlet weak var lblValueOne: UILabel!
    @IBOutlet weak var lblValueTwo: UILabel!
    @IBOutlet weak var viewExceptionalWork: BorderView!
    @IBOutlet weak var viewDatesInfo: BorderView!
    @IBOutlet weak var exceptionalTableViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var actionViewParent: UIView!
    
    @IBOutlet weak var lblExceptionalTitle: UILabel!
    @IBOutlet weak var marcacionViewParent: UIView!
    @IBOutlet weak var lblMarcacionTitle: UILabel!
    @IBOutlet weak var lblMarcacionValue: UILabel!
    
    var parametersForApplicationDetail : Solicitud?
    var applicationDetail : Solicitud?
    var trackings = [Seguimiento]()
    var selectedTracking : Seguimiento?
    var approveApplication = false
    var delegate : DetalleSolicitudViewControllerDelegate?
    var exceptionalWorksDetails = [LaborExcepcionalDetalle]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.showSpinner(onView: self.view)
        setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.APPLICATION_DETAIL, leftImage: "iconLeft")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: UITrackingTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: UITrackingTableViewCell.IDENTIFIER)
        self.tableView.tableFooterView = UIView(frame: .zero)
        
        self.tableExceptional.delegate = self
        self.tableExceptional.dataSource = self
        
        self.viewExceptionalWork.isHidden = true
        if let parameters = parametersForApplicationDetail {
            let request = prepareApplicationRequestForDetail(parameters: parameters)
            self.retrieveApplicationDetail(using: appDelegate.authorizationToken, with: request)
        }else{
            self.removeSpinner()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let exceptionalValuesCounter = self.exceptionalWorksDetails.count
        var exceptionalValuesHeight = self.tableExceptional.contentSize.height
        if exceptionalValuesCounter > 5 {
            exceptionalValuesHeight = (exceptionalValuesHeight / CGFloat(integerLiteral: exceptionalValuesCounter)) * 5
            self.exceptionalTableViewHeightConstraint.constant = exceptionalValuesHeight + CGFloat(integerLiteral: 20)
        } else {
            self.exceptionalTableViewHeightConstraint.constant = self.tableExceptional.contentSize.height + CGFloat(integerLiteral: 30)
        }
    }
    
    override func viewDidLayoutSubviews() {
        let maskPath = UIBezierPath(roundedRect: self.actionViewParent.bounds,
                                    byRoundingCorners: [.topLeft, .topRight],
                                    cornerRadii: CGSize(width: 40.0, height: 40.0))

        let shape = CAShapeLayer()
        shape.path = maskPath.cgPath
        self.actionViewParent.layer.mask = shape
        
        let exceptionalValuesCounter = self.exceptionalWorksDetails.count
        var exceptionalValuesHeight = self.tableExceptional.contentSize.height
        if exceptionalValuesCounter > 5 {
            exceptionalValuesHeight = (exceptionalValuesHeight / CGFloat(integerLiteral: exceptionalValuesCounter)) * 5
            self.exceptionalTableViewHeightConstraint.constant = exceptionalValuesHeight + CGFloat(integerLiteral: 20)
        } else {
            self.exceptionalTableViewHeightConstraint.constant = self.tableExceptional.contentSize.height + CGFloat(integerLiteral: 30)
        }
        self.tableExceptional.reloadData()
    }
    
    func prepareApplicationRequestForDetail(parameters : Solicitud)->SolicitudRequest{
        var request = SolicitudRequest()
        request.codPersona=parameters.codPersona
        request.numSolicitud=String(parameters.numSolicitud!)
        request.annSolicitud=parameters.annSolicitud
        return request
    }
    
    func retrieveApplicationDetail(using token: String, with request: SolicitudRequest){
        showSpinner(onView: self.view)
        SolicitudWorker.getDetailRequest(with: token, parameters: request, onSuccess: { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.applicationDetail = onSuccessResponse.httpBody.solicitud!
                self.setUpApplicationStaticFields(application: self.applicationDetail!)
                self.trackings = self.applicationDetail!.seguimientos!
                self.tableView.reloadData()
                
                if self.applicationDetail!.codTipo == SolicitudEspecial.AUTORIZACION_DE_LABOR_EXCEPCIONAL.rawValue {
                    self.exceptionalWorksDetails = self.applicationDetail!.detalles!
                    self.tableExceptional.reloadData()
                }
               
                self.removeSpinner()
            }
        }, onFailed: {(onFailed) in
            self.removeSpinner()
            if onFailed.httpResponse.httpCode.isEmpty{
                UserAlerts.showAlertForUserToServiceAction(on: self, message: "Error de conexion, comprueba tu conexion o prueba una diferente e intentalo más tarde", configuration: .Error)
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: "Ocurrio un error, intentalo más tarde", configuration: .Error)
            }
        }, onAuthenticationError: {(onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        })
    }
    
    func setUpApplicationStaticFields(application : Solicitud){
        self.lblApplicationDescription.text = application.desSolicitud
        let applicationYear = application.annSolicitud ?? ""
        let applicationNum = String(application.numSolicitud ?? 0)
        self.lblApplicationId.text = "\(applicationYear)-\(applicationNum)"
        self.lblApplicant.text = application.nomSolicitante
        self.lblIssueDate.text = application.fecSolicitud
        self.lblObservartions.text = application.desObservacion
        self.lblValueOne.text = application.fecInicio
        self.lblValueTwo.text = application.fecFin
        
        let applicationTypeCode = application.codTipo
        let applicationSpecial = SolicitudEspecial.init(rawValue: applicationTypeCode ?? "")
        switch  applicationSpecial{
        case .OMISION_DE_MARCACIONES :
            self.marcacionViewParent.isHidden = false
            self.viewExceptionalWork.isHidden = false
            self.lblMarcacionTitle.text = "Marcación Omitida"
            self.lblMarcacionValue.text = application.horMarcacionOmitida
        case .ANULACION_DE_MARCACIONES :
            self.marcacionViewParent.isHidden = false
            self.viewExceptionalWork.isHidden = false
            self.lblMarcacionTitle.text = "Marcación Incorrecta"
            self.lblMarcacionValue.text = application.horMarcacionIncorrecta
        case .AUTORIZACION_DE_LABOR_EXCEPCIONAL :
            self.marcacionViewParent.isHidden = true
            self.viewExceptionalWork.isHidden = false
        default:
            self.lblValueOne.text = application.fecInicio
            self.lblValueTwo.text = application.fecFin
        }
    }
    
    func showLaborExcepcionalDetalle(detalleLaborExcepcional : LaborExcepcionalDetalle){
        DispatchQueue.main.async {
            let alertController = AutorizacionLaborExcepcionalAlerViewController(nibName: "AutorizacionLaborExcepcionalAlerViewController", bundle: nil)
            alertController.asunto = detalleLaborExcepcional.desSustento
            alertController.horaInicio = detalleLaborExcepcional.horInicio
            alertController.horaFin = detalleLaborExcepcional.horFin
            alertController.fechaAutorizacion = detalleLaborExcepcional.fecPermiso
            alertController.modalPresentationStyle = .overCurrentContext
            self.present(alertController, animated: false, completion: nil)
        }
    }

    @IBAction func rejectApplication(_ sender: Any) {
        self.approveApplication = false
        UserAlerts.showAlertForUserObservation(on: self)
    }
    @IBAction func approveApplication(_ sender: Any) {
        self.approveApplication = true
        UserAlerts.showAlertForUserObservation(on: self)
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DetalleSeguimientoViewController {
            vc.applicationParametersForTrackingDetail = self.parametersForApplicationDetail
            vc.trackingParametersForTrackingDetail = self.selectedTracking
        }
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension DetalleSolicitudViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableExceptional {
            return exceptionalWorksDetails.count
        } else {
            return trackings.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tableExceptional {
            let cell = tableView.dequeueReusableCell(withIdentifier: UILaborExcepcionalTableViewCell.IDENTIFIER ,for: indexPath) as! UILaborExcepcionalTableViewCell
            let exceptionalWork = self.exceptionalWorksDetails[indexPath.row]
            
            cell.lblAuthorizationDate.text = exceptionalWork.fecPermiso
            cell.lblStartHour.text = exceptionalWork.horInicio
            cell.lblEndHour.text = exceptionalWork.horFin
            cell.lblAffair.text = exceptionalWork.desSustento
            
            return cell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: UITrackingTableViewCell.IDENTIFIER ,for: indexPath) as! UITrackingTableViewCell
            let application = trackings[indexPath.row]
            
            cell.lblReceptionDate.text = application.fecRecepcion
            cell.lblIssuerName.text = application.nomRemitente
            cell.lblAddressee.text = application.nomDestinatario
            cell.lblActionDescription.text = application.desAccion
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == self.tableExceptional {
            return UITableView.automaticDimension
        } else {
            return 70
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tableView {
            self.selectedTracking = trackings[indexPath.row]
            self.performSegue(withIdentifier: AppConstants.SEGUE.TRACKING_DETAIL, sender: nil)
        } else if tableView == self.tableExceptional {
            let selectedDetalleLabor = exceptionalWorksDetails[indexPath.row]
            self.showLaborExcepcionalDetalle(detalleLaborExcepcional: selectedDetalleLabor)
        }
    }
    
}

// MARK: - HeaderViewDelegate
extension DetalleSolicitudViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goBackMore()
    }
    
}

// MARK: - UIObservationInputAlertViewControllerDelegate
extension DetalleSolicitudViewController : UIObservationInputAlertViewControllerDelegate {
    
    func observationWasAdded(observation: String) {
        if self.approveApplication {
            var request = AprobarSolicitudRequest()
            request.codPersonaSolicitud = applicationDetail?.codPersona
            request.annSolicitud = applicationDetail?.annSolicitud
            if let numSolicitud = applicationDetail?.numSolicitud {
                request.numSolicitud = String(numSolicitud)
            }
            request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
            request.codLoginAprobador = appDelegate.currentUser.userName
            request.desMensajeAprobacion = observation
            request.numLatitud = appDelegate.location?.latitude.description
            request.numLongitud = appDelegate.location?.longitude.description
            SolicitudWorker.approvePendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
                if let errores = onSuccessResponse.httpBody.errores {
                    if errores.count > 0 {
                        let errorMessage =  onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle."
                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBAR_SOLICITUD.WARNING_TITLE, message: errorMessage, configuration: .Warning)
                    } else {
                        UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.SUCCES_MESSAGE)
                    }
                } else {
                    UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.SUCCES_MESSAGE)
                }
                
            }, onFailed: {(onFailedResponse) in
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_SOLICITUD.FAIL_MESSAGE, configuration: .Error)
            }, onAuthenticationError: {(onFailedResponse) in
                self.showExpiredSessionAlert(on: self)
            })
            
        } else {
            var request = RechazarSolicitudRequest()
            request.codPersonaSolicitud = applicationDetail?.codPersona
            request.annSolicitud = applicationDetail?.annSolicitud
            if let numSolicitud = applicationDetail?.numSolicitud {
                request.numSolicitud = String(numSolicitud)
            }
            request.nroRegistroAprobador = appDelegate.currentUser.registryNumber
            request.codLoginAprobador = appDelegate.currentUser.userName
            request.desMensajeAprobacion = observation
            request.numLatitud = appDelegate.location?.latitude.description
            request.numLongitud = appDelegate.location?.longitude.description
            SolicitudWorker.rejectPendingApplication(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
                if let errores = onSuccessResponse.httpBody.errores {
                    if errores.count > 0 {
                        let errorMessage =  onSuccessResponse.httpBody.errores?[0].msg ?? "No hay detalle."
                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.RECHAZAR_SOLICITUD.WARNING_TITLE, message: errorMessage, configuration: .Warning)
                    } else {
                        UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.SUCCES_MESSAGE)
                    }
                } else {
                    UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.SUCCES_MESSAGE)
                }
            }, onFailed: {(onFailedResponse) in
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.RECHAZAR_SOLICITUD.FAIL_MESSAGE, configuration: .Error)
            
            }, onAuthenticationError: {(onFailedResponse) in
                self.showExpiredSessionAlert(on: self)
            })
        }
        
    }

}

extension DetalleSolicitudViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        DispatchQueue.main.async {
            self.delegate?.applicationApprovedOrRejected()
            self.goBackMore()
        }
    }
}


enum SolicitudEspecial : String {
    case OMISION_DE_MARCACIONES = "10"
    case ANULACION_DE_MARCACIONES = "60"
    case AUTORIZACION_DE_LABOR_EXCEPCIONAL = "124"
}

