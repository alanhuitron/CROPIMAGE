//
//  ParametrosBusqueda.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 11/4/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation
struct ParametrosBusqueda : Codable {
    
    var codTipo  : String?
    var numSolicitud  : String?
    var desAsunto   : String?
    var fecRegistroAntes   : String?
    var fecDerivadaAntes  : String?
    var codEmisor : String?
    var codUltimoResponsable : String?
    var fecInicio : String?
    var fecFin : String?
    var codPersona : String?
    var codUnidad : String?
}
