//
//  AprobacionMasivaSolicitudesResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/28/19.
//

import Foundation

struct AprobacionMasivaSolicitudesResponseBody : Codable {
    
    var indProceso : String?
    var cantidadSolicitudesAtendidas : Int?
    var solicitudError :Solicitud?
    var errores : [Errores]?
}
