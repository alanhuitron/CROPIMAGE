//
//  MarcacionWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

import Foundation
class MarcacionWorker {
    
    static func getAttendaceRecords(with token: String, forUser userRegistryNum: String,
                                onSuccess success: @escaping (_ response: ObtenerMarcacionesResponse) -> Void,
                                onFailed failed: @escaping (_ response: ObtenerMarcacionesResponse) -> Void ,
                                onAuthenticationError authFailed: @escaping (_ response: ObtenerMarcacionesResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(userRegistryNum)/marcaciones/listar"
        print("Enviando peticion al servicio : \(endpointURL)")
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
         
        
         let configuration  = URLSessionConfiguration.default
         let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
         let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
             if(response == nil){
                 var responseFailed=ObtenerMarcacionesResponse()
                 responseFailed.httpResponse.success = false
                 failed(responseFailed)
             }else{
                 let httpResponse = response as! HTTPURLResponse
                 let statusCode = httpResponse.statusCode
                 var response = ObtenerMarcacionesResponse()
                 let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                 print("Se recibio el Http status : \(statusCode)")
                 print("Se recibio el Http body" + dataAsString)
                 switch statusCode {
                 case 200:
                     response.httpBody.marcaciones = JSONParser.decode([Marcacion].self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     success(response)
                 case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                 default:
                    var responseFailed=ObtenerMarcacionesResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    failed(responseFailed)
                 }
             }
         })
         task.resume()
     }
    
    static func registerAttendanceRecord(with token: String,
                                   parameters: RegistrarMarcacionRequest,
                                 onSuccess success: @escaping (_ response: RegistrarMarcacionResponse) -> Void,
                                 onFailed failed: @escaping (_ response: RegistrarMarcacionResponse) -> Void,
                                 onAuthenticationError authFailed: @escaping (_ response: RegistrarMarcacionResponse) -> Void){
            
            let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
            let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.codPersona ?? "")/marcaciones/registrarDesdeApp"
            print("Enviando peticion al servicio : \(endpointURL)")
            let endpoint = URL(string: endpointURL)

             var request = URLRequest(url: endpoint!)
             request.httpMethod = HttpMethod.POST.rawValue
             request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
             request.addValue("application/json", forHTTPHeaderField: "Content-Type")
             request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            request.httpBody=JSONParser.encode(parameters)
            print("Enviando el Http body", String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=RegistrarMarcacionResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = RegistrarMarcacionResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("Se recibio el Http status : \(statusCode)")
                    print("Se recibio el Http body" + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.errorMarcaciones = JSONParser.decode([ErrorMarcacion].self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        success(response)
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                    default:
                       var responseFailed=RegistrarMarcacionResponse()
                       responseFailed.httpResponse.success = false
                       responseFailed.httpResponse.httpCode = String(statusCode)
                       failed(responseFailed)
                    }
                }
            })
            task.resume()
        }
}
