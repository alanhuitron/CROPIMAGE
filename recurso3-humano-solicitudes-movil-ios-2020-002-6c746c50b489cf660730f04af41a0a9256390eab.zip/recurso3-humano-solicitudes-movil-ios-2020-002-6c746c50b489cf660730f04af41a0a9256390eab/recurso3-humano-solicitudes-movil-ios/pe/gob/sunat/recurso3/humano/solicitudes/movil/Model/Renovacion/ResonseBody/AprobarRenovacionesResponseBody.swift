//
//  AprobarRenovacionesResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/25/20.
//

import Foundation

class AprobarRenovacionesResponseBody : Decodable {
    var exito : Bool?
    var mensaje : String?
}
