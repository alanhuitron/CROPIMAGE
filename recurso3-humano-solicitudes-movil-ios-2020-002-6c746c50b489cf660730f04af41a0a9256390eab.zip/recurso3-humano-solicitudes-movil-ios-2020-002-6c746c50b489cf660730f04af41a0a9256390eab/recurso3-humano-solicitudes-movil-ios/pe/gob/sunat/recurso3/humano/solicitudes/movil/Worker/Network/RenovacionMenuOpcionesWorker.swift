//
//  RenovacionMenuWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/18/20.
//

import Foundation

class RenovacionMenuOpcionesWorker {
    
    static func getEsResponsable(with token: String, forUser userRegistryNum: String,
                             onSuccess success: @escaping (_ response: GetRenovationOptionResponse) -> Void,
                             onFailed failed: @escaping (_ response: GetRenovationOptionResponse) -> Void,
                             onAuthenticationError authFailed: @escaping (_ response: GetRenovationOptionResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/esResponsableUnidad?codPersona=\(userRegistryNum)"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=GetRenovationOptionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = GetRenovationOptionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print(dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.response = JSONParser.decode(Bool.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                default:
                   var responseFailed=GetRenovationOptionResponse()
                   responseFailed.httpResponse.success = false
                   responseFailed.httpResponse.httpCode = String(statusCode)
                   failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func getEsIntendente(with token: String, forUser userRegistryNum: String,
                             onSuccess success: @escaping (_ response: GetRenovationOptionResponse) -> Void,
                             onFailed failed: @escaping (_ response: GetRenovationOptionResponse) -> Void,
                             onAuthenticationError authFailed: @escaping (_ response: GetRenovationOptionResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/esIntendente?codPersona=\(userRegistryNum)"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=GetRenovationOptionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = GetRenovationOptionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print(dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.response = JSONParser.decode(Bool.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                default:
                   var responseFailed=GetRenovationOptionResponse()
                   responseFailed.httpResponse.success = false
                   responseFailed.httpResponse.httpCode = String(statusCode)
                   failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    
    static func getNotificationNumber(with token: String, parameters: ObtenerNumeroRenovacionesRequest,
                             onSuccess success: @escaping (_ response: ObtenerNumeroRenovacionesResponse) -> Void,
                             onFailed failed: @escaping (_ response: ObtenerNumeroRenovacionesResponse) -> Void,
                             onAuthenticationError authFailed: @escaping (_ response: ObtenerNumeroRenovacionesResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/listarenovacioncount"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=ObtenerNumeroRenovacionesResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = ObtenerNumeroRenovacionesResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print(dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(ObtenerNumeroRenovacionesResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                default:
                   var responseFailed=ObtenerNumeroRenovacionesResponse()
                   responseFailed.httpResponse.success = false
                   responseFailed.httpResponse.httpCode = String(statusCode)
                   failed(responseFailed)
                }
            }
        })
        task.resume()
    }
}
