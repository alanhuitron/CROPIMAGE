//
//  FirmarRenovacionTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import UIKit

@objc protocol FirmarRenovacionTableViewCellDelegate {
    @objc func firmarRenovacion(desAccionRenov: String?, codTipoRenov: String?, numPeriRenov: Int, desTipoRenov: String?, codRegistro: String?, codPdf: String?, numIntencion : String?)
}

class FirmarRenovacionTableViewCell: UITableViewCell {

    static let NAME = "FirmarRenovacionTableViewCell"
    static let IDENTIFIER = "FirmarRenovacionTableViewCell"
    
    
    @IBOutlet weak var periodoLabel: UILabel!
    @IBOutlet weak var renuevaLabel: UILabel!
    @IBOutlet weak var estadoLabel: UILabel!
    @IBOutlet weak var actionView: UIView!
    @IBOutlet weak var signOrDownloadButton: UIButton!
    @IBOutlet weak var actionLabel: UILabel!
    var renovation: RenovacionPorFirmar?
    var delegate : FirmarRenovacionTableViewCellDelegate?

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func signOrDownloadAction(_ sender: Any) {
        let numeroPeriRenov = Int((self.renovation?.numPerirenov)!)
        self.delegate?.firmarRenovacion(desAccionRenov: (self.renovation?.desAccionRenov), codTipoRenov: (self.renovation?.codTiporenov) , numPeriRenov: numeroPeriRenov!, desTipoRenov: (self.renovation?.desTipoRenov), codRegistro: (self.renovation?.codPersonal), codPdf: ((self.renovation?.codDocfircola)), numIntencion: (self.renovation?.numIntencion))
    }
    
}
