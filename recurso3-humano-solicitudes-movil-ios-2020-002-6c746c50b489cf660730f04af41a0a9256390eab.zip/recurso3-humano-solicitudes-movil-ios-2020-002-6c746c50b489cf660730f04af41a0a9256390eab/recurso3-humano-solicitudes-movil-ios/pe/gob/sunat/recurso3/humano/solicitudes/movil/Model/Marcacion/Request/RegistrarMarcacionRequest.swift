//
//  RegistrarMarcacionRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

struct RegistrarMarcacionRequest : Codable {
    
    var codPersona : String?
    var ubicacion : Ubicacion?
    
}
