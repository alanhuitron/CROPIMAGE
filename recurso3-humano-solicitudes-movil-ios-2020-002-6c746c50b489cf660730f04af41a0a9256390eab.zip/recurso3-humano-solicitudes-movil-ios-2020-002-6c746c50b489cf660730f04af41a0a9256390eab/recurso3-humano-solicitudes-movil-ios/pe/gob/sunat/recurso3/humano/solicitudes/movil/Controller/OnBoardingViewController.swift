//
//  OnBoardingViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/30/20.
//

import Foundation
import UIKit

class OnBoardingViewController : ParentViewController {
    
    @IBOutlet weak var onBoardingGifImageView: UIImageView!
    @IBOutlet weak var startNowButton: UIButton!
    let userDefaults = UserDefaults.standard
    
    override func viewDidLoad() {
        let gif = UIImage.gif(name: "onBoarding")
        onBoardingGifImageView.image = gif
        self.startNowButton.roundBorders(corner: 5.0)
    }
    
    @IBAction func startNowButtonAction(_ sender: Any) {
        self.locationManager.requestWhenInUseAuthorization()
        let UUID = UIDevice.current.identifierForVendor?.uuidString
        userDefaults.set(true, forKey: "locationPermission")
        userDefaults.set(UUID!, forKey: "UUID")
        appDelegate.UUID = UUID
    }
    
}
