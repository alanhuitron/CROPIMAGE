//
//  SeguimientoWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation
class SeguimientoWorker {
    
    
    static func getDetailTracking(with token: String,
                                  forUser userRegistryNum: String,
                                  parameters: SeguimientoRequest,
                                onSuccess success: @escaping (_ response: SeguimientoResponse) -> Void,
                                onFailed failed: @escaping (_ response: SeguimientoResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: SeguimientoResponse) -> Void){
           
            let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
            let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(userRegistryNum)/seguimiento"
            let endpoint = URL(string: endpointURL)

            var request = URLRequest(url: endpoint!)
            request.httpMethod = HttpMethod.POST.rawValue
            request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            request.httpBody=JSONParser.encode(parameters)
            print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               if(response == nil){
                   var responseFailed=SeguimientoResponse()
                   responseFailed.httpResponse.success = false
                   failed(responseFailed)
               }else{
                   let httpResponse = response as! HTTPURLResponse
                   let statusCode = httpResponse.statusCode
                   var response = SeguimientoResponse()
                   let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                   print("Detalle seguimiento : " + dataAsString)
                   switch statusCode {
                   case 200:
                       response.httpBody.seguimiento = JSONParser.decode(Seguimiento.self, from: data!)!
                       response.httpResponse.success = true
                       response.httpResponse.httpCode = String(statusCode)
                       success(response)
                   case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                   case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                   default:
                        var responseFailed=SeguimientoResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                    }
                }
        })
        task.resume()
    }
}
