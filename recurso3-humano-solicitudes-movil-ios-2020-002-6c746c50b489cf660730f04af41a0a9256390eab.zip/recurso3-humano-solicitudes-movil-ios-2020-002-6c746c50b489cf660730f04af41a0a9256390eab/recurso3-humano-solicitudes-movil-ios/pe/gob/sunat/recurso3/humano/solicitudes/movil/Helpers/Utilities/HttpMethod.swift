//
//  HttpMethod.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/14/19.
//

import Foundation

enum HttpMethod : String {
    case GET = "GET"
    case POST = "POST"
    case PUT = "PUT"
}
