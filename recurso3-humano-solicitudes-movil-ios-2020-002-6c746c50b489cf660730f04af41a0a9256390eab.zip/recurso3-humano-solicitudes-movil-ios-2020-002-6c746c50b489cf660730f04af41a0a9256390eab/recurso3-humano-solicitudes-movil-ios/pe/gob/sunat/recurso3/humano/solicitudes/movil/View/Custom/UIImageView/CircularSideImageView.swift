//
//  CircularSideImageView.swift
//  AppPrecintos
//
//  Created by Rommy Fuentes Davila Otani on 9/6/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

class CircularSideImageView: UIImageView {
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        self.layer.cornerRadius = self.frame.size.height/2
        self.clipsToBounds = true
    }
}
