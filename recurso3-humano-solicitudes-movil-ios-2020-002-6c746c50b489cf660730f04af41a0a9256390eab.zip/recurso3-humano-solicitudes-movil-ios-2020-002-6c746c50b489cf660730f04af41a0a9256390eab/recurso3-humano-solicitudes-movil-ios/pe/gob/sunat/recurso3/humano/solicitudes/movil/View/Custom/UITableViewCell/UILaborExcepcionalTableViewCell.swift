//
//  UILaborExcepcionalTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 12/3/19.
//

import UIKit

class UILaborExcepcionalTableViewCell: UITableViewCell {
    
    static let IDENTIFIER = "UILaborExcepcionalTableViewCell"

    @IBOutlet weak var lblAuthorizationDate: UILabel!
    @IBOutlet weak var lblStartHour: UILabel!
    @IBOutlet weak var lblEndHour: UILabel!
    @IBOutlet weak var lblAffair: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
