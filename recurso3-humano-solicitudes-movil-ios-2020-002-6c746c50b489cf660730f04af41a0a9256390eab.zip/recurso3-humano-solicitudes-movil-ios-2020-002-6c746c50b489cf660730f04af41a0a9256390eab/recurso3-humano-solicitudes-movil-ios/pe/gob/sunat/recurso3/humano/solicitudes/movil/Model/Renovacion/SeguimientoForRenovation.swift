//
//  Seguimiento.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import Foundation

class SeguimientoForRenovation : Codable {
    var numIntencion: Int?
    var codTiporenov: String?
    var numPerirenov: Int?
    var obsRenovacion: String?
    var codInisituacion: String?
    var codFinsituacion: String?
    var arcDocfircola: String?
    var codTipofircola: String?
}
