//
//  GetRenovationOptionsResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/19/20.
//

import Foundation

struct GetRenovationOptionResponse : Codable {
    
    var httpResponse = BaseResponse()
    var httpBody = GetRenovationOptionResponseBody()
    
}
