//
//  FirmarRenovacionesViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import UIKit

class FirmarRenovacionesViewController : ParentViewController {
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var emptyState: UIImageView!
    @IBOutlet weak var noResultsLabel: UILabel!
    @IBOutlet weak var noRenovationsForTheMomentLabel: UILabel!
    
    var renovations = [RenovacionPorFirmar]() //general
    var renovationsFilteredBySearch = [RenovacionPorFirmar]() //for applications returned by filter. After received, this array become 'applications' array
    var selectedRenovation : RenovacionPorFirmar? //application selected by simple touch on cell
    var searchIsActive = false
    var approveApplication = false
    var willBeAMassiveProcess = false
    var userIsInSelectMode = false
    var currentNumIntencion = ""
    var selectedRenovationsIndexPath = [IndexPath]()
    let refreshControl = UIRefreshControl()
    var alerts = ToastAlerts()
    var blob64 : String?
    var docName : String? {
        didSet {
            showPDFView(for: docName)
        }
    }
    let userAlerts = UserAlerts()
    
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setHeaderView(headerView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.SIGN_RENOVATIONS, leftImage: "iconLeft")
        self.emptyState.isHidden = true
        self.noResultsLabel.isHidden = true
        self.noRenovationsForTheMomentLabel.isHidden = true
        //table view setup
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib(nibName: FirmarRenovacionTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: FirmarRenovacionTableViewCell.IDENTIFIER)
        self.tableView.tableFooterView = UIView(frame: .zero)
            //adding refresh control for refresh on pull gesture
        self.tableView.refreshControl = refreshControl
        self.refreshControl.addTarget(self, action: #selector(retrievePendingSignRenovations), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.refreshControl.attributedTitle = NSAttributedString(string: "Recuperando renovaciones ...", attributes: attributes)


        self.retrievePendingSignRenovations()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: false)
        }
        print("viewWillAppear indexSelected after clean \(selectedRenovationsIndexPath.count)")
    }
    
    
    // MARK: - Miscellaneous Fuctions


    private func selectCellOn(indexPath : IndexPath){
        print("selected :\(indexPath.row)")
        let cell = tableView.cellForRow(at: indexPath)
        if selectedRenovationsIndexPath.contains(indexPath){
            cell?.backgroundColor = .white
            if let index = selectedRenovationsIndexPath.firstIndex(of: indexPath){
                selectedRenovationsIndexPath.remove(at: index)
            }
        } else {
            cell!.backgroundColor = UIColor(netHex: 0xD1D1D6)
            selectedRenovationsIndexPath.append(indexPath)
        }
        
    }
    
    func prepareDefaultRenovationRequest()->ObtenerRenovacionesRequest{
        var request = ObtenerRenovacionesRequest()
        request.codUOrga = "TODOS"
        request.codSituacion = "09"
        request.dependencias = "0"
        return request
    }
    
    func showPDFView(for pdfName: String?) {
        let storyboard = UIStoryboard(name: "FirmarRenovaciones", bundle: nil)
        
        DispatchQueue.global().async {
            DispatchQueue.main.async {
                let vc = storyboard.instantiateViewController(withIdentifier: "pdfViewController") as! PDFViewController
                vc.PDFName = pdfName
                vc.blob64 = self.blob64
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)
            }
        }
    }
    
    @objc func retrievePendingSignRenovations(){
        self.searchIsActive = false
        self.renovationsFilteredBySearch.removeAll()
        self.selectedRenovationsIndexPath.removeAll()
        self.showSpinner(onView: self.view)
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        self.showSpinner(onView: self.view)
        FirmarRenovacionWorker.getPendingSignRenovations(with: appDelegate.authorizationToken,with: autorizacionbean, with: appDelegate.currentUser.registryNumber) { (onSuccessResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.renovations = onSuccessResponse.httpBody.lista!
                if self.renovations.count == 0 {
                    self.emptyState.isHidden = false
                    self.noResultsLabel.isHidden = false
                    self.noRenovationsForTheMomentLabel.isHidden = false
                } else {
                    self.emptyState.isHidden = true
                    self.noResultsLabel.isHidden = true
                    self.noRenovationsForTheMomentLabel.isHidden = true
                    self.tableView.isHidden = false

                }
                self.removeSpinner()
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        } onFailed: { (onFailed) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.renovationsFilteredBySearch.removeAll()
                print("falló la obtención")
                self.renovations.removeAll()
                self.tableView.reloadData()
                self.emptyState.isHidden = false
                self.noResultsLabel.isHidden = false
                self.noRenovationsForTheMomentLabel.isHidden = false
            }
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            
        } onAuthenticationError: { (onFailedResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                print("falló la autenticación")
                self.refreshControl.endRefreshing()
                self.showExpiredSessionAlert(on: self)
            }
        }
    }
}

extension FirmarRenovacionesViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if renovations.count == 0 {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: false)
        } else {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: true)
        }
        
        if searchIsActive {
            return renovationsFilteredBySearch.count
        }
        return renovations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: FirmarRenovacionTableViewCell.IDENTIFIER ,for: indexPath) as! FirmarRenovacionTableViewCell
        cell.selectionStyle = .none
        
        let renovation : RenovacionPorFirmar?
        if searchIsActive {
            renovation = renovationsFilteredBySearch[indexPath.row]
        } else {
            renovation = renovations[indexPath.row]
        }
        
        if selectedRenovationsIndexPath.contains(indexPath){
            cell.backgroundColor = UIColor(netHex: 0xD1D1D6)
        } else {
            cell.backgroundColor = UIColor(netHex: 0xFFFFFF)
        }
        
        if let renovation = renovation {
            cell.renovation = renovation
        }
        
        if let fecIniPeriodo = renovation?.fecIniperiodo, let fecFinPeriodo = renovation?.fecFinperiodo {
            let dateFormatterGet = DateFormatter()
            dateFormatterGet.dateFormat = "dd/MM/yyyy"
            dateFormatterGet.locale = NSLocale(localeIdentifier: "es_ES") as Locale
            let dateFormatterPrint = DateFormatter()
            dateFormatterPrint.dateFormat = "dd MMM. yyyy"
            dateFormatterPrint.locale = NSLocale(localeIdentifier: "es_ES") as Locale
            if let dateIni = dateFormatterGet.date(from: fecIniPeriodo), let dateFin = dateFormatterGet.date(from: fecFinPeriodo) {
                cell.periodoLabel.text =  "Periodo: \(dateFormatterPrint.string(from: dateIni)) al  \(dateFormatterPrint.string(from: dateFin))"
            }
        } else  {
            cell.periodoLabel.text =  "Sin periodo de renovación"
        }
        if let tipoRenov = renovation?.desTipoRenov {
            cell.renuevaLabel.text = tipoRenov + " - "
        }
        
        if let desEstadoRenov = renovation?.desEstadoRenov {
            cell.estadoLabel.text = desEstadoRenov
            if desEstadoRenov == "Pendiente" {
                cell.estadoLabel.textColor = UIColor(named: "pendienteColor")
            } else {
                cell.estadoLabel.textColor = UIColor.green
            }
        }
        
        cell.actionView.colorBordersAndRoundCorners()
        
        if let desAccionRenov = renovation?.desAccionRenov {
            print(desAccionRenov)
            if (desAccionRenov == "Descargar") {
                let downloadImage = UIImage(named: "downloadIcon")
                let tintedImage = downloadImage?.withRenderingMode(.alwaysTemplate)
                cell.signOrDownloadButton.setImage(tintedImage, for: .normal)
                cell.signOrDownloadButton.tintColor = .green
                cell.actionLabel.text = "Descargar"
                cell.actionLabel.textColor = .green
            } else {
                let downloadImage = UIImage(named: "check")
                let tintedImage = downloadImage?.withRenderingMode(.alwaysTemplate)
                cell.signOrDownloadButton.setImage(tintedImage, for: .normal)
                cell.signOrDownloadButton.tintColor = UIColor(named: "appColor")
                cell.actionLabel.text = "Firmar"
                cell.actionLabel.textColor = UIColor(named: "appColor")
            }
        }
        
        cell.delegate = self
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if userIsInSelectMode {
            self.selectCellOn(indexPath: indexPath)
        } else {
            self.selectedRenovation = renovations[indexPath.row]
            print("celda seleccionada")
            //self.performSegue(withIdentifier: AppConstants.SEGUE.RENOVATION_DETAIL, sender: nil)
        }
    }
    
    func setupHiddenPropertyForNotFoundRelatedViews(isHidden :  Bool){
        if !isHidden {
            self.emptyState.isHidden = isHidden
            self.tableView.backgroundColor = .clear
        } else {
            self.emptyState.isHidden = isHidden
            self.tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


// MARK: - EXTENSION HeaderView
extension FirmarRenovacionesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.openMenu()
    }
    
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchBar.setValue("Cancelar", forKey: "cancelButtonText")
        searchBar.showsCancelButton = true
        searchBar.enablesReturnKeyAutomatically = true
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = nil
        searchBar.showsCancelButton = false
        //Remove focus from the search bar.
        searchBar.endEditing(true)
        renovationsFilteredBySearch = []
        searchIsActive = false;
        self.tableView.reloadData()
     }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
        searchBar.resignFirstResponder()
    }
    
}


// MARK: - EXTENSION UIActionResultAlert
extension FirmarRenovacionesViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        //self.retrievePendingSignRenovations()
    }
}

extension FirmarRenovacionesViewController : FirmarRenovacionTableViewCellDelegate {
    func firmarRenovacion(desAccionRenov: String?, codTipoRenov: String?, numPeriRenov: Int, desTipoRenov: String?, codRegistro: String?, codPdf: String?, numIntencion : String?) {
        if let numIntencion = numIntencion {
            self.currentNumIntencion = numIntencion
        }
        
        if let desAccionRenov = desAccionRenov {
            if(desAccionRenov == "Descargar") {
                var descargarRenovacionParams = DescargarRenovacionRequest()
                descargarRenovacionParams.codRegistro = appDelegate.currentUser.registryNumber
                if let codPdf = codPdf {
                    descargarRenovacionParams.codPDF = codPdf
                }
                
                var autorizacionbean = "ios-"
                if let uuid = appDelegate.UUID {
                    autorizacionbean += uuid + "|"
                }
                
                if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
                    autorizacionbean += "\(latitude)|\(longitude)"
                }
                self.showSpinner(onView: self.view)
                FirmarRenovacionWorker.downloadRenovation(with: appDelegate.authorizationToken, with: autorizacionbean, with: descargarRenovacionParams) { (onSuccessResponse) in
                    if let blob64 = onSuccessResponse.httpBody.blobBase64, let documentName = onSuccessResponse.httpBody.nomArchivo {
                        print(blob64)
                        
                        self.saveBase64StringToPDF(blob64, docName: documentName)
                        self.blob64 = blob64
                        self.docName = documentName
                        
                        self.removeSpinner()
                    } else {
                        self.alerts.showToastAlert(vc: self, message: "No se pudo descargar el PDF de la renovación")
                    }
                    
                } onFailed: { (onFailedResponse) in
                    self.removeSpinner()
                    UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                    print("Falló el response de la descarga de PDF")
                } onAuthenticationError: { (onFailedResponse) in
                    self.removeSpinner()
                    self.showExpiredSessionAlert(on: self)
                }

            } else if (desAccionRenov == "Confirmar"){
                var seguimientos = [SeguimientoForRenovation]()
                var autorizacionbean = "ios-"
                if let uuid = appDelegate.UUID {
                    autorizacionbean += uuid + "|"
                }
                
                if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
                    autorizacionbean += "\(latitude)|\(longitude)"
                }
                
                if let numIntencion = Int(numIntencion!), let codTiporenov = codTipoRenov {
                    let seguimiento = prepareRenovationForAppend(numIntencion: numIntencion, codTiporenov: codTiporenov, numPerirenov: numPeriRenov)
                    seguimientos = [seguimiento]
                }
                
                print(autorizacionbean)
                FirmarRenovacionWorker.guardarSeguimiento(with: appDelegate.authorizationToken, with: autorizacionbean, with: seguimientos) { (onSuccessResponse) in
                    if onSuccessResponse.exito  == true {
                        print("Se guardó el seguimiento con éxito")
                    } else {
                        print("Algo salió mal con el seguimiento")
                    }
                } onFailed: { (onFailed) in
                    print("Falló el request")
                } onAuthenticationError: { (onFailedResponse) in
                    print("No se autenticó")
                }

                if renuevaNoRenueva(desTipoRenov: desTipoRenov!) {
                    UserAlerts.showAlertForRenovationConfirmation(on: self, numPeriRenov: numPeriRenov)
                } else {
                    UserAlerts.showAlertForRenovationDownload(on: self, numPeriRenov: numPeriRenov)
                }
            }
        }
        
    }
    
    func prepareRenovationForAppend(numIntencion: Int, codTiporenov: String, numPerirenov: Int) -> SeguimientoForRenovation {
        let seguimiento = SeguimientoForRenovation()
        seguimiento.numIntencion = numIntencion
        seguimiento.codTiporenov = codTiporenov
        seguimiento.numPerirenov = numPerirenov
        seguimiento.obsRenovacion = "Personal accedió al link de intención de renovación"
        seguimiento.codInisituacion = "09"
        seguimiento.codFinsituacion = "09"
        seguimiento.arcDocfircola = ""
        seguimiento.codTipofircola = ""
        return seguimiento
    }
    
    func prepareSignTrackingForAppend(numIntencion: Int, codTiporenov: String, numPerirenov: Int, arcDocFircola : String) -> SeguimientoForRenovation {
        let seguimiento = SeguimientoForRenovation()
        seguimiento.numIntencion = numIntencion
        seguimiento.codTiporenov = codTiporenov
        seguimiento.numPerirenov = numPerirenov
        if codTiporenov == "01" || codTiporenov == "04" {
            seguimiento.obsRenovacion = "Personal confirma firma de renovación"
        } else {
            seguimiento.obsRenovacion = "Personal confirma firma de no renovación"
        }
        
        seguimiento.codInisituacion = "09"
        seguimiento.codFinsituacion = "10"
        if codTiporenov != "04" {
            seguimiento.arcDocfircola = arcDocFircola
        } else {
            seguimiento.arcDocfircola = ""
        }
        seguimiento.codTipofircola = "1"
        return seguimiento
    }
    
    func renuevaNoRenueva(desTipoRenov: String) -> Bool {
        if desTipoRenov == "RENUEVA" {
            return true
        } else {
            
        }
        return false
    }
    
    
    func saveBase64StringToPDF(_ base64String: String, docName: String) {
        var documentName = docName
        guard
            var documentsURL = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last,
            let convertedData = Data(base64Encoded: base64String)
            else {
            //handle error when getting documents URL
            return
        }
        

        if !documentName.contains(".pdf") {
            documentName = documentName + ".pdf"
        }
        //name your file however you prefer
        documentsURL.appendPathComponent("\(documentName)")

        do {
            try convertedData.write(to: documentsURL)
        } catch {
            //handle write error here
        }

        print(documentsURL)
    }
}

extension FirmarRenovacionesViewController : UIDescargarIntencionRenovacionAlertViewControllerDelegate   {
    func confirmarRenovacion(username: String, password: String) {
        // Servicio 06
        var confirmarRenovacion = ConfirmarRenovacion()
        confirmarRenovacion.login = username
        confirmarRenovacion.clave = password
        confirmarRenovacion.numIntencion = self.currentNumIntencion
        
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        self.showSpinner(onView: self.view)
        FirmarRenovacionWorker.confirmarRenovacion(with: appDelegate.authorizationToken, with: autorizacionbean, with: confirmarRenovacion) { (onSuccessResponse) in
            if let exito  = onSuccessResponse.httpBody.exito {
                if exito == true {
                    print(onSuccessResponse.httpBody.mensaje!)
                    DispatchQueue.main.async {
                        let numInt = Int(self.currentNumIntencion)
                        var seguimientos = [SeguimientoForRenovation]()
                        if let arcDocFircola = onSuccessResponse.httpBody.mensaje, let numInt = numInt {
                            let seguimiento = self.prepareSignTrackingForAppend(numIntencion: numInt, codTiporenov: "02", numPerirenov: 0, arcDocFircola: arcDocFircola)
                            seguimientos = [seguimiento]
                        }
                        
                        FirmarRenovacionWorker.guardarSeguimiento(with: self.appDelegate.authorizationToken, with: autorizacionbean, with: seguimientos) { (onSuccessResponse) in
                            if onSuccessResponse.exito  == true {
                                print("Se guardó el seguimiento de firma con éxito")
                            } else {
                                print("Algo salió mal con el seguimiento de firma")
                            }
                        } onFailed: { (onFailed) in
                            print("Falló el request")
                        } onAuthenticationError: { (onFailedResponse) in
                            print("No se autenticó")
                        }
                        
                        self.alerts.showToastAlert(vc: self, message: "Se firmó la renovación con éxito")
                        self.removeSpinner()
                        self.retrievePendingSignRenovations()
                        self.tableView.reloadData()
                    }
                } else {
                    DispatchQueue.main.async {
                        //self.alerts.showToastAlert(vc: self, message: "Algo salió mal al firmar la renovación")
                        self.removeSpinner()
                        self.retrievePendingSignRenovations()
                        self.tableView.reloadData()
                    }
                    if let mensaje = onSuccessResponse.httpBody.mensaje {
                        self.alerts.showToastAlert(vc: self, message: mensaje)
                        
                    }
                }
            }
        } onFailed: { (onFailedResponse) in
            DispatchQueue.main.async {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                self.removeSpinner()
                self.retrievePendingSignRenovations()
                self.tableView.reloadData()
            }
        } onAuthenticationError: { (onFailed) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }

    func downloadNotRenovationLetter() {
        
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        
        FirmarRenovacionWorker.descargarCartaNoRenovacion(with: appDelegate.authorizationToken, with: autorizacionbean, with: self.currentNumIntencion) {  (onSuccessResponse) in
            if let blob64 = onSuccessResponse.blobBase64, let documentName = onSuccessResponse.nomArchivo {
                self.saveBase64StringToPDF(blob64, docName: documentName)
                self.blob64 = blob64
                self.docName = documentName
            }
            self.removeSpinner()
        } onFailed: { (onFailedResponse) in
            self.removeSpinner()
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        } onAuthenticationError: { (onFailed) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }
}

extension FirmarRenovacionesViewController: UIConfirmarRenovacionAlertViewControllerDelegate {
    
    func acceptAction(username: String, password: String, codTipoRenov: String, numPeriRenov: Int) {
        var confirmarFirma = ConfirmarFirma()
        confirmarFirma.login = username
        confirmarFirma.clave = password
        confirmarFirma.codTiporenov = codTipoRenov
        confirmarFirma.numIntencion = self.currentNumIntencion
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        self.showSpinner(onView: self.view)
        FirmarRenovacionWorker.confirmarFirma(with: appDelegate.authorizationToken, with: autorizacionbean, with: confirmarFirma) { (onSuccessResponse) in
            if onSuccessResponse.httpBody.exito == true {
                DispatchQueue.main.async {
                    let numInt = Int(self.currentNumIntencion)
                    var seguimientos = [SeguimientoForRenovation]()
                    if let arcDocFircola = onSuccessResponse.httpBody.mensaje, let numInt = numInt {
                        let seguimiento = self.prepareSignTrackingForAppend(numIntencion: numInt, codTiporenov: codTipoRenov, numPerirenov: numPeriRenov, arcDocFircola: arcDocFircola)
                        seguimientos = [seguimiento]
                    }
                    
                    FirmarRenovacionWorker.guardarSeguimiento(with: self.appDelegate.authorizationToken, with: autorizacionbean, with: seguimientos) { (onSuccessResponse) in
                        if onSuccessResponse.exito  == true {
                            print("Se guardó el seguimiento de firma con éxito")
                        } else {
                            print("Algo salió mal con el seguimiento de firma")
                        }
                    } onFailed: { (onFailed) in
                        print("Falló el request")
                    } onAuthenticationError: { (onFailedResponse) in
                        print("No se autenticó")
                    }
                    
                    self.alerts.showToastAlert(vc: self, message: "Se firmó la renovación con éxito")
                    self.removeSpinner()
                    self.retrievePendingSignRenovations()
                    self.tableView.reloadData()
                }
            } else {
                DispatchQueue.main.async {
                    self.removeSpinner()
                    self.retrievePendingSignRenovations()
                    self.tableView.reloadData()
                    
                    if let mensaje = onSuccessResponse.httpBody.mensaje  {
                        self.alerts.showToastAlert(vc: self, message: mensaje)
                        //UserAlerts.showAlertForUserToServiceAction(on: self, title: "Ocurrió un error!", message: mensaje, configuration: .Error)
                    }
                    
                    print(onSuccessResponse.httpBody.mensaje!)
                }
                
            }
            
        } onFailed: { (onFailedResponse) in
            DispatchQueue.main.async {
                //self.alerts.showToastAlert(vc: self, message: "No se pudo firmar la renovación")
                self.removeSpinner()
                self.retrievePendingSignRenovations()
                self.tableView.reloadData()
            }
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
        } onAuthenticationError: { (onFailed) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }
}
