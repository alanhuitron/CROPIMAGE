//
//  UITableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import UIKit
@objc protocol UIPapeletaTableViewCellDelegate {
    
    @objc optional func actionAprobarFila(object: UIPapeletaTableViewCell)
}
class UIPapeletaTableViewCell: UITableViewCell {
   static let NAME = "UIPapeletaTableViewCell"
    
    @IBOutlet weak var lblNombrePersona: UILabel!

    @IBOutlet weak var lblDespapeleta: UILabel!
    
    @IBOutlet weak var lblFechaingreso: UILabel!
    
    @IBOutlet weak var lblHoraIngreso: UILabel!
    
    @IBOutlet weak var lblDesobservacion: UILabel!
    @IBOutlet weak var lblFechaPapeleta: UILabel!

    @IBOutlet weak var imageCheck: UIImageView!
   // let tapImage  =   UITapGestureRecognizer(target: self, action: #selector(tapImage(sender:)))
    

      public var delegate: UIPapeletaTableViewCellDelegate!
    

    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let  tapImage  = UITapGestureRecognizer(target: self, action: #selector(handlePress))
        imageCheck.isUserInteractionEnabled = true
        imageCheck.addGestureRecognizer(tapImage)
        
    }

    
    @objc func handlePress(sender: UITapGestureRecognizer){
         delegate.actionAprobarFila?(object: self)
    }
    
    func setupContent(nombrePersona : String, desPapeleta : String, fechaIngreso:String,horaIngreso:String,desObservacion:String ,desFecha :String ){
        self.lblNombrePersona.text = nombrePersona
        self.lblDespapeleta.text = desPapeleta
        self.lblFechaingreso.text = "Día " + fechaIngreso
        self.lblHoraIngreso.text = "De: " + horaIngreso
        self.lblDesobservacion.text = desObservacion
        self.lblFechaPapeleta.text = desFecha
    }
    
    
    func  ocultarEvento (){
        imageCheck.isUserInteractionEnabled = false
    }
    
    func  mostrarEvento (){
        imageCheck.isUserInteractionEnabled = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
 
}
