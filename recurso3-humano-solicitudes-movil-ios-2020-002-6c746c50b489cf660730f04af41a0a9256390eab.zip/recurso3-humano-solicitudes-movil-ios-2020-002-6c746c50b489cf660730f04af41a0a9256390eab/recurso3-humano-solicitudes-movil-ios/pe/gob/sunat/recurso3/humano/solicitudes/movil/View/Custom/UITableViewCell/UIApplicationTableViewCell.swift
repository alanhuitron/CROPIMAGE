//
//  UIApplicationTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/8/19.
//

import UIKit

@objc protocol UIApplicationTableViewCellDelegate {
    @objc optional func approveApplicationByClickOnCheck(object: UIApplicationTableViewCell)
}

class UIApplicationTableViewCell: UITableViewCell {
    
    static let NAME = "UIApplicationTableViewCell"
    static let IDENTIFIER = "ApplicationTableViewCell"
    
    
    @IBOutlet weak var lblApplicationId: UILabel!
    @IBOutlet weak var lblApplicationDescription: UILabel!
    @IBOutlet weak var lblPersonName: UILabel!
    @IBOutlet weak var lblApplicationDate: UILabel!
    @IBOutlet weak var imgCheck: UIImageView!
    var code : String?
    var delegate : UIApplicationTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        let  tapImage  = UITapGestureRecognizer(target: self, action: #selector(handlePress))
        imgCheck.isUserInteractionEnabled = true
        imgCheck.addGestureRecognizer(tapImage)
    }
    
    @objc func handlePress(sender: UITapGestureRecognizer){
         delegate?.approveApplicationByClickOnCheck?(object: self)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
