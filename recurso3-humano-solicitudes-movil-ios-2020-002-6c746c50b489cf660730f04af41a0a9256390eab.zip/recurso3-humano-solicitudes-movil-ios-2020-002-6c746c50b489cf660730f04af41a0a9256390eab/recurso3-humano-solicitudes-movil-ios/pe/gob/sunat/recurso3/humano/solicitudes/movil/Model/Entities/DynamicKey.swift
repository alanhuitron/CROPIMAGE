//
//  DynamicKey.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/6/19.
//

import Foundation

public struct DynamicKey: CodingKey {
    public var stringValue: String
    public init(stringValue: String) {
        self.stringValue = stringValue
    }
    public var intValue: Int? { return nil }
    public init?(intValue: Int) { return nil }
}
