//
//  FiltroAutorizarRenovacionViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation
import UIKit

protocol FiltroAutorizarRenovacionViewControllerDelegate {
    
    func filtersWereApplied(filteredRenovations : [Renovacion]?, codSituacion: String, UUOO: String)
    
    func cleanFiltersRenovacion()
    
}

class FiltroAutorizarRenovacionViewController : ParentViewController {
    
    @IBOutlet weak var headerNavigationBarView: UIView!
    
    @IBOutlet weak var cbxUUOO: UIPickerText!
    
    @IBOutlet weak var cbxSituacion: UIPickerText!
    @IBOutlet weak var checkBox: UICheckboxControl!
    
    @IBOutlet weak var UUOOLabel: UILabel!
    
    @IBOutlet weak var applyFiltersButton: UIButton!
 
    
    var situationCode: String?
    var UUOOCode: String?
    var incluirUUOODependientes: String?
    var UUOOs = [CodeValueEntity]()
    var situations = [CodeValueEntity]()
    var delegate : FiltroAutorizarRenovacionViewControllerDelegate?
    var alerts = ToastAlerts()

    override func viewDidLoad() {
    super.viewDidLoad()
        
        self.setHeaderView(self.headerNavigationBarView, viewController: self, title: "Autorizar Renovaciones", leftImage: "iconLeft")
        self.UUOOLabel.isHidden = true
        self.applyFiltersButton.roundBorders(corner: 5.0)
        self.cbxUUOO.delegate = self
        self.cbxSituacion.delegate = self
        self.cbxUUOO.resignFirstResponder()
        self.cbxSituacion.resignFirstResponder()
        self.cbxUUOO.customizeBorder(color: UIColor(named: "appColor")!, width: 2, cornerRadius: 3)
        self.UUOOCode = "TODOS"
        self.cbxUUOO.text = "TODAS LAS UNIDADES ORGÁNICAS"
        self.cbxSituacion.customizeBorder(color: UIColor(named: "appColor")!, width: 2, cornerRadius: 3)
        self.checkBox.borderStyle = .square
        self.checkBox.style = .tick
        self.checkBox.isChecked = false
        self.checkBox.isHidden = true
        self.setup()
        self.hideKeyboardWhenTappedAround()
    }
    
    func cleanData(){
        self.cbxUUOO.text = nil
        self.situationCode = nil
        self.cbxSituacion.text = nil
        self.UUOOCode = nil
    }
    
    
    @IBAction func aplicarFiltro(_ sender: Any) {
        
        var haveFilters = false
        if let _ = situationCode, let _ = UUOOCode {
            haveFilters = true
        }
        DispatchQueue.main.async {
            self.applyFiltersButton.isEnabled = false
        }
        
        if !haveFilters {
            UserAlerts.showAlertMessage(on: self, message: "Debe ingresar un filtro de búsqueda")
            DispatchQueue.main.async {
                self.applyFiltersButton.isEnabled = true
            }
        }else{
            let request = prepareRenovationRequest()
            self.retrieveFilteredRenovations(using: appDelegate.authorizationToken, with: request)
        }
    }
    
    
    func setup() {
        
        let codValue = CodeValueEntity(code: "TODOS", value: "TODAS LAS UNIDADES ORGÁNICAS")
        self.UUOOs.append(codValue)
        
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionWorker.getUUOO(with: appDelegate.authorizationToken, with: autorizacionbean, with: appDelegate.currentUser.registryNumber) { (onSuccessResponse) in
            DispatchQueue.main.async {
                let UUOOsArray = onSuccessResponse
                for UUOO in UUOOsArray {
                    let codValue = CodeValueEntity(code: UUOO.t12codUorga!, value: UUOO.t12desUorga!)
                    self.UUOOs.append(codValue)
                }
                self.cbxUUOO.loadDropdown(data: self.UUOOs)
                self.cbxUUOO.customPicker.pickerViewDelegate = self
                self.removeSpinner()
            }
        } onFailed: { (onFailed) in
            UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            self.removeSpinner()
        } onAuthenticationError: { (onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
        
        RenovacionWorker.getSituations(with: appDelegate.authorizationToken, with: autorizacionbean) { (onSuccessResponse) in
            DispatchQueue.main.async {
                if let lista = onSuccessResponse.httpBody.lista{
                    let situationsArray = lista
                    for situation in situationsArray {
                        if situation.t99codigo == "03" || situation.t99codigo == "08" || situation.t99codigo == "09" || situation.t99codigo == "10" {
                            let codValue = CodeValueEntity(code: situation.t99codigo!, value: situation.t99descrip!)
                            self.situations.append(codValue)
                        }
                    }
                    self.cbxSituacion.loadDropdown(data: self.situations)
                    self.cbxSituacion.customPicker.pickerViewDelegate = self
                    self.removeSpinner()
                }
            }
        } onFailed: { (onFailed) in
            //self.alerts.showToastAlert(vc: self, message: AppConstants.MESSAGES.CONNECTION_ERROR)
            self.removeSpinner()
        } onAuthenticationError: { (onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
        
    }
    
    
    func prepareRenovationRequest()->ObtenerRenovacionesRequest{
        var request = ObtenerRenovacionesRequest()
        if let codUOrga = UUOOCode {
            request.codUOrga = codUOrga
        }
        
        if let situacionCode = situationCode {
            request.codSituacion = situacionCode
        }
        
        if checkBox.isChecked {
            request.dependencias = "1"
        } else {
            request.dependencias = "0"
        }

        return request
    }
    
    
    func retrieveFilteredRenovations(using token: String, with request: ObtenerRenovacionesRequest){
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionWorker.getRenovations(with: token, with: autorizacionbean, parameters: request) { (onSuccessResponse) in
            DispatchQueue.main.async {
                self.delegate?.filtersWereApplied(filteredRenovations: onSuccessResponse.httpBody.renovaciones, codSituacion: self.situationCode!, UUOO: self.UUOOCode!)
                self.applyFiltersButton.isEnabled = true
                
                self.goBackMore()
            }
        } onFailed: { (onFailedResponse) in
            DispatchQueue.main.async {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
                self.applyFiltersButton.isEnabled = true
            }
        } onAuthenticationError: { (onFailedResponse) in
            self.showExpiredSessionAlert(on: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension FiltroAutorizarRenovacionViewController : UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case cbxUUOO:
            //criterionData = nil
        break
        case cbxSituacion:
            //cr
        break
        default:
            break
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case cbxUUOO:
            //self.UUOO = textField.text
        break
        case cbxSituacion:
            for situation in self.situations {
                if situation.description == textField.text {
                    self.situationCode = textField.text
                }
            }
            break
        default:
            break
        }
    }
}

extension FiltroAutorizarRenovacionViewController : PickerViewDelegate {
    func pickerViewDidSelectRow(_ pickerView: UIPickerView) {
        switch pickerView {
        case self.cbxUUOO.customPicker:
            self.UUOOCode = cbxUUOO.customPicker.currentRow.code
            if cbxUUOO.customPicker.currentRow.code != "TODOS" {
                DispatchQueue.main.async {
                    self.checkBox.isHidden = false
                    self.UUOOLabel.isHidden = false

                }
            } else {
                DispatchQueue.main.async {
                    self.checkBox.isHidden = true
                    self.UUOOLabel.isHidden = true
                }
            }
            break
            
        case self.cbxSituacion.customPicker:
            self.situationCode = cbxSituacion.customPicker.currentRow.code
            break
        default:
            break
        }
    }
}

extension FiltroAutorizarRenovacionViewController: HeaderViewDelegate{

    func actionLeft() {
       self.goBackMore()
    }
}
