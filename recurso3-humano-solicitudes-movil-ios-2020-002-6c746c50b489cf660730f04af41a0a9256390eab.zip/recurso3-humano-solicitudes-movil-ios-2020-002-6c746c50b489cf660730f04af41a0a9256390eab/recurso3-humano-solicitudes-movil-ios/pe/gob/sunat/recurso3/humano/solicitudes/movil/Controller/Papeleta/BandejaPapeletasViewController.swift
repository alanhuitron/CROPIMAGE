//
//  BandejaPapeletasViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/6/19.
//

import UIKit
import Foundation

private let reuseIdentifier = "PapeletaCell"
class BandejaPapeletasViewController:  ParentViewController  {
    
    @IBOutlet weak var headerNavigationBarView: UIView!
    var authToken : String?
    var papeletas = [Papeleta]()
    var selectPapeletas = [Papeleta]()
    var applicationsFilteredBySearch = [Papeleta]()
    var searchIsActive = false
    
    @IBOutlet weak var noItemsFoundView: UIView!
    @IBOutlet weak var imgNotFoundItems: UIImageView!
    @IBOutlet weak var lblNotFoundItems: UILabel!
    
    @IBOutlet weak var botonBarView: UIView!
    @IBOutlet weak var tableBandejaPapeleta: UITableView!
    
    @IBOutlet weak var viewAdapter: UIView!
    
    var ubicacionTop = Ubicacion()
    var usuarioConectado = Usuario ()
    
    var selectedApplicationsIndexPath = [IndexPath]()
    var userIsInSelectMode = false
    var indAprobarMasiva = false
    
    let refreshControl = UIRefreshControl()
    var selectedApplicationsOnly = Int();
    
    var vistaFiltro = FiltroPapeletaViewController()
    
    // MARK: - LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        }
        /*on iOS 11.0.1 the notification center doesnt call this method
        just after the observer was added, so is required call it here */

        
        self.iniParametros()
        self.loadServicePapeleta()

        self.tableBandejaPapeleta.allowsMultipleSelection =  false
        
          //print("viewDidLoad indexSelected \(selectedApplicationsIndexPath.count)")
      }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
       // print(selectedApplicationsIndexPath.count)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //print("viewWillAppear indexSelected \(selectedApplicationsIndexPath.count)")
        if let indexPath = tableBandejaPapeleta.indexPathForSelectedRow {
            tableBandejaPapeleta.deselectRow(at: indexPath, animated: false)
        }
        //print("viewWillAppear indexSelected after clean \(selectedApplicationsIndexPath.count)")
    }
    
    // MARK: - Miscellaneous Fuctions
    func iniParametros () {
        self.setHeaderView(headerNavigationBarView, viewController: self, title:  "Papeletas Pendientes", leftImage: "iconMenu", rightImage: "iconSearch", rightImage2: "iconFilter", useSearchBar: true)

        self.authToken = appDelegate.authorizationToken
        self.tableBandejaPapeleta.delegate = self
        self.tableBandejaPapeleta.dataSource = self
        self.tableBandejaPapeleta.translatesAutoresizingMaskIntoConstraints = false
        self.tableBandejaPapeleta.register(UINib(nibName: UIPapeletaTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: reuseIdentifier)
        self.tableBandejaPapeleta.tableFooterView = UIView(frame: .zero)
        
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        self.tableBandejaPapeleta.addGestureRecognizer(longPress)

        self.tableBandejaPapeleta.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(loadServicePapeleta), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        refreshControl.attributedTitle = NSAttributedString(string: "Recuperando papeletas ...", attributes: attributes)


        self.setBotonBarView(self.botonBarView, viewControllerTitle: "Papeletas Pendientes", viewController: self)
        
          
        ubicacionTop.numLatitud =  self.appDelegate.location?.latitude.description
        ubicacionTop.numLongitud =   self.appDelegate.location?.longitude.description
        print(" lati\( String(describing: ubicacionTop.numLatitud) )")
        usuarioConectado.login = self.appDelegate.currentUser.userName
        usuarioConectado.nroRegistro = self.appDelegate.currentUser.registryNumber
    }
    
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: self.tableBandejaPapeleta)
            if let indexPath = self.tableBandejaPapeleta.indexPathForRow(at: touchPoint) {
                self.selectCellOn(indexPath: indexPath)
                if !self.userIsInSelectMode {
                    self.userIsInSelectMode = true
                }
            }
        }
        //print("handleLongPress indexSelected \(selectedApplicationsIndexPath.count)")
    }
    
    private func selectCellOn(indexPath : IndexPath){
        print("selected :\(indexPath.row)")
        print("numero de filas en la tabla(seccion 0)  :\(tableBandejaPapeleta.numberOfRows(inSection: 0))")
        let cell = tableBandejaPapeleta.cellForRow(at: indexPath)
        let  data = tableBandejaPapeleta.cellForRow(at: indexPath) as! UIPapeletaTableViewCell
        if selectedApplicationsIndexPath.contains(indexPath){
            cell?.backgroundColor = .white
            if let index = selectedApplicationsIndexPath.firstIndex(of: indexPath){
                selectedApplicationsIndexPath.remove(at: index)
            }
            data.mostrarEvento()
            validarNumberFileBarButton()
        } else {
            cell!.backgroundColor = UIColor(netHex: 0xD1D1D6)
            selectedApplicationsIndexPath.append(indexPath)
            data.ocultarEvento()
        }
        validarNumberFileBarButton()
    }

    @objc func loadServicePapeleta (){
        self.searchIsActive = false
        self.applicationsFilteredBySearch.removeAll()
        self.selectedApplicationsIndexPath.removeAll()
        if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        var requestParameterSeguimiento = PapeletaRequest()
        requestParameterSeguimiento.codPersona = self.appDelegate.currentUser.registryNumber
        self.showSpinner(onView: self.view)
        PapeletaWorker.getPendingPapeletaRequest(with: authToken! , parameters : requestParameterSeguimiento ,
            onSuccess: { (responseOnSuccess) in
                DispatchQueue.main.async {
                    self.papeletas = responseOnSuccess.httpBody.papeletas!
                    self.tableBandejaPapeleta.reloadData()
                    self.refreshControl.endRefreshing()
                    self.removeSpinner()
                }

            }, onFailed: {(onFailed) in
                self.refreshControl.endRefreshing()
                self.removeSpinner()
                if onFailed.httpResponse.success {
                    self.showAlertMessage(title: "Error : \(onFailed.httpResponse.error.status)", message: onFailed.httpResponse.error.message)
                } else {
                    self.showAlertMessage(title: "Error de comunicación", message: "Error http : \(onFailed.httpResponse.httpCode)")
                }
                
            }, onAuthenticationError: {(onFailedResponse) in
                self.refreshControl.endRefreshing()
                self.removeSpinner()
                self.showExpiredSessionAlert(on: self)
            })
    }
    
    
    func showAlertMessage(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    func setupHiddenPropertyPorNotFoundRelatedViews(isHidden :  Bool){
        self.noItemsFoundView.isHidden = isHidden
        self.imgNotFoundItems.isHidden = isHidden
        self.lblNotFoundItems.isHidden = isHidden
        if !isHidden {
           self.tableBandejaPapeleta.backgroundColor = .clear
        } else {
           self.tableBandejaPapeleta.backgroundColor = UIColor(hexString: "#EEEEEE")
        }
    }
    
    func prepareDataPapeleta (itemData :  [IndexPath] ){
        if (indAprobarMasiva){
            self.selectPapeletas.removeAll()
            for index in 0..<itemData.count {
                     let rowbean = itemData[index]
                     let data = self.papeletas[rowbean.row]
                    self.setearBeanPapeleta(objectPapeleta: data)

            }
        }else {
            var data = Papeleta ()
            data = self.papeletas[selectedApplicationsOnly]
            self.setearBeanPapeleta(objectPapeleta: data)
  
        }
    }
    
    
    func setearBeanPapeleta(objectPapeleta : Papeleta) {
        let dateStringFormatter = DateFormatter()
        let dateString = objectPapeleta.fecIngreso
        dateStringFormatter.dateFormat = "dd/MM/yyyy"
        print("-->\(String(describing: dateString))")
        let date = dateStringFormatter.date(from: dateString!)
        print("--->\(String(describing: date))")
        dateStringFormatter.dateFormat = "yyyy-MM-dd"
        var beanPapeleta = Papeleta ()
        beanPapeleta.codPersona  = objectPapeleta.codPersona
        beanPapeleta.fecIngreso = dateStringFormatter.string(from: date!)
        beanPapeleta.horIngreso =  objectPapeleta.horIngreso
        beanPapeleta.codPeriodo =  objectPapeleta.codPeriodo

        //print("DATA NOMBRE  ====>\( String(describing: objectPapeleta.nomPersona))")
        self.selectPapeletas.append(beanPapeleta)
    }
    
    
    func validarAccionAprobar(){
        self.prepareDataPapeleta(itemData: selectedApplicationsIndexPath)
        if (!indAprobarMasiva){
            
            var papeletaRegistro  = RegistroPapeletaRequest()
            papeletaRegistro.papeleta = self.selectPapeletas[0]
            papeletaRegistro.ubicacion = ubicacionTop
            papeletaRegistro.usuario = usuarioConectado
                            
            PapeletaWorker.getAcceptPapeletaRequest(with: authToken! , parameters: papeletaRegistro ,
                       onSuccess: { (responseOnSuccess) in
                           DispatchQueue.main.async {
                             
                               // print ("Hillsoness==>" + String(responseOnSuccess.httpBody.solicitud , encoding: .utf8))
                                let beanPapeleta  = responseOnSuccess.httpBody.papeletas!
                                if (beanPapeleta.count == 0){
                                    UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBAR_PAPELETA.SUCCES_MESSAGE)
                                }else {
                                    UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.WARNING_TITLE, message: beanPapeleta[0].msg! , configuration: .Warning)
                                }
                          
                           }

                       }, onFailed: {(onFailed) in
                               if onFailed.httpResponse.success {
                                        self.showAlertMessage(title: "Error : \(onFailed.httpResponse.error.status)", message: onFailed.httpResponse.error.message)
                                  } else {
                                          self.showAlertMessage(title: "Error de comunicación", message: "Error http : \(onFailed.httpResponse.httpCode)")
                                 }
                       }, onAuthenticationError: {(onFailedResponse) in
                           self.showExpiredSessionAlert(on: self)
                       })
                           
        }else{
            var papeletaRegistro  = RegistroPapeletaMasivaRequest()
            papeletaRegistro.papeletas = self.selectPapeletas
            papeletaRegistro.ubicacion = ubicacionTop
            papeletaRegistro.usuario = usuarioConectado
                 
                      
            PapeletaWorker.getAcceptMasivaPapeletaRequest(with: authToken! , parameters: papeletaRegistro ,
                        onSuccess: { (responseOnSuccess) in
                                 DispatchQueue.main.async {
                                    //  print ("Hillsoness==>" , String(responseOnSuccess.httpBody.papeletaResponse , encoding: .utf8))
                                    let masivaPapeleta = responseOnSuccess.httpBody.papeletaResponse!
                                    let result = masivaPapeleta.indProceso?.caseInsensitiveCompare("1")
                                    if(result == .orderedSame){
                                        UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.SUCCES_MESSAGE)

                                    }else {
                                        let mensajeError = masivaPapeleta.errores?[0]
                                        UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.WARNING_TITLE,message: "Error :" + mensajeError!.msg! , configuration: .Warning)

                                    }
                                
                                 }
                         }, onFailed: {(onFailed) in
                                 if onFailed.httpResponse.success {
                                     self.showAlertMessage(title: "Error : \(onFailed.httpResponse.error.status)", message: onFailed.httpResponse.error.message)
                                  } else {
                                     self.showAlertMessage(title: "Error de comunicación", message: "Error http : \(onFailed.httpResponse.httpCode)")
                                  }
                         }, onAuthenticationError: {(onFailedResponse) in
                             self.showExpiredSessionAlert(on: self)
                         })
                      
        }
        
    }
    
        func  validarAccionRechazar (){
            self.prepareDataPapeleta(itemData: selectedApplicationsIndexPath)
            if (!indAprobarMasiva){
                     
          
                var papeletaRegistro  = RegistroPapeletaRequest()
                papeletaRegistro.papeleta = self.selectPapeletas[0]
                papeletaRegistro.ubicacion = ubicacionTop
                papeletaRegistro.usuario = usuarioConectado
                                
                
                PapeletaWorker.getRejectPapeletaRequest(with: authToken! , parameters: papeletaRegistro ,
                        onSuccess: { (responseOnSuccess) in
                            DispatchQueue.main.async {
                                // print ("Hillsoness==>" + String(responseOnSuccess.httpBody.solicitud , encoding: .utf8))
                                //  self.solicitud = responseOnSuccess.httpBody.solicitud
                                let beanPapeleta  = responseOnSuccess.httpBody.papeletas!
                                     if (beanPapeleta.count == 0){
                                          UserAlerts.showAlertForUserToServiceAction(on: self, message: "Papeleta Rechazada exitosamente")
                                      }else {
                                          UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.WARNING_TITLE, message: beanPapeleta[0].msg! , configuration: .Warning)
                                        }
                                

                            }
                        }, onFailed: {(onFailed) in

                        }, onAuthenticationError: {(onFailedResponse) in
                            self.showExpiredSessionAlert(on: self)
                        })
                               
                
                
            } else {
                var papeletaRegistro  = RegistroPapeletaMasivaRequest()
                papeletaRegistro.papeletas = self.selectPapeletas
                papeletaRegistro.ubicacion = ubicacionTop
                papeletaRegistro.usuario = usuarioConectado


                PapeletaWorker.getRejectMasivaPapeletaRequest(with: authToken! , parameters: papeletaRegistro ,
                        onSuccess: { (responseOnSuccess) in
                            DispatchQueue.main.async {
                             // print ("Hillsoness==>" + String(responseOnSuccess.httpBody.solicitud , encoding: .utf8))
                             //  self.solicitud = responseOnSuccess.httpBody.solicitud
                                let beanPapeleta  = responseOnSuccess.httpBody.papeletaResponse
                                let result = beanPapeleta?.indProceso?.caseInsensitiveCompare("1")
                                      if(result == .orderedSame){
                                         UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.SUCCES_MESSAGE)

                                     }else {
                                        let mensajeError = beanPapeleta?.errores?[0]
                                         UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.APROBACION_MASIVA_PAPELETAS.WARNING_TITLE,message: "Error :" + mensajeError!.msg! , configuration: .Warning)

                                    }
                                

                            }

                        }, onFailed: {(onFailed) in
                           
                        }, onAuthenticationError: {(onFailedResponse) in
                            self.showExpiredSessionAlert(on: self)
                        })
            }
        }
            
    func openModalOnlyRow(value: Bool){
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "popUpMessage") as! PopUpViewController
                  vc.modalPresentationStyle = .overCurrentContext
                  vc.delegate = self
                  self.present(vc, animated: true, completion: nil)
        
        if(value){
            vc.setMensajeTitle(titulo: AppConstants.MENU_POPUP.APROBAR_TITLE)
            vc.setMensajeBody(mensaje: AppConstants.MENU_POPUP.APROBAR_BODY )
            vc.setMensajeBoton(botonTitulo: AppConstants.MENU_POPUP.APROBAR_BUTTON)
        }else {
            vc.setMensajeTitle(titulo: AppConstants.MENU_POPUP.RECHAZAR_TITLE)
            vc.setMensajeBody(mensaje: AppConstants.MENU_POPUP.RECHAZAR_BODY )
            vc.setMensajeBoton(botonTitulo: AppConstants.MENU_POPUP.RECHAZAR_BUTTON)
            
        }
               
    }
    
    func validarNumberFileBarButton(){
        if selectedApplicationsIndexPath.count == 0 {
            self.userIsInSelectMode = false
            if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
                botonBarView.ocultarBotonAction()
                botonBarView.setLabelSelectTodo()
                botonBarView.checkTotal.isChecked = false
            }
        } else {
            if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
                botonBarView.setLabelTotal(totalFila: String(selectedApplicationsIndexPath.count))
                botonBarView.mostrarBotonAction()
            }
        }
    }
    
    func quitSelectRow (patRow : IndexPath){
        let cell = tableBandejaPapeleta.cellForRow(at: patRow)
        // let  data = tableBandejaPapeleta.cellForRow(at: patRow) as! UIPapeletaTableViewCell
        if selectedApplicationsIndexPath.contains(patRow){
            cell?.backgroundColor = .white
            if let index = selectedApplicationsIndexPath.firstIndex(of: patRow){
                selectedApplicationsIndexPath.remove(at: index)
            }
            //  data.mostrarEvento()
            //print ("QUITAR  SELECCION "  +   String(patRow.row) )
            validarNumberFileBarButton()
        }
        
    }
}

// MARK: - EXTENSION TABLEVIEW
extension BandejaPapeletasViewController:UITableViewDelegate,UITableViewDataSource{
    
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        if papeletas.count == 0 {
           self.setupHiddenPropertyPorNotFoundRelatedViews(isHidden: false)
        } else {
           self.setupHiddenPropertyPorNotFoundRelatedViews(isHidden: true)
        }
        
        if searchIsActive {
            return applicationsFilteredBySearch.count
        }
        return papeletas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier ,for: indexPath) as! UIPapeletaTableViewCell
        cell.selectionStyle = .none
        cell.delegate = self
        let data : Papeleta?
        
        if searchIsActive {
           data = applicationsFilteredBySearch[indexPath.row]
        } else {
           data = papeletas[indexPath.row]
        }
               
        if selectedApplicationsIndexPath.contains(indexPath){
            cell.backgroundColor = UIColor(netHex: 0xD1D1D6)
        } else {
            cell.backgroundColor = UIColor(netHex: 0xFFFFFF)
           //// cell.mostrarEvento()
        }

        if selectedApplicationsIndexPath.count == 0 {
            cell.mostrarEvento()
        }else {
            cell.ocultarEvento()
        }

        
        //print("indexpathh==============> ==>" , indexPath.row)
        
        /*print("nomPersona ==>" + (data?.nomPersona!)!)
        print("desPapeleta ==>" + (data?.desPapeleta!)!)
        print("fecIngreso ==>" + (data?.fecIngreso!)!)
        print("horIngreso ==>" + (data?.horIngreso!)!)
        print("desObservacion ==>" + (data?.desObservacion!)!)
        print("fecPapeleta ==>" + (data?.fecPapeleta ??  "") ?? "")*/
        //  var fdesPapeleta  :String  = data?.fecPapeleta??""
        
        
        guard let nombrePerso = data?.nomPersona, let desPape = data?.desPapeleta,  let fechaIngre = data?.fecIngreso ,
            let horaIngre = data?.horIngreso ,    let desObserva = data?.desObservacion ,
            let descriFecha : String = (data?.fecPapeleta) else  {
            return cell
        }
        
        var fechaPapeletaWithStyle = descriFecha
        if #available(iOS 13.0, *) {
            let fechaPapeletaAsDate = DateUtils.convert(dateString: descriFecha, from: DateUtils.dd_MM_yyyy_withSlashFormat)
            if let fechaPapeleta = fechaPapeletaAsDate {
                let daysDiff = abs(DateUtils.interval(ofComponent: .day, fromDate: fechaPapeleta))
                if daysDiff <= 7 {
                    fechaPapeletaWithStyle = DateUtils.convert(dateString: descriFecha, from: DateUtils.dd_MM_yyyy_withSlashFormat, with: .named)!
                }
            }
        }
        
        cell.setupContent(nombrePersona: nombrePerso, desPapeleta: desPape, fechaIngreso: fechaIngre, horaIngreso: horaIngre, desObservacion: desObserva, desFecha: fechaPapeletaWithStyle)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let cell = tableBandejaPapeleta.cellForRow(at: indexPath)
        if self.userIsInSelectMode {
            self.selectCellOn(indexPath: indexPath)
        }
        
        /*if self.userIsInSelectedMode {
            self.selectCellOn(indexPath: indexPath)
        } else {
            if selectedApplicationsIndexPath.contains(indexPath){
                print ("aGREGAR  SELECCION "  +   String(indexPath.row) )
                print ("aGREGAR  selectedApplicationsIndexPath "  +   String(selectedApplicationsIndexPath.description) )
                cell?.backgroundColor = .white
                if let index = selectedApplicationsIndexPath.firstIndex(of: indexPath){
                    selectedApplicationsIndexPath.remove(at: index)
                }
                /// data.mostrarEvento()
                validarNumberFileBarButton()
            }
        }*/
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
         let rejectAction =  UIContextualAction(style: .destructive, title: "RECHAZAR", handler: { (action,view,completionHandler ) in
                 //print("rechazado")
                self.openModalOnlyRow(value: false)
                self.selectedApplicationsOnly = indexPath.row
                self.indAprobarMasiva = false
                 //completionHandler(false)
             })
         //rejectAction.image = UIImage(named: "paper")
         rejectAction.title = "RECHAZAR"
         rejectAction.backgroundColor = .red
         let configuration = UISwipeActionsConfiguration(actions: [rejectAction])
         return configuration
     }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

// MARK: - EXTENSION HeaderView
extension BandejaPapeletasViewController: HeaderViewDelegate{

    func actionLeft() {
        self.openMenu()
    }
    
    func actionRight() {

    }
    
    func actionMore() {
          let vc = self.storyboard?.instantiateViewController(withIdentifier: "filtroPapeleta") as! FiltroPapeletaViewController
          vc.modalPresentationStyle = .fullScreen
            vc.delegate = self
          self.present(vc, animated: true, completion: nil)
            vistaFiltro = vc
    }
    
    
    func searchOnBar(searchBar: UISearchBar, textDidChange searchText: String) {
          self.applicationsFilteredBySearch = papeletas.filter({ (application) -> Bool in
              let add = (application.nomPersona?.lowercased().contains(searchText.lowercased()) ?? false)
              return add
          })
          
          if(applicationsFilteredBySearch.count == 0){
              searchIsActive = false;
          } else {
              searchIsActive = true;
          }
          self.tableBandejaPapeleta.reloadData()
      }
      
      func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
          searchBar.setValue("Cancelar", forKey: "cancelButtonText")
          searchBar.showsCancelButton = true
          searchBar.enablesReturnKeyAutomatically = true
      }
      
      
      func searchBarCancelButtonClicked(searchBar: UISearchBar) {
          searchBar.text = nil
          searchBar.showsCancelButton = false
          //Remove focus from the search bar.
          searchBar.endEditing(true)
          applicationsFilteredBySearch = []
          if(applicationsFilteredBySearch.count == 0){
              searchIsActive = false;
          } else {
              searchIsActive = true;
          }
          self.tableBandejaPapeleta.reloadData()
       }
      
    
    
      func searchBarSearchButtonClicked( searchBar: UISearchBar)  {
          searchBar.resignFirstResponder()
      }
    

}

// MARK: - EXTENSION FiltroPapeletasPendientes
extension BandejaPapeletasViewController: FiltroPapeletasPendientesViewControllerDelegate{
   
    func cleanFiltersPapeleta() {
        vistaFiltro.dismiss(animated: true, completion: nil)
        var contPapeleta = 0
        for _ in papeletas{
            let index = IndexPath(row: contPapeleta, section: 0)
            if let indexPosition = selectedApplicationsIndexPath.firstIndex(of: index){
                    self.selectedApplicationsIndexPath.remove(at: indexPosition)
            }
            contPapeleta  = contPapeleta  + 1
        }
        loadServicePapeleta()
    }
    
    
    func filtersWereApplied(filteredApplications: [Papeleta]?) {
        self.papeletas = filteredApplications ?? [Papeleta]()
        searchIsActive = false
        self.selectedApplicationsIndexPath.removeAll()
        if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
            botonBarView.checkTotal.isChecked = false
            botonBarView.setLabelSelectTodo()
            botonBarView.ocultarBotonAction()
        }
        self.tableBandejaPapeleta.reloadData()
    }
  
    
}

// MARK: - EXTENSION BotonBar
extension BandejaPapeletasViewController: BotonBarViewDelegate{
    
        func actionCheckBox() {
            if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
                if (botonBarView.getChecked()){
                    self.userIsInSelectMode = true
                    botonBarView.setLabelTotal(totalFila: String (papeletas.count))
                    botonBarView.mostrarBotonAction()
                    selectedApplicationsIndexPath.removeAll()
                    var contPapeleta = 0
                    for _ in papeletas{
                        //print("contadoo ==>> " , contPapeleta )
                        let index = IndexPath(row: contPapeleta, section: 0)
                        //let cell = tableBandejaPapeleta.cellForRow(at: index)
                        //let  data = tableBandejaPapeleta.cellForRow(at: index) as! UIPapeletaTableViewCell
                        //cell!.backgroundColor = UIColor(netHex: 0xD1D1D6)
                        selectedApplicationsIndexPath.append(index)
                        //  data.ocultarEvento()
                        //  self.tableBandejaPapeleta.selectRow(at: index, animated: true, scrollPosition: UITableView.ScrollPosition.none)
                        contPapeleta  = contPapeleta  + 1
                    
                    }

                }else{
                    self.userIsInSelectMode = false
                    botonBarView.setLabelSelectTodo()
                    botonBarView.ocultarBotonAction()
                    var contPapeleta = 0
                    for _ in papeletas{let index = IndexPath(row: contPapeleta, section: 0)
                        if let indexPosition = selectedApplicationsIndexPath.firstIndex(of: index){
                            self.selectedApplicationsIndexPath.remove(at: indexPosition)
                        }
                        contPapeleta  = contPapeleta  + 1
                    }
                }
            }
         self.tableBandejaPapeleta.reloadData()

        }
    
    func actionAprobar () {
        //print("Se van a aprobar \(self.selectedApplicationsIndexPath.count) solicitudes")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "popUpMessage") as! PopUpViewController
        vc.modalPresentationStyle = .overCurrentContext
        vc.delegate = self
        self.present(vc, animated: true, completion: nil)
        vc.setMensajeTitle(titulo: AppConstants.MENU_POPUP.APROBAR_TITLE + " MASIVA")
        vc.setMensajeBody(mensaje: AppConstants.MENU_POPUP.APROBAR_BODY_MASIVO )
        vc.setMensajeBoton(botonTitulo: AppConstants.MENU_POPUP.APROBAR_BUTTON)
        indAprobarMasiva = true
      

    }
    
    func actionRechazar() {
        //print("Se van a rechazar \(self.selectedApplicationsIndexPath.count) solicitudes")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "popUpMessage") as! PopUpViewController
        vc.modalPresentationStyle = .overCurrentContext
        vc.delegate = self

        self.present(vc, animated: true, completion: nil)
        vc.setMensajeTitle(titulo: AppConstants.MENU_POPUP.RECHAZAR_TITLE + " MASIVA")
        vc.setMensajeBody(mensaje: AppConstants.MENU_POPUP.RECHAZAR_BODY_MASIVO )
        vc.setMensajeBoton(botonTitulo: AppConstants.MENU_POPUP.RECHAZAR_BUTTON)
        indAprobarMasiva = true
    }

}

// MARK: - EXTENSION PopUp
extension BandejaPapeletasViewController: PopUpViewControllerDelegate {
    func buttonCloseModal() {
        self.tableBandejaPapeleta.reloadData()
    }
    
    func buttonAccionPapeleta(textAccion: String) {
        if (textAccion == AppConstants.MENU_POPUP.APROBAR_BUTTON ){
            self.validarAccionAprobar()
        }else {
            self.validarAccionRechazar()
        }
    }
        
        
}

// MARK: - EXTENSION UIActionResultAlertViewControllerDelegate
extension BandejaPapeletasViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted() {
        self.loadServicePapeleta();
        self.selectedApplicationsIndexPath.removeAll()
        self.selectPapeletas.removeAll()
        
        if let botonBarView = self.botonBarView.subviews[0] as? BotonBarView {
                botonBarView.ocultarBotonAction()
                botonBarView.setLabelSelectTodo()
                botonBarView.checkTotal.isChecked = false
        }
        
    }
}


// MARK: - EXTENSION UIPapeletaTable
extension  BandejaPapeletasViewController :  UIPapeletaTableViewCellDelegate{
     func actionAprobarFila(object: UIPapeletaTableViewCell) {
        if !userIsInSelectMode {
            openModalOnlyRow(value: true)
            let indexPath = self.tableBandejaPapeleta.indexPath(for: object)
            //print(indexPath!.row)
            selectedApplicationsOnly = indexPath!.row
            indAprobarMasiva = false
        }
    }
}

