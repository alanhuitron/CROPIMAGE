//
//  PopUpViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/8/19.
//

import UIKit


protocol PopUpViewControllerDelegate {
    
    func buttonAccionPapeleta(textAccion : String)
    func buttonCloseModal()
    
}

class PopUpViewController: UIViewController {

    @IBOutlet weak var viewBorderPopUp: UIView!
    
    
    @IBOutlet weak var titlePopUp: UILabel!
    
    
    @IBOutlet weak var mensajePopUp: UILabel!
    
    @IBOutlet weak var botonPopUp: UIButton!
    
    var delegate : PopUpViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
          viewBorderPopUp.layer.shadowColor = UIColor.gray.cgColor

          viewBorderPopUp.layer.shadowOpacity = 0.3

          viewBorderPopUp.layer.shadowOffset = .zero

          viewBorderPopUp.layer.cornerRadius = 10

          viewBorderPopUp.layer.shouldRasterize = true

          viewBorderPopUp.layer.rasterizationScale = UIScreen.main.scale
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func buttonAction(_ sender: Any) {
        
        self.delegate?.buttonAccionPapeleta(textAccion : botonPopUp.title(for:  .normal)! )
        
         self.dismiss(animated: true, completion: nil )
    }
    
    
    @IBAction func buttonClose(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
        self.delegate?.buttonCloseModal()
    }
    
  public   func setMensajeBody(mensaje:String ){
        mensajePopUp.text = mensaje
    }
  public       func setMensajeTitle(titulo:String ){
        titlePopUp.text = titulo
    }
    
    public       func setMensajeBoton(botonTitulo:String ){
        botonPopUp.setTitle( botonTitulo ,  for: .normal)
    }
    
}
