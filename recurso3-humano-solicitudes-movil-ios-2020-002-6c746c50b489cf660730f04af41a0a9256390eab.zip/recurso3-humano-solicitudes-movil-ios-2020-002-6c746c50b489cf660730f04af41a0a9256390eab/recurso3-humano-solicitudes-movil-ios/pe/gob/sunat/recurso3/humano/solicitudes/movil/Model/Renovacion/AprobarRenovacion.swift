//
//  AprobarRenovacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/25/20.
//

import Foundation

class AprobarRenovacion : Codable {
    var numIntencion: String?
    var codSituacion: String?
}
