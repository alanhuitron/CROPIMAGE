//
//  UIActionAcceptCancelAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 12/4/19.
//

import UIKit

class UIActionAcceptCancelAlertViewController: UIViewController {

    @IBOutlet weak var imgAlert: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnAccept: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var viewParent: BorderView!
    
    var alertTitle : String?
    var alertMessage : String?
    var acceptAction : (() -> Void)?
    var cancelAction : (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.viewParent.layer.cornerRadius = 40
        self.btnAccept.layer.cornerRadius = 10
        self.btnCancel.layer.cornerRadius = 10
        self.lblTitle.text = alertTitle
        self.lblMessage.text = alertMessage
        // Do any additional setup after loading the view.
    }

    @IBAction func cancel(_ sender: Any) {
        if let action = self.cancelAction {
            action()
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func accept(_ sender: Any) {
        if let action = self.acceptAction {
            action()
        }
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
