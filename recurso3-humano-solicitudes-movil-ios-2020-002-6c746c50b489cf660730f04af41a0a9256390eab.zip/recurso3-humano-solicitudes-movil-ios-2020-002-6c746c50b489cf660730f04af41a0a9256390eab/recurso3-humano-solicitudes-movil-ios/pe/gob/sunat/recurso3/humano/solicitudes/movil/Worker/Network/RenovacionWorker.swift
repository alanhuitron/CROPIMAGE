//
//  RenovacionWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/11/20.
//

import Foundation
class RenovacionWorker {
    
    static func getSituations(with token: String, with auditoriaBean: String,  onSuccess success: @escaping (_ response: GetSituacionesResponse) -> Void,
                              onFailed failed: @escaping (_ response: GetSituacionesResponse) -> Void,
                              onAuthenticationError authFailed: @escaping (_ response: GetSituacionesResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/listasituacion" //TODO: validar y crear constantes
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=GetSituacionesResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = GetSituacionesResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(GetSituacionesResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    print(response)
                    success(response)
                    
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    print(response)
                    authFailed(response)
                default:
                    var responseFailed=GetSituacionesResponse()
                    responseFailed.httpResponse.success = false
                    responseFailed.httpResponse.httpCode = String(statusCode)
                    print(response)
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func getUUOO(with token: String, with auditoriaBean: String, with codPersona: String, onSuccess success: @escaping (_ response: [UUOO]) -> Void,
                              onFailed failed: @escaping (_ response: [UUOO]) -> Void,
                              onAuthenticationError authFailed: @escaping (_ response: [UUOO]) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/listauorgjefe?codPersona=\(codPersona)" //TODO: validar y crear constantes
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                let responseFailed=[UUOO]()
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = [UUOO]()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode([UUOO].self, from: data!)!
                    success(response)
                    
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    print(response)
                    failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    print(response)
                    authFailed(response)
                default:
                    let responseFailed=[UUOO]()
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func getIntendenteUUOO(with token: String, with auditoriaBean: String, with codPersona: String, onSuccess success: @escaping (_ response: [UUOO]) -> Void,
                              onFailed failed: @escaping (_ response: [UUOO]) -> Void,
                              onAuthenticationError authFailed: @escaping (_ response: [UUOO]) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/listauorgintendencia?codPersona=\(codPersona)" //TODO: validar y crear constantes
        let endpoint = URL(string: endpointURL)
        
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                let responseFailed=[UUOO]()
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = [UUOO]()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Se recibieron las siguientes renovaciones : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode([UUOO].self, from: data!)!
                    success(response)
                    
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    print(response)
                    failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    print(response)
                    authFailed(response)
                default:
                    let responseFailed=[UUOO]()
                    failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    

    static func getRenovations(with token: String, with auditoriaBean: String,
                                  parameters: ObtenerRenovacionesRequest,
                                onSuccess success: @escaping (_ response: ObtenerRenovacionesResponse) -> Void,
                                onFailed failed: @escaping (_ response: ObtenerRenovacionesResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: ObtenerRenovacionesResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/listarenovacion" //TODO: validar y crear constantes
        let endpoint = URL(string: endpointURL)
        print(auditoriaBean)
        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
            
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=ObtenerRenovacionesResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = ObtenerRenovacionesResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("El servicio respondio con un http status ->",statusCode)
                    print("Se recibieron las siguientes renovaciones : " + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.renovaciones = JSONParser.decode([Renovacion].self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        print(response)
                        success(response)
                        
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        print(response)
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        print(response)
                        authFailed(response)
                    default:
                        var responseFailed=ObtenerRenovacionesResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        print(response)
                        failed(responseFailed)
                    }
               }
           })
           task.resume()
       }

    static func getDetailRequest(with token: String, with auditoriaBean: String,
                                  parameters: SolicitudRequest,
                                onSuccess success: @escaping (_ response: GetPendingResponse) -> Void,
                                onFailed failed: @escaping (_ response: GetPendingResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: GetPendingResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(parameters.codPersona ?? "")/solicitud"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
            
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
                if(response == nil){
                    var responseFailed=GetPendingResponse()
                    responseFailed.httpResponse.success = false
                    failed(responseFailed)
                }else{
                    let httpResponse = response as! HTTPURLResponse
                    let statusCode = httpResponse.statusCode
                    var response = GetPendingResponse()
                    let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                    print("El servicio respondio con un http status ->",statusCode)
                    print("Detalle de Solicitud : " + dataAsString)
                    switch statusCode {
                    case 200:
                        response.httpBody.solicitud = JSONParser.decode(Solicitud.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        success(response)
                    case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                    case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                    default:
                        var responseFailed=GetPendingResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                   }
               }
           })
           task.resume()
       }
    
    static func approveRenovation(with token: String, with auditoriaBean: String, parameters: [AprobarRenovacion],
                                onSuccess success: @escaping (_ response: AprobarRenovacionResponse) -> Void,
                                onFailed failed: @escaping (_ response: AprobarRenovacionResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: AprobarRenovacionResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/asignarRenovacionJefe"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.PUT.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=AprobarRenovacionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = AprobarRenovacionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(AprobarRenovacionesResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     authFailed(response)
                default:
                     var responseFailed=AprobarRenovacionResponse()
                     responseFailed.httpResponse.success = false
                     responseFailed.httpResponse.httpCode = String(statusCode)
                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func updateRenovationPeriod(with token: String, with auditoriaBean: String, parameters: [EditarRenovacion],
                                onSuccess success: @escaping (_ response: EditarRenovacionResponse) -> Void,
                                onFailed failed: @escaping (_ response: EditarRenovacionResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: EditarRenovacionResponse) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/periodos/updateInte"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.PUT.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")
        
        request.httpBody=JSONParser.encode(parameters)
        print(String(data: request.httpBody!, encoding: .utf8) ?? "")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=EditarRenovacionResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = EditarRenovacionResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody = JSONParser.decode(EditarRenovacionResponseBody.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     failed(response)
                case 401:
                     let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     response.httpResponse.success = true
                     response.httpResponse.httpCode = String(statusCode)
                     response.httpResponse.error = baseErrorResponse
                     authFailed(response)
                default:
                     var responseFailed=EditarRenovacionResponse()
                     responseFailed.httpResponse.success = false
                     responseFailed.httpResponse.httpCode = String(statusCode)
                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func getRenovationCodes(with token: String, with auditoriaBean: String,
                                onSuccess success: @escaping (_ response: [RenovationType]) -> Void,
                                onFailed failed: @escaping (_ response: [RenovationType]) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: [RenovationType]) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/unidadorganica/obtenerCodigo"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                let responseFailed=[RenovationType]()
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = [RenovationType]()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode([RenovationType].self, from: data!)!
                    success(response)
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!

                     authFailed(response)
                default:
                    let responseFailed=[RenovationType]()

                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
    static func getRenovationPeriods(with token: String, with auditoriaBean: String,
                                onSuccess success: @escaping (_ response: [RenovationPeriod]) -> Void,
                                onFailed failed: @escaping (_ response: [RenovationPeriod]) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: [RenovationPeriod]) -> Void){
        
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/periodos/obtenerPeriodo"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.GET.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")

        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                let responseFailed=[RenovationPeriod]()
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = [RenovationPeriod]()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print("El servicio respondio con un http status ->",statusCode)
                print("Respuesta Aprobacion Solicitud : " + dataAsString)
                switch statusCode {
                case 200:
                    response = JSONParser.decode([RenovationPeriod].self, from: data!)!
                    success(response)
                case 400:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                     failed(response)
                case 401:
                    _ = JSONParser.decode(BaseErrorResponse.self, from: data!)!

                     authFailed(response)
                default:
                    let responseFailed=[RenovationPeriod]()

                     failed(responseFailed)
                }
            }
        })
        task.resume()
    }
}
