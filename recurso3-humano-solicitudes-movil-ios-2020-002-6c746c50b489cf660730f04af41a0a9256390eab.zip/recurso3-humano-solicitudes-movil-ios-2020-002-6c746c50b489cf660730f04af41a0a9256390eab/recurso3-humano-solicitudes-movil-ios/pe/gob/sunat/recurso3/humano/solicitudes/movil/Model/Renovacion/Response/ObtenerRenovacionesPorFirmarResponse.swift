//
//  ObtenerRenovacionesPorFirmarResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import Foundation

struct ObtenerRenovacionesPorFirmarResponse : Decodable {
    
    var httpResponse = BaseResponse()
    var httpBody = ObtenerRenovacionesPorFirmarResponseBody()
}
