//
//  EditarRenovacionResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/29/20.
//

import Foundation

struct EditarRenovacionResponseBody : Decodable {
    var exito : Bool?
    var mensaje : String?
}
