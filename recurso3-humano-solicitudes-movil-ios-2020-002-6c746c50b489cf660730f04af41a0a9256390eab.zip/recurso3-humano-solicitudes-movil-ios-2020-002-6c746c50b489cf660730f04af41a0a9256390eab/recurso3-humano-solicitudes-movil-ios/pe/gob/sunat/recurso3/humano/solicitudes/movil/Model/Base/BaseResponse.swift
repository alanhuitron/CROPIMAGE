//
//  BaseResponse.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/16/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct BaseResponse : Codable {
    
    var success = Bool()
    var httpCode = String ()
    var error = BaseErrorResponse()
    
}
