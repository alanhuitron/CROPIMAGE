//
//  KeyChainHelper.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/21/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

class KeyChainHelper {
    
    static func findByKey(searchIn keychainAccessGroupName : String, using itemKey : String) -> String{
        
        print(keychainAccessGroupName)
        print(itemKey)
        
        var value = String()
        let queryLoad: [String: AnyObject] = [
          kSecClass as String: kSecClassGenericPassword,
          kSecAttrAccount as String: itemKey as AnyObject,
          kSecReturnData as String: kCFBooleanTrue,
          kSecMatchLimit as String: kSecMatchLimitOne,
          kSecAttrAccessGroup as String: keychainAccessGroupName as AnyObject
        ]

        var result: AnyObject?

        let resultCodeLoad = withUnsafeMutablePointer(to: &result) {
          SecItemCopyMatching(queryLoad as CFDictionary, UnsafeMutablePointer($0))
        }

        if resultCodeLoad == noErr {
          if let result = result as? Data,
            let keyValue = NSString(data: result,
                                    encoding: String.Encoding.utf8.rawValue) as String? {
            value = keyValue
          }
        } else {
          print("Error loading from Keychain: \(resultCodeLoad)")
        }
        return value
    }
    
    static func addKeyValue(addIn keychainAccessGroupName : String, theKey itemKey : String, theValue itemValue : String){
        guard let valueData = itemValue.data(using: String.Encoding.utf8) else {
          print("Error saving text to Keychain")
          return
        }
        print(keychainAccessGroupName)
        print(itemKey)

        let queryAdd: [String: AnyObject] = [
          kSecClass as String: kSecClassGenericPassword,
          kSecAttrAccount as String: itemKey as AnyObject,
          kSecValueData as String: valueData as AnyObject,
          kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlocked,
          kSecAttrAccessGroup as String: keychainAccessGroupName as AnyObject
        ]

        let resultCode = SecItemAdd(queryAdd as CFDictionary, nil)

        if resultCode != noErr {
          print("Error saving to Keychain: \(resultCode)")
        }
    }
    
    static func deleteByKey(deleteIn keychainAccessGroupName : String, using itemKey : String){
        let queryDelete: [String: AnyObject] = [
          kSecClass as String: kSecClassGenericPassword,
          kSecAttrAccount as String: itemKey as AnyObject,
          kSecAttrAccessGroup as String: keychainAccessGroupName as AnyObject
        ]

        let resultCodeDelete = SecItemDelete(queryDelete as CFDictionary)

        if resultCodeDelete != noErr {
          print("Error deleting from Keychain: \(resultCodeDelete)")
        }
    }
}
