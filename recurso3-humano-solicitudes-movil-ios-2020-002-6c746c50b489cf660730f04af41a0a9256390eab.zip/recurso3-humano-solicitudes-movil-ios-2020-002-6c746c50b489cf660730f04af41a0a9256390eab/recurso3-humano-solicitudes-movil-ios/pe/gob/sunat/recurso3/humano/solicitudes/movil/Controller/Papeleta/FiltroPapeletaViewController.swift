//
//  FiltroPapeletaaViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/11/19.
//

import UIKit
import Foundation


protocol FiltroPapeletasPendientesViewControllerDelegate {
    
    func filtersWereApplied(filteredApplications : [Papeleta]?)
    
    func cleanFiltersPapeleta()
    
}

class FiltroPapeletaViewController: ParentViewController
 {

    @IBOutlet weak var headerNavigationBarView: UIView!
   // @IBOutlet weak var botonCriterio: UIButton!
    
    @IBOutlet weak var textFechaIni: UITextField!
    @IBOutlet weak var textFechaFin: UITextField!
    
    
    @IBOutlet weak var cbxCriterio: UIPickerText!
    
    @IBOutlet weak var txtCodCriterio: UITextField!
    
    var delegate : FiltroPapeletasPendientesViewControllerDelegate?
    let datePickerFechaIni = UIDatePicker()
    let datePickerFechaFin = UIDatePicker()
    var criterionCode : String?
    var criterionData : String?
    var applicationTypeCode : String?
    var modalDropDown = DropDownCriterioViewController()
    
    override func viewDidLoad() {
    super.viewDidLoad()
        
        
        let bottomLine = CALayer()
             bottomLine.frame = CGRect(x: 0.0, y: 75 - 1, width: 300, height: 1.0)
             bottomLine.backgroundColor = UIColor.white.cgColor
             txtCodCriterio.borderStyle = .none
             txtCodCriterio.layer.addSublayer(bottomLine)
             txtCodCriterio.delegate = self
        
        self.setHeaderView(self.headerNavigationBarView, viewController: self, title: "Papeletas Pendientes", leftImage: "iconLeft")
        iniDatePicker(fechaDatePicker: datePickerFechaIni ,  textFecha : textFechaIni)
        iniDatePicker(fechaDatePicker: datePickerFechaFin ,  textFecha : textFechaFin)
        
        datePickerFechaIni.addTarget(self , action: #selector(self.dateChangedFechaini(datePicker:)    ), for: .valueChanged)
        datePickerFechaFin.addTarget(self , action: #selector(self.dateChangedFechaFin(datePicker:)    ), for: .valueChanged)
        self.cbxCriterio.customizeBorder(color: UIColor(netHex: 0x1976D2), width: 2, cornerRadius: 3)
        

        let color = UIColor(netHex: 0x1976D2)
        textFechaIni.layer.borderColor = color.cgColor
        textFechaIni.layer.cornerRadius = 3
        textFechaIni.layer.borderWidth = 2
        
        textFechaFin.layer.borderColor = color.cgColor
        textFechaFin.layer.cornerRadius = 3
        textFechaFin.layer.borderWidth = 2

        self.setup()
    }
    

    func iniDatePicker (fechaDatePicker : UIDatePicker , textFecha : UITextField ){
        
        let localeID = Locale.preferredLanguages.first
        fechaDatePicker.locale = Locale(identifier: localeID!)
        fechaDatePicker.datePickerMode = .date
       // fechaDatePicker.addTarget(self , action: #selector(self.dateChangedFechaini(datePicker:)    ), for: .valueChanged)
        textFecha.inputView = fechaDatePicker
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapGestureDone))
      
    }
    
    @objc func dateChangedFechaini (datePicker : UIDatePicker ) {
        let dateFormatter = DateFormatter ()
        dateFormatter.dateFormat = "dd/MM/yyyy"
       textFechaIni.text = dateFormatter.string(from: datePicker.date)
             view.endEditing(true)
    }
    
    
    @objc func dateChangedFechaFin (datePicker : UIDatePicker) {
        let dateFormatter = DateFormatter ()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        textFechaFin.text = dateFormatter.string(from: datePicker.date)
          view.endEditing(true)
    }

    @objc func tapGestureDone () {
        view.endEditing(true)
        ///  view.endEditing(   )
      }
    
    
    @IBAction func btnDropdown(_ sender: Any) {
        modalDropDown = self.storyboard?.instantiateViewController(withIdentifier: "dropDownCriterio") as! DropDownCriterioViewController
        modalDropDown.modalPresentationStyle = .overCurrentContext
        modalDropDown.delegate = (self as DropDownCriterioViewDelegate)
        self.present(modalDropDown, animated: true, completion: nil)
    }
    
    
    public func setBotonCriterio (texto:String){
       //  botonCriterio.setTitle( texto ,  for: .normal)
    }
    
    
    
    
    @IBAction func aplicarFiltro(_ sender: Any) {
        
        self.txtCodCriterio.resignFirstResponder()
        var haveFilters = false
        if let _ = applicationTypeCode {
            haveFilters = true
        } else if let _ = criterionCode , let _ = criterionData {
            if !criterionData!.isEmpty {
                haveFilters = true
            }
        }
        
        if !haveFilters {
            UserAlerts.showAlertMessage(on: self, message: "Debe ingresar un filtro de búsqueda")
        }else{
            let request = prepareApplicationRequest()
            self.retrieveFilteredPendingApplications(using: appDelegate.authorizationToken, with: request)
        }
    }
    
    
    
    func setup() {
        var applicationTypes = [CodeValueEntity]()
        let applicationCriteria = [
            CodeValueEntity(code: ApplicationCriterionpPapeleta.registro.rawValue, value: "Registro"),
            CodeValueEntity(code: ApplicationCriterionpPapeleta.unidadOrganiza.rawValue, value: "Unidad Organizacional"),
        ]
        
        self.cbxCriterio.loadDropdown(data: applicationCriteria)
        self.cbxCriterio.customPicker.pickerViewDelegate = self
   
    }
    
    
    func prepareApplicationRequest()->PapeletaRequest{
        var request = PapeletaRequest()
        request.codPersona = self.appDelegate.currentUser.registryNumber
        
        var parametrosDeBusqueda = ParametrosBusqueda()
        parametrosDeBusqueda.codTipo = applicationTypeCode
        if let _ = criterionCode {
            let criterion = ApplicationCriterionpPapeleta.init(rawValue: criterionCode!)
            switch criterion {
            case .registro : parametrosDeBusqueda.codPersona = criterionData
            case .unidadOrganiza : parametrosDeBusqueda.codUnidad = criterionData
                
          
            default:
                break
            }
        }
                let dateStringFormatter = DateFormatter()
        if (textFechaIni.text != "" &&  textFechaFin.text != ""){
            dateStringFormatter.dateFormat = "dd/MM/yyyy"
            var date = dateStringFormatter.date(from: textFechaIni.text!)
             dateStringFormatter.dateFormat = "yyyy-MM-dd"
                print("--->\(date)")
            parametrosDeBusqueda.fecInicio = dateStringFormatter.string(from: date!)
             dateStringFormatter.dateFormat = "dd/MM/yyyy"
            date = dateStringFormatter.date(from: textFechaFin.text!)
            dateStringFormatter.dateFormat = "yyyy-MM-dd"
            parametrosDeBusqueda.fecFin = dateStringFormatter.string(from: date!)
        }
        
        request.parametrosBusqueda = parametrosDeBusqueda
        return request
    }
    
    
    @IBAction func cleanFilter(_ sender: Any) {
        
       self.applicationTypeCode = nil
       self.textFechaIni.text = ""
       self.textFechaFin.text = ""
       self.criterionCode = nil
       txtCodCriterio.text = ""
        self.cbxCriterio.text = ""
        delegate?.cleanFiltersPapeleta()
    }
    
    func retrieveFilteredPendingApplications(using token: String, with request: PapeletaRequest){
            PapeletaWorker.getPendingPapeletaRequest(with: token, parameters: request, onSuccess: { (onSuccessResponse) in
                DispatchQueue.main.async {
                    self.delegate?.filtersWereApplied(filteredApplications: onSuccessResponse.httpBody.papeletas)
                    self.goBackMore()
                }
            }, onFailed: {(onFailed) in
                  
            }, onAuthenticationError: {(onFailedResponse) in
                self.showExpiredSessionAlert(on: self)
            })
            

        }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension FiltroPapeletaViewController : UITextFieldDelegate {
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case txtCodCriterio:
            criterionData = nil
        default:
            break
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField {
        case txtCodCriterio:
            criterionData = textField.text
        default:
            break
        }
    }
}

extension FiltroPapeletaViewController: DropDownCriterioViewDelegate{
    
    func cerrarVentana() {
        self.setBotonCriterio(texto: modalDropDown.textoSeleccionado!)
        modalDropDown.dismiss(animated: true, completion: nil)
    }
    
}

extension FiltroPapeletaViewController : PickerViewDelegate {
    func pickerViewDidSelectRow(_ pickerView: UIPickerView) {
        switch pickerView {
        case self.cbxCriterio.customPicker:
            self.criterionCode = cbxCriterio.customPicker.currentRow.code
        default:
            break
        }
    }
}

extension FiltroPapeletaViewController: HeaderViewDelegate{

    func actionLeft() {
       self.goBackMore()
    }
}

enum ApplicationCriterionpPapeleta : String{
    case registro = "registro"
    case unidadOrganiza = "UnidadOrganiza"

     case fechaIni = "fechaIni"
       case fechaFin = "fechaFin"
}
