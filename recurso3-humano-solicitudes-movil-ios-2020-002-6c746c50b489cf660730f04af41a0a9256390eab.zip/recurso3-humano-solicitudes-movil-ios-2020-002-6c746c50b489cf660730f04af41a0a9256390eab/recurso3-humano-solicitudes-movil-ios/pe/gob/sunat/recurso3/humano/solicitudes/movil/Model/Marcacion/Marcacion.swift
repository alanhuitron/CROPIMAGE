//
//  Marcacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

struct Marcacion : Codable {
    
    //De Json, no mapeado al conocerce el tipo deobjeto que contiene el array
    //"links": [],
    var hora : String?
    var desReloj : String?
    
}
