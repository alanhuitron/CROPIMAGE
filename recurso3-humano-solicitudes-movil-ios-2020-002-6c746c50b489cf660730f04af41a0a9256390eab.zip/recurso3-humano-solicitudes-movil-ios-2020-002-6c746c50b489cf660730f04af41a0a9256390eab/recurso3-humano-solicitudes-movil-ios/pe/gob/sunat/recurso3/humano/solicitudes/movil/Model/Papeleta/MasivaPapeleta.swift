//
//  MasivaPapeleta.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/15/19.
//

import Foundation
struct MasivaPapeleta:Codable {

    var indProceso : String?
    var cantidadPapeletasAtendidas : Int?
    var papeletaError :Papeleta?
    var errores : [Errores]?

}
