//
//  ConfigurationFileReader.swift
//  tecnologia3-seguridad-authenticator-ios-clientessunat
//
//  Created by MOJAVE on 10/16/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

class ConfigurationFileReader {
    
    static func read<T>(_ key: String) -> T?{
        var value : T?
        value = Bundle.main.infoDictionary?[key] as? T
        return value
    }
    
}
