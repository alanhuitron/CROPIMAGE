//
//  GetOptionsResponse.swift
//  test-rh
//
//  Created by MOJAVE on 10/31/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct GetOptionsResponse : Codable {
    
    var httpResponse = BaseResponse()
    var httpBody = GetOptionsResponseBody()
    
}
