//
//  RegistrarMarcacionResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/6/20.
//

import Foundation

struct RegistrarMarcacionResponseBody : Codable {
    
    var errorMarcaciones : [ErrorMarcacion]?
    
}
