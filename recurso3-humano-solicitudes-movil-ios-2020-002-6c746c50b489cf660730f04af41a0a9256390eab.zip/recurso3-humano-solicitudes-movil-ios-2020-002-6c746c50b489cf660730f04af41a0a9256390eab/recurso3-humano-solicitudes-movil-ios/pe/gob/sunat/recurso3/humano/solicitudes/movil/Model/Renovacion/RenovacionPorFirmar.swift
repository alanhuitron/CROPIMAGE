//
//  RenovacionPorFirmar.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/22/20.
//

import Foundation

class RenovacionPorFirmar : Decodable {
    var numIntencion : String?
    var codUuoo: String?
    var codTipocontra: String?
    var codPersonal: String?
    var desTiemposerv: String?
    var codSituacionact: String?
    var codTiporenov: String?
    var numDocumento: String?
    var desLicencia: String?
    var codDocfirgge: String?
    var codDocfircola: String?
    var codTipofircola: String?
    var numPerirenov: String?
    var obsRenovacion: String?
    var fecFirmagge: String?
    var fecFirmacola: String?
    var fecIniperiodo: String?
    var fecFinperiodo: String?
    var desTipoRenov: String?
    var desEstadoRenov: String?
    var desAccionRenov: String?
    var login: String?
    var clave: String?
}
