//
//  AprobarSolicitudResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/18/19.
//

import Foundation

struct AprobarSolicitudResponse : Codable {
    
    var httpResponse = BaseResponse()
    var httpBody = AprobacionSolicitudResponseBody()
    
}
