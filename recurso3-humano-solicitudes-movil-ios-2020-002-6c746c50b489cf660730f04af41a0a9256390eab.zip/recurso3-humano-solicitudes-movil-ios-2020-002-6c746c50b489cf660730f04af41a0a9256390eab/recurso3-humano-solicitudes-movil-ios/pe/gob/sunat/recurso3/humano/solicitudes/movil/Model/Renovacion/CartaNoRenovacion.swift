//
//  CartaNoRenovacion.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/27/20.
//

import Foundation
 
class CartaNoRenovacion : Codable {
    var nomArchivo : String?
    var desMimeType: String?
    var blobBase64: String?
}
