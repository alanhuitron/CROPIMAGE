//
//  RegistrarMarcacionResponse.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

struct RegistrarMarcacionResponse : Codable {
    
    var httpResponse = BaseResponse()
    //El body que se recibe solo trae mensajes de error, si no hay error el servicio devuelve un array vacio
    var httpBody = RegistrarMarcacionResponseBody()
}
