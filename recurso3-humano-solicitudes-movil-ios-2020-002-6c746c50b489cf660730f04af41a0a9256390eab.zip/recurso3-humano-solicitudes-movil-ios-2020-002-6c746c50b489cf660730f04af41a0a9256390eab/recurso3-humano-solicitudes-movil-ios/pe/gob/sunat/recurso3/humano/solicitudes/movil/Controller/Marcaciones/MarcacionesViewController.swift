//
//  MarcacionesViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import UIKit

class MarcacionesViewController: ParentViewController {

    @IBOutlet weak var headerNavigationBarView: UIView!
    @IBOutlet weak var marcacionesTableView: UITableView!
    @IBOutlet weak var noItemsFoundView: UIView!
    @IBOutlet weak var btnMarcarAsistencia: UIButton!
    
    let refreshControl = UIRefreshControl()
    var marcaciones = [Marcacion]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.ATTENDANCE_RECORD, leftImage: "iconMenu", rightImage: "", rightImage2: "")
        
        self.setup()
    }
    
    @IBAction func marcarAsistenciaAction(_ sender: Any) {
        if self.areLocationServicesEnableToThisApp(){
            self.startLocalizationServiceListener()
            guard let _ = self.appDelegate.location?.latitude.description, let _ = self.appDelegate.location?.longitude.description else {
                self.checkLocalizationServiceAndTakeActions()
                return
            }
            UserAlerts.showAlertSimpleAlertToUserAcceptCancelAction(on: self, message: AppConstants.MENU_POPUP.REGISTRAR_MARCACION_MESSAGE , acceptHandler: {
                self.callRegistrarMarcacion()
            }, cancelHandler: nil, btnAcceptTitle: AppConstants.MENU_POPUP.REGISTRAR_MARCACION_ACCEPT_TITLE)
        } else {
            self.checkLocalizationServiceAndTakeActions()
        }
        
    }
    
    private func setup(){
        self.marcacionesTableView.delegate = self
        self.marcacionesTableView.dataSource = self
        self.marcacionesTableView.register(UINib(nibName: UIMarcacionTableViewCell.IDENTIFIER, bundle: nil), forCellReuseIdentifier: UIMarcacionTableViewCell.IDENTIFIER)
        self.refreshControl.addTarget(self, action: #selector(callObtenerMarcacionesSelector), for: .valueChanged)
        let attributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        self.refreshControl.attributedTitle = NSAttributedString(string: "Recuperando marcaciones ...", attributes: attributes)
        self.marcacionesTableView.refreshControl = refreshControl
        self.btnMarcarAsistencia.roundBorders(corner: 5)
        
        self.callObtenerMarcaciones()
    }
    
    func setupHiddenPropertyForNotFoundRelatedViews(isHidden :  Bool){
        self.noItemsFoundView.isHidden = isHidden
    }
    
    // MARK: - SERVICES
    private func callObtenerMarcaciones(){
        self.showSpinner(onView: self.view)
        MarcacionWorker.getAttendaceRecords(with: appDelegate.authorizationToken, forUser: appDelegate.currentUser.registryNumber, onSuccess: { (onSuccessResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.marcaciones = onSuccessResponse.httpBody.marcaciones ?? []
                self.marcacionesTableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }, onFailed: { (onFailureResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.marcaciones.removeAll()
                self.marcacionesTableView.reloadData()
            }
        }, onAuthenticationError: { (onAuthenticationErrorResponse) in
            self.removeSpinner()
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing()
                self.showExpiredSessionAlert(on: self)
            }
        })
    }
    
    @objc private func callObtenerMarcacionesSelector(){
        self.callObtenerMarcaciones()
    }
    
    private func callRegistrarMarcacion(){
        self.showSpinner(onView: self.view)
        
        var request = RegistrarMarcacionRequest()
        request.codPersona = appDelegate.currentUser.registryNumber
        request.ubicacion = Ubicacion()
        request.ubicacion?.numLatitud = self.appDelegate.location?.latitude.description
        request.ubicacion?.numLongitud = self.appDelegate.location?.longitude.description
        
        MarcacionWorker.registerAttendanceRecord(with: appDelegate.authorizationToken, parameters: request, onSuccess: { (onSuccessResponse) in
            self.removeSpinner()
            if let errores = onSuccessResponse.httpBody.errorMarcaciones, errores.count > 0 {
                let errorMessage =  errores[0].msg ?? "No hay detalle."
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppMessages.SERVICE.REGITRAR_MARCACIONES.WARNING_TITLE, message: errorMessage, configuration: .Warning)
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.REGITRAR_MARCACIONES.SUCCES_MESSAGE)
            }
        }, onFailed: { (onFailureResponse) in
            self.removeSpinner()
            UserAlerts.showAlertForUserToServiceAction(on: self, message: AppMessages.SERVICE.REGITRAR_MARCACIONES.FAIL_MESSAGE, configuration: .Error)
        }) { (onAuthenticationErrorResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }
}

// MARK: - EXTENSION HeaderView
extension MarcacionesViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.openMenu()
    }
    
}

// MARK: - EXTENSION TABLEVIEW
extension MarcacionesViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.marcaciones.count > 0 {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: true)
        } else {
            self.setupHiddenPropertyForNotFoundRelatedViews(isHidden: false)
        }
        
        return self.marcaciones.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let marcacion = self.marcaciones[indexPath.row]
        
        let celda = self.marcacionesTableView.dequeueReusableCell(withIdentifier: UIMarcacionTableViewCell.IDENTIFIER, for: indexPath) as! UIMarcacionTableViewCell
        celda.lblHour.text = marcacion.hora
        celda.lblDescripcion.text = "Registrado desde: "+(marcacion.desReloj  ?? AppConstants.VALUES.EMPTY)
        
        return celda
    }
    
    
}

extension MarcacionesViewController : UIActionResultAlertViewControllerDelegate {
    
    func alertAccepted(){
        self.callObtenerMarcaciones()
    }
}
