//
//  UIExternalToolsAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/6/20.
//

import UIKit

protocol UIExternalToolsAlertViewControllerDelegate{
    
    func openChatBot(option : ExternalToolOption)
    
    func openYammerComunicandonosEnLinea(option : ExternalToolOption)
        
    func openYammerComunicadosInternos(option : ExternalToolOption)

}

class UIExternalToolsAlertViewController: UIViewController {
    
    static let IDENTIFIER = "UIExternalToolsAlertViewController"
    
    @IBOutlet weak var fillerView: UIView!
    @IBOutlet weak var chatBoxLabelViewContainer: UIView!
    @IBOutlet weak var lblChatboxLabel: UILabel!
    @IBOutlet weak var chatBoxOptionViewContainer: UIView!
    @IBOutlet weak var lblChatBoxOption: UILabel!
    
    @IBOutlet weak var yammerLabelViewContainer: UIView!
    @IBOutlet weak var yammerFirstOptionViewContainer: UIView!
    @IBOutlet weak var lblYammerFirstOption: UILabel!
    @IBOutlet weak var yammerSecondOptionViewContainer: UIView!
    @IBOutlet weak var lblYammerSecondOption: UILabel!
    
    
    var delegate : UIExternalToolsAlertViewControllerDelegate?
    var externalToolOptions = [String : ExternalToolOption]()
    
    struct Options {
        static let CHATBOX = "001"
        static let YAMMER_INTERNO = "002"
        static let YAMMER_EN_LINEA = "003"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

       self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        // Do any additional setup after loading the view.
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(singleTap))
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(panGesture))

        self.view.addGestureRecognizer(panGestureRecognizer)
        self.fillerView.addGestureRecognizer(tapGestureRecognizer)
        self.setup()
    }
    
    func setup(){
        self.chatBoxOptionViewContainer.isHidden = true
        self.yammerLabelViewContainer.isHidden = true
        self.yammerFirstOptionViewContainer.isHidden = true
        self.yammerSecondOptionViewContainer.isHidden = true
        
        if !externalToolOptions.isEmpty {
            
            if let chatboxOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.CHATBOX] {
                self.chatBoxLabelViewContainer.isHidden = false
                self.chatBoxOptionViewContainer.isHidden =  false
                self.lblChatBoxOption.text =  chatboxOption.description
            }
            
            if let yammerFirstOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.YAMMER_EN_LINEA] {
                self.yammerLabelViewContainer.isHidden = false
                self.yammerFirstOptionViewContainer.isHidden = false
                self.lblYammerFirstOption.text = yammerFirstOption.description
            }
            
            if let yammerSecondOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.YAMMER_INTERNO] {
                self.yammerLabelViewContainer.isHidden = false
                self.yammerSecondOptionViewContainer.isHidden = false
                self.lblYammerSecondOption.text = yammerSecondOption.description
            }
            
        } else {
            self.lblChatboxLabel.text = "No hay opciones disponibles"
        }
    }

    @IBAction func openChatBotAction(_ sender: Any) {
        if let chatboxOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.CHATBOX] {
            self.delegate?.openChatBot(option: chatboxOption)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func openYammerComunicandonosEnLineaAction(_ sender: Any) {
        if let yammerFirstOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.YAMMER_EN_LINEA] {
            self.delegate?.openYammerComunicandonosEnLinea(option: yammerFirstOption)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func openYammerComunicadosInternosAction(_ sender: Any) {
        if let yammerSecondOption = self.externalToolOptions[UIExternalToolsAlertViewController.Options.YAMMER_INTERNO] {
            self.delegate?.openYammerComunicadosInternos(option: yammerSecondOption)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func singleTap(recognizer: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func panGesture(recognizer: UIPanGestureRecognizer){
        let percentThreshold:CGFloat = 0.02
        
        let translation = recognizer.translation(in: self.view)
        let verticalMovement = translation.y / self.view.bounds.height
        let downwardMovement = fmaxf(Float(verticalMovement), 0.0)
        let downwardMovementPercent = fminf(downwardMovement, 1.0)
        let progress = CGFloat(downwardMovementPercent)
        if progress > percentThreshold {
            self.dismiss(animated: true, completion: nil)
        }
        
    }
}

struct ExternalToolOption {
    
    var code : String?
    var description : String?
    var serviceLink : String?
    
    init(code : String, description: String?, serviceLink: String?) {
        self.code = code
        self.description = description
        self.serviceLink =  serviceLink
    }
}
