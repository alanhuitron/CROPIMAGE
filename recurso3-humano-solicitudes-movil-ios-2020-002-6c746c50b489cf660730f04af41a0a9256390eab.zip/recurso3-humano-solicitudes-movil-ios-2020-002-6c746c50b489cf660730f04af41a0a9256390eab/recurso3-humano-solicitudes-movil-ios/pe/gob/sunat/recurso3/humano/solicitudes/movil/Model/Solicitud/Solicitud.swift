//
//  Solicitud.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation

struct Solicitud : Codable {
    
    var annSolicitud :String?
    var numSolicitud :Int?
    var desSolicitud:String?
    var fecSolicitud:String?
    var nomEmisor:String?
    var desAsunto:String?
    var fecRecepcion:String?
    var nomPersona:String?
    var nomResponsable:String?
    var codPersona:String?
    var codTipo:String?
    var nomSolicitante:String?
    var nomSolicitanteAbrev:String?
    var codUnidad:String?
    var desObservacion:String?
    var fecInicio:String?
    var fecFin:String?
    var codUsuCrea:String?
    var codUsuOrigen:String?
    var codUsuDestino:String?
    var annVacaciones:String?
    var numDias:Int?
    var numSegActual:String?
    var codUnidadSeg:String?
    var codEstado:String?
    var indFlujo:String?
    var indRrhh:String?
    var codRegimenLaboral:String?
    var seguimientos:[Seguimiento]?
    var fecInicioDate:Int?
    var fecFinDate:Int?
    var horMarcacionIncorrecta:String?
    var horMarcacionOmitida:String?
    var detalles:[LaborExcepcionalDetalle]?

    
    
    
}
