//
//  ViewController.swift
//  pruebaMenu
//
//  Created by JUAN MAURICIO on 26/09/17.
//  Copyright © 2017 jamg. All rights reserved.
//

import UIKit

class KYViewController: KYDrawerController, KYDrawerControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        self.drawerDirection = .left
        self.drawerWidth     = 280
    }
    
    // MARK: - STATIC
    static func instantiate() -> KYViewController {
        return UIStoryboard(name: AppConstants.STORYBOARD.MENU, bundle: nil).instantiateViewController(withIdentifier: AppConstants.VIEWCONTROLLER.REVEAL) as! KYViewController
    }
    
    func drawerController(_ drawerController: KYDrawerController, willChangeState state: KYDrawerController.DrawerState) {
        print(state)
    }
    
    func drawerController(_ drawerController: KYDrawerController, didChangeState state: KYDrawerController.DrawerState) {
        if state == .closed {
            UIApplication.shared.keyWindow?.windowLevel = UIWindow.Level.normal
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - NAVIGATION SECTION
    public func goToSegue(_ segue: String){
        self.performSegue(withIdentifier: segue, sender: self)
    }
    
    public func goToStoryboard(storyBoardMame : String){
        goToSegue(storyBoardMame)
        self.setDrawerState(.closed, animated: true)
    }
    
    public func goToMainMenu() {
        goToSegue(AppConstants.SEGUE.MENU)
        self.setDrawerState(.closed, animated: true)
    }
    
    public func goToRenovations() {
        goToSegue(AppConstants.SEGUE.RENOVATIONS_MENU)
        self.setDrawerState(.closed, animated: true)
    }
    
    public func goToAuthorizeRenovations() {
        goToSegue(AppConstants.SEGUE.AUTHORIZE_RENOVATIONS)
        self.setDrawerState(.closed, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }
}


