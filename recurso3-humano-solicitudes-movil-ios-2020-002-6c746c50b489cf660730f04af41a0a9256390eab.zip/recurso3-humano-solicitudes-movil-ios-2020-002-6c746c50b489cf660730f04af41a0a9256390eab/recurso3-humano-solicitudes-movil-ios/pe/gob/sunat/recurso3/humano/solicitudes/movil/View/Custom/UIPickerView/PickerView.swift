//
//  PickerView.swift
//  AppPrecintos
//
//  Created by MOJAVE on 10/5/19.
//  Copyright © 2019 canvia. All rights reserved.
//

import UIKit

protocol PickerViewDelegate {
    
    func pickerViewDidSelectRow(_ pickerView: UIPickerView)
}

class PickerView: UIPickerView,  UIPickerViewDataSource, UIPickerViewDelegate {
    
    var pickerViewDelegate : PickerViewDelegate?
    var pickerData : [CodeValueEntity]!
    var pickerTextField : UITextField!
    var selectionHandler : ((_ selectedText: String) -> Void)?
    var currentRow: CodeValueEntity!
    
    init(pickerData: [CodeValueEntity], dropdownField: UITextField) {
        super.init(frame: CGRect.zero)
        print("Ingresando \(pickerData.count) elemento(s) al picker")
        self.pickerData = pickerData
        self.pickerTextField = dropdownField
        self.pickerTextField.isEnabled = true
        self.delegate = self
        self.dataSource = self
        //dispatch
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row].value
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerData != nil && pickerData.count > 0 {
            self.currentRow = pickerData[row]
            pickerTextField.text = self.currentRow.value
        }
        pickerTextField.endEditing(true)
        
        if let _ = self.pickerViewDelegate {
            self.pickerViewDelegate?.pickerViewDidSelectRow(pickerView)
        }
    }
    
    
}
