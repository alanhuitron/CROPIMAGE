//
//  SeguimientoForRenovationResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/27/20.
//

import Foundation

struct SeguimientoForRenovationResponseBody : Codable {
    var exito: Bool?
    var data : String?
}
