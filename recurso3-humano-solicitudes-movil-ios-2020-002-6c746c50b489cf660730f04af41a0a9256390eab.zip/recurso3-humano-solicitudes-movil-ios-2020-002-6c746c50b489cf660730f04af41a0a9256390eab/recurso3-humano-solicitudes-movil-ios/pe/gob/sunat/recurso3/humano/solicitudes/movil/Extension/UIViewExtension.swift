//
//  UIViewExtension.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import Foundation
import UIKit

extension UIView {
    func colorBordersAndRoundCorners() {
        layer.borderWidth = 1
        layer.borderColor = UIColor.lightGray.cgColor
        layer.cornerRadius = 5;
    }
    
}
