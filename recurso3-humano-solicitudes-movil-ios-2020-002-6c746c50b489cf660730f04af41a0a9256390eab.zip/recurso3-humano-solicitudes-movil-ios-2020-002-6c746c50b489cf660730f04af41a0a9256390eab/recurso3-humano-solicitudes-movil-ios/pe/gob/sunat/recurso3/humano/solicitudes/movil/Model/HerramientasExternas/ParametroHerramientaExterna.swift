//
//  ParametroHerramientaExterna.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 2/5/20.
//

import Foundation

struct ParametroHerramientaExterna : Codable {
    
    var codParametro : String?
    var codDataParametro : String?
    var desParametro : String?
    var desAbreviatura : String?
    var desGlosa : String?
    
}
