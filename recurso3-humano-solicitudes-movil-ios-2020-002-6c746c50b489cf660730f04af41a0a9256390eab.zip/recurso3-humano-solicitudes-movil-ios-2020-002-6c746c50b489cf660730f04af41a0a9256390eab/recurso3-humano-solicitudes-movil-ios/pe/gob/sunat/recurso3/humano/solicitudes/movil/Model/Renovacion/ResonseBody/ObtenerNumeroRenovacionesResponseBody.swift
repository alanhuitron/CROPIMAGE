//
//  ObtenerNumeroRenovacionResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import Foundation

class ObtenerNumeroRenovacionesResponseBody : Codable {
    var cantidadregistros: String?
}
