//
//  AppLoaderHelper.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/7/19.
//

import Foundation
import UIKit

class AppInteractorHelper {
    
    static func searchForAuthorizationToken(executeIfTokenNil countermeasure: (_ controller: UIViewController) ->Void, on viewController: UIViewController) -> String? {
        //search for token
        let authToken : String? = KeyChainHelper.findByKey(searchIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
        
        //check if the token is nil or if not have content
        guard let _ = authToken, authToken!.count > 0 else{
            countermeasure(viewController)
            return authToken
        }
        return authToken
    }
    
    static func closeSessionAndInvokeIfRequired(in controller: UIViewController){
        UserAlerts.showAlertForUserToAcceptCancelAction(on: controller, title: "SIRH Móvil", message: "¿Estas seguro que quieres cerrar sesión?", acceptHandler: {
            DispatchQueue.main.async {
                KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHORIZATION_TOKEN_KEY)
                KeyChainHelper.deleteByKey(deleteIn: AppDelegate.accessGroup, using:AppConstants.SECURITY.AUTHENTICATION_TOKEN_KEY)
                
                //.rootViewController.dismissViewControllerAnimated(false, completion: nil)
                
                let sharedAppDelegate = UIApplication.shared.delegate as! AppDelegate
                sharedAppDelegate.authorizationToken = String()
                sharedAppDelegate.currentUser = UserEntity()
                sharedAppDelegate.menuOptions = [OptionEntity]()
                sharedAppDelegate.positionMenu = 0
                sharedAppDelegate.location = nil
                for vc in sharedAppDelegate.controllerWithObservers {
                    NotificationCenter.default.removeObserver(vc)
                }
                /*for vc in sharedAppDelegate.controllerToClean {
                    DispatchQueue.main.async {
                        vc.dismiss(animated: false, completion: nil)
                    }
                }*/
                let loadingDataStoryboard : UIStoryboard = UIStoryboard(name: AppConstants.STORYBOARD.LOADING, bundle: nil)
                let loadingDataViewController: LoadingViewController = loadingDataStoryboard.instantiateViewController(withIdentifier: AppConstants.VIEWCONTROLLER.LOADING) as! LoadingViewController
                controller.present(loadingDataViewController, animated: true, completion: nil)
                //RelativeAppsHelper.openRelativeApp(for: AppDelegate.actionCloseSession)
            }
        }, cancelHandler : {
            print("Se cancelo el cierre de sesión")
        })
    }
}
