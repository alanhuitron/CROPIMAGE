//
//  Segumiento.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/5/19.
//

import Foundation
struct Seguimiento: Codable{
    
    var numSeguimiento:Int?
    var codEstado:String?
    var codAccion:String?
    var fecRecepcion:String?
    var desObservacion:String?
    var nomRemitente:String?
    var desAccion:String?
    var nomDestinatario:String?
    
}
