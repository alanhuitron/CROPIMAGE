//
//  SideBarViewController.swift
//  AppSaintGeorgesCollege
//
//  Created by Rommy Fuentes Davila on 12/17/18.
//  Copyright © 2018 Saint Georges College. All rights reserved.
//

import UIKit

class SideBarViewController: UIViewController {

    //MARK: - IBOUTLETS
    @IBOutlet weak var tableView:       UITableView!
    @IBOutlet weak var lblUserName:     UILabel!
    @IBOutlet weak var lblMail:         UILabel!
    @IBOutlet weak var ivUser:          UIImageView!
    
    //MARK: - PROPERTIES
    private var lastY:      CGFloat = 0.0
    public var listCell:    [CellEntity]!
    let appDelegate =       UIApplication.shared.delegate as! AppDelegate
    var drawerController:   KYViewController?
    
    struct VALUES {
        static let CELL_IDENTIFIER = "MenuItem"
        static let CELL_IDENTIFIER_CLOSE = "MenuItemClose"
    }
    
    // MARK: - STATIC
    static func instantiate() -> SideBarViewController {
        
        return UIStoryboard(name: AppConstants.STORYBOARD.MENU, bundle: nil).instantiateViewController(withIdentifier: AppConstants.VIEWCONTROLLER.SIDEBAR) as! SideBarViewController
    }
    
    
    //MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        appDelegate.controllerWithObservers.append(self)
        print("creacion menu")
        self.setUpMenuOptions(with: appDelegate.menuOptions)
        self.setView()
        drawerController = self.parent as? KYViewController
        NotificationCenter.default.addObserver(self, selector: #selector(selectFromMenuCell(_:)), name: .onMenuOptionCellSelected, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setDefaultSelect()
    }
    
    @objc func selectFromMenuCell(_ notification : Notification){
        print("print [DBG: \(#function)]: \(self)")
        if let code = notification.userInfo?["code"] as! String?{
            for row in 0 ... (self.tableView.numberOfRows(inSection: 0)-1) {
                let index = IndexPath(row: row, section: 0)
                let cell = self.tableView.cellForRow(at: index) as! MenuCell
                if code == cell.menuCode {
                    self.tableView(self.tableView, didSelectRowAt: index)
                    break
                }
            }
        }
        
    }
    
    
    //MARK: - CONTROLLER
    func setView() {
        self.selectDefaultRow()
        self.setStatusBar()
        self.setUserData()
    }
    
    private func setUserData(){
        lblUserName.text = appDelegate.currentUser.name
        lblMail.text = appDelegate.currentUser.email
        
    }
    
    private func setStatusBar(){
        UIApplication.shared.keyWindow?.windowLevel = UIWindow.Level.statusBar
    }

    
    private func setDefaultSelect(){
        var i:Int = 0
        for item in listCell{
            item.selected = false
            if(appDelegate.positionMenu == i){
                item.selected = true
            }
            i = i + 1
        }
        tableView.reloadData()
    }
    
    private func setUpMenuOptions(with options: [OptionEntity]) {
        listCell = SideBarViewController.prepareCellList(with: options)
    }

    private func selectDefaultRow() {
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView?.selectRow(at: indexPath, animated: false, scrollPosition: .none)
        let selectedCell = self.tableView!.cellForRow(at: indexPath) as! MenuCell
        selectedCell.selectDefaultRow(image: listCell[indexPath.row].img)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
    private static func prepareCellList(with options: [OptionEntity]) -> [CellEntity] {
        var cells = [CellEntity]()
        cells.append(CellEntity(code: "00", name: AppConstants.MENU_OPTION_TITLE.MAIN_MENU, img: UIImage(named: "iconSideMenu00") ?? #imageLiteral(resourceName: "iconDot")))
        if options.count > 0 {
            for option in options {
                print("isEnable de opción \(option.codOpcion): \(option.isEnable())")
                if option.isEnable(){
                    if option.nomOpcion == "Renovación de Contratos" {
                        let cell = CellEntity(code: option.codOpcion!, name: "Renovaciones", img: UIImage(named: "iconSideMenu"+option.codOpcion!) ?? #imageLiteral(resourceName: "iconDot"))
                        cells.append(cell)
                    } else {
                        let cell = CellEntity(code: option.codOpcion!, name: option.getShortName(), img: UIImage(named: "iconSideMenu"+option.codOpcion!) ?? #imageLiteral(resourceName: "iconDot"))
                        cells.append(cell)
                    }

                }
            }
        }

        cells.append(CellEntity(code: "99", name: AppConstants.MENU_OPTION_TITLE.CLOSE_SESSION, img: UIImage(named: "iconLogout") ?? #imageLiteral(resourceName: "iconDot")))
        return cells
    }

    // LIST BY TWO SPRINT
    private func doWithSelectedCell(i: Int, isLast: Bool, cellCode: String) {
        
        let selectedOptionEnum = MenuOptionEnum(rawValue: MenuOption(stringLiteral: cellCode+",_"))
        
        if let _ = selectedOptionEnum {
            var isAnAllowedOption = false
            if AppConstants.OPTIONS_ONLY_ALLOWED_TO_SIRH_JEFE.contains(cellCode) {
                //check for user role
                if !appDelegate.currentUser.roles.isEmpty && appDelegate.currentUser.roles["SIRH-JEFE"] != nil {
                    isAnAllowedOption = true
                }
            }else {
                isAnAllowedOption = true
            }
                
            if isAnAllowedOption && AppConstants.OPTIONS_WITH_STORYBOARD_PRESENTATION.contains(cellCode){
                drawerController!.goToStoryboard(storyBoardMame: (selectedOptionEnum?.rawValue.value)!)
            } 
        } else {
            switch i {
            case 0: drawerController!.goToMainMenu()
            default:
                break
            }
        }
        
        if isLast {
            AppInteractorHelper.closeSessionAndInvokeIfRequired(in: self)
        }
        if(!isLast){
            appDelegate.positionMenu = i
        }
    }
   

    
    private func setInvokeLogout(){
        self.appDelegate.currentUser = UserEntity()
    }
    
    /*private func logoutUser(){
            UserAlerts.mostrarAlertaConTitulo(titulo: AppConstants.MESSAGES.TITLE_DIALOG, conMensaje: AppConstants.MESSAGES.LOGOUT, conNombreDeBotonCancelar: AppConstants.BUTTON.CANCEL, conNombreDeBotonAceptar: AppConstants.BUTTON.ACCEPT, enControlador: self, conCompletionCancelar: {
                self.dismiss(animated: true, completion: nil)
            }) {
                self.invokeLogout()
                //FeaturesUser.finishSession()
                UIApplication.shared.keyWindow?.windowLevel = UIWindow.Level.normal
                //self.goToLogin()
                }
     }*/
    
    private func getViewControllers() -> [UIViewController]{
        let loadingDataStoryboard : UIStoryboard = UIStoryboard(name: AppConstants.STORYBOARD.LOADING, bundle: nil)
        var vcList:[UIViewController] = [UIViewController]()
        
        let loadingDataViewController: LoadingViewController = loadingDataStoryboard.instantiateViewController(withIdentifier: AppConstants.VIEWCONTROLLER.LOADING) as! LoadingViewController
        vcList.append(loadingDataViewController)
        
        return vcList
    }
    
}

// MARK: - TABLEVIEW DELEGATE SECTION
extension SideBarViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listCell.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = VALUES.CELL_IDENTIFIER
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath) as! MenuCell
        let entity = listCell[indexPath.row]
        
        /*if(listCell[indexPath.row] == listCell.last){
            cell.viewIcon.isHidden = true
        }else{
            cell.viewIcon.isHidden = false
        }*/
        cell.setUpCell(entity: entity)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCell = tableView.cellForRow(at: indexPath) as! MenuCell
        if ReachabilitySwift.isConnectedToNetwork(){
            if(appDelegate.positionMenu != indexPath.row){
                if(listCell[indexPath.row] != listCell.last){
                    let entity = listCell[indexPath.row]
                    entity.selected = true
                    selectedCell.selectDefaultRow(image: entity.img)
                    doWithSelectedCell(i: indexPath.row, isLast: false, cellCode: entity.code)
                }else{
                    doWithSelectedCell(i: indexPath.row, isLast: true, cellCode: "99")
                }
            }else{
                //selectedCell.isSelected = false
                //dismiss(animated: true, completion: nil)
            }
        }else{
            //selectedCell.isSelected = false
            //dismiss(animated: true, completion: nil)
            UserAlerts.mostrarAlertaConTitulo(titulo: AppConstants.VALUES.EMPTY, conMensaje: AppConstants.MESSAGES.NO_CONECTION, conNombreDeBotonCancelar: AppConstants.BUTTON.ACCEPT, enControlador: self, conCompletion: {})
        }
    }
    

    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if let deselectedCell = tableView.cellForRow(at: indexPath) as? MenuCell {
            let entity = listCell[indexPath.row]
            entity.selected = false
            deselectedCell.deselectRow(image: entity.img)
        } else {
            for i in listCell {
                i.selected = false
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableViewHeight(indexPath: indexPath)
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableViewHeight(indexPath: indexPath)
    }
    
    private func tableViewHeight(indexPath: IndexPath)-> CGFloat {
        return UITableView.automaticDimension
    }
}
