//
//  GetTiposSolicitudResponseBody.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/13/19.
//

import Foundation

struct GetTiposSolicitudResponseBody : Codable {
    
    var tiposSolicitud : [Parametro]?
    
}
