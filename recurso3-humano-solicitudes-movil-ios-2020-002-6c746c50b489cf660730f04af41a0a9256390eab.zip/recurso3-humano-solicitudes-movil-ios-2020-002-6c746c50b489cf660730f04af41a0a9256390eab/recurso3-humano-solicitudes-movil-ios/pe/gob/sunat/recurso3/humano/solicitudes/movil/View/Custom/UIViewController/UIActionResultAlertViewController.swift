//
//  UIActionResultAlertViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/12/19.
//

import UIKit


@objc protocol UIActionResultAlertViewControllerDelegate {
    
    @objc optional func alertAccepted()
}

class UIActionResultAlertViewController: UIViewController {

    @IBOutlet weak var imgAlert: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnAccept: UIButton!
    @IBOutlet weak var viewParentTitle: UIView!
    @IBOutlet weak var viewParent: BorderView!
    
    var alertTitle : String?
    var alertMessage : String?
    var configuration : AlertConfiguration?
    var delegate : UIActionResultAlertViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        self.viewParent.layer.cornerRadius = 40
        self.btnAccept.layer.cornerRadius = 10
        self.lblTitle.text = alertTitle
        self.lblMessage.text = alertMessage
        self.setup(with: self.configuration)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    @IBAction func accept(_ sender: Any) {
        self.delegate?.alertAccepted?()
        self.dismiss(animated: true, completion: nil)
    }
    
    public func setup(with configuration : AlertConfiguration?){
        switch configuration {
        case .Warning:
            self.loadWithWarningStyle()
        case .Error:
            self.loadWithErrorStyle()
        default:
            break
        }
    }
    
    private func loadWithWarningStyle(){
        self.viewParentTitle.backgroundColor = UIColor(hexString: "#FCC102")
        self.btnAccept.backgroundColor = UIColor(hexString: "#FCC102")
        self.imgAlert.image = UIImage(named: "iconWarning")
    }
    
    private func loadWithErrorStyle(){
        self.viewParentTitle.backgroundColor = UIColor(hexString: "#EF5350")
        self.btnAccept.backgroundColor = UIColor(hexString: "#EF5350")
        self.imgAlert.image = UIImage(named: "iconCancel")
    }
    
    override func viewWillLayoutSubviews() {
        //self.view.layer.masksToBounds = true
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

enum AlertConfiguration{
    case Accept
    case Warning
    case Error
}
