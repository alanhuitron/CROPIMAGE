//
//  OptionWorker.swift
//  tecnologia3-arquitectura-ejemplo2-ios-clientessunat
//
//  Created by MOJAVE on 10/17/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

class MenuOpcionesWorker {
    
    static func getOptions(with token: String, forUser userRegistryNum: String,
                             onSuccess success: @escaping (_ response: GetOptionsResponse) -> Void,
                             onFailed failed: @escaping (_ response: GetOptionsResponse) -> Void,
                             onAuthenticationError authFailed: @escaping (_ response: GetOptionsResponse) -> Void){
        let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/solicitudesdeasistencia/\(userRegistryNum)/menu/opciones"
        let endpoint = URL(string: endpointURL)

        var request = URLRequest(url: endpoint!)
        request.httpMethod = HttpMethod.POST.rawValue
        request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let configuration  = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            if(response == nil){
                var responseFailed=GetOptionsResponse()
                responseFailed.httpResponse.success = false
                failed(responseFailed)
            }else{
                let httpResponse = response as! HTTPURLResponse
                let statusCode = httpResponse.statusCode
                var response = GetOptionsResponse()
                let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                print(dataAsString)
                switch statusCode {
                case 200:
                    response.httpBody.options = JSONParser.decode([OptionEntity].self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    success(response)
                case 400:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    failed(response)
                case 401:
                    let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                    response.httpResponse.success = true
                    response.httpResponse.httpCode = String(statusCode)
                    response.httpResponse.error = baseErrorResponse
                    authFailed(response)
                default:
                   var responseFailed=GetOptionsResponse()
                   responseFailed.httpResponse.success = false
                   responseFailed.httpResponse.httpCode = String(statusCode)
                   failed(responseFailed)
                }
            }
        })
        task.resume()
    }
    
}
