//
//  OptionEntity.swift
//  test-rh
//
//  Created by MOJAVE on 10/31/19.
//  Copyright © 2019 MOJAVE. All rights reserved.
//

import Foundation

struct OptionEntity : Codable {
    
    var codOpcion : String?
    var nomOpcion : String?
    var desOpcion : String?
    var codEstado : String?
    
    
    func isEnable() -> Bool{
        let enabledFlag = "1"
        return self.codEstado == enabledFlag
    }
    
    func getShortName() -> String{
        return String(self.nomOpcion?.split(separator: " ")[0] ?? "-")
    }
    
}
