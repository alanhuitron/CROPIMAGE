//
//  RenovacionTrackingWorker.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import Foundation
class RenovacionTrackingWorker {
    
    static func convertStringToDictionary(text: String) -> [String:AnyObject]? {
       if let data = text.data(using: .utf8) {
           do {
               let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
               return json
           } catch {
               print("Something went wrong")
           }
       }
       return nil
   }
    
    static func stringToData (string: String) -> Data {
        let data = Data(string.utf8)
        return data
    }
    
    static func getRenovationTracking(with token: String, with auditoriaBean: String,
                                  parameters: SeguimientoRenovacionRequest,
                                onSuccess success: @escaping (_ response: SeguimientoRenovacionResponse) -> Void,
                                onFailed failed: @escaping (_ response: SeguimientoRenovacionResponse) -> Void,
                                onAuthenticationError authFailed: @escaping (_ response: SeguimientoRenovacionResponse) -> Void){
           
            let domain = EnviromentConfiguration.RECURSOS_HUMANOS_DOMAIN
        let endpointURL = domain+"/v1/recurso/renovacion/t/periodos/obtenerSeguimiento?numIntencion=\(parameters.numIntencion!)"
            let endpoint = URL(string: endpointURL)

            var request = URLRequest(url: endpoint!)
            request.httpMethod = HttpMethod.GET.rawValue
            request.addValue("Bearer "+token, forHTTPHeaderField: "Authorization")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(auditoriaBean.toBase64(), forHTTPHeaderField: "auditoriabean")

            let configuration  = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: URLSession(), delegateQueue: nil)
            let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
               if(response == nil){
                   var responseFailed=SeguimientoRenovacionResponse()
                   responseFailed.httpResponse.success = false
                   failed(responseFailed)
               }else{
                   let httpResponse = response as! HTTPURLResponse
                   let statusCode = httpResponse.statusCode
                   var response = SeguimientoRenovacionResponse()
                   let dataAsString = String(data: data!, encoding: String.Encoding.utf8) ?? "Data could not be printed"
                   
                   print("Detalle seguimiento : " + dataAsString)
                   switch statusCode {
                   case 200:
                    print(response.httpBody)
                    response.httpBody = JSONParser.decode(GetRenovationTrackingResponseBody.self, from: data!)!
                    print(response.httpBody)
                       response.httpResponse.success = true
                       response.httpResponse.httpCode = String(statusCode)
                       success(response)
                   case 400:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        failed(response)
                   case 401:
                        let baseErrorResponse = JSONParser.decode(BaseErrorResponse.self, from: data!)!
                        response.httpResponse.success = true
                        response.httpResponse.httpCode = String(statusCode)
                        response.httpResponse.error = baseErrorResponse
                        authFailed(response)
                   default:
                        var responseFailed=SeguimientoRenovacionResponse()
                        responseFailed.httpResponse.success = false
                        responseFailed.httpResponse.httpCode = String(statusCode)
                        failed(responseFailed)
                    }
                }
        })
        task.resume()
    }
}
