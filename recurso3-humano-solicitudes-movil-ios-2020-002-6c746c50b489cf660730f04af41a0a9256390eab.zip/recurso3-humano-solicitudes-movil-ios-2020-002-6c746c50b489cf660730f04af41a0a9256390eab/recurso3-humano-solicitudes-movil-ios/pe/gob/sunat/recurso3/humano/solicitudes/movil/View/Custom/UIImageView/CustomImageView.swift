//
//  StandardImageView.swift
//  SGC
//
//  Created by Innovacion GMD on 19/04/18.
//  Copyright © 2018 Fernando Mateo Ramos. All rights reserved.
//

import UIKit

class CustomImageView: UIImageView {
    override func prepareForInterfaceBuilder() {
        self.configure()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.configure()
    }
    
    @IBInspectable override var tintColor: UIColor! {
        didSet {
            self.configure()
        }
    }
    
    private func configure() {
        self.image = self.image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
    }
}
