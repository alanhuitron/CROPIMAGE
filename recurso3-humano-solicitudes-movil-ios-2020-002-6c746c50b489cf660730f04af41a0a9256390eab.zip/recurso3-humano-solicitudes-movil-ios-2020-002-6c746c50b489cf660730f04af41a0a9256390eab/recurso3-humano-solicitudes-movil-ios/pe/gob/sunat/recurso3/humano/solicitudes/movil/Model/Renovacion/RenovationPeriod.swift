//
//  RenovationPeriod.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/29/20.
//

import Foundation
 
class RenovationPeriod : Codable {
    var numeroPeriodo: Int?
    var nombrePeriodo: String?
}


