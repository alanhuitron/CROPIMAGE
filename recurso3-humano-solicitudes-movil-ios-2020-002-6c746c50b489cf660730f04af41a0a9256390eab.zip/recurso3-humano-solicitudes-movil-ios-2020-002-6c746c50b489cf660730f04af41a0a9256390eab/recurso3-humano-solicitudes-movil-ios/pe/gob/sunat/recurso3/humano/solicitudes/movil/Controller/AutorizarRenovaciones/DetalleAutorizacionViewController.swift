//
//  DetalleAutorizacionViewController.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/13/20.
//

import UIKit

class DetalleAutorizacionViewController: ParentViewController {
    
    @IBOutlet weak var UUOOCodeAndNameLabel: UILabel!
    @IBOutlet weak var nomColaboradorLabel: UILabel!
    @IBOutlet weak var tipoContratoLabel: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var situacionLabel: UILabel!
    @IBOutlet weak var periodoLabel: UILabel!
    @IBOutlet weak var estadoLabel: UILabel!
    @IBOutlet weak var tiempoServicioLabel: UILabel!
    @IBOutlet weak var observacionTextView: UITextView!
    var parametersForRenovationDetail : Renovacion?

    @IBOutlet weak var headerNavigationBarView: UIView!
    
    @IBOutlet weak var seguimientoTableView: UITableView!
    
    @IBOutlet weak var UUOOCodeAndNameView: UIView!
    
    @IBOutlet weak var detailView: UIView!
    @IBOutlet weak var trackingHeight: NSLayoutConstraint!
    var cellContentSize : CGFloat = 650.0
    var trackings = [SeguimientoRenovacion]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setHeaderView(headerNavigationBarView, viewController: self, title: AppConstants.VIEWCONTROLLER.TITLE.RENOVATION_DETAIL, leftImage: "iconLeft")
        self.seguimientoTableView.delegate = self
        self.seguimientoTableView.dataSource = self
        self.seguimientoTableView.register(UINib(nibName: RenovacionTrackingTableViewCell.NAME, bundle: nil), forCellReuseIdentifier: RenovacionTrackingTableViewCell.IDENTIFIER)
        //self.scrollView.contentSize = CGSize(width: self.view.frame.width, height: self.view.frame.height)

        self.UUOOCodeAndNameView.colorBordersAndRoundCorners()
        self.detailView.colorBordersAndRoundCorners()
        if let parameters = parametersForRenovationDetail {
            let request = prepareRenovationRequestForDetail(parameters: parameters)
            self.retrieveRenovationTrackings(using: appDelegate.authorizationToken, with: request)
        }else{
            self.removeSpinner()
        }
        
        setupDetailLabels()
       
        // Do any additional setup after loading the view.
    }
    
    func checkIfValueIsNil(value : String?, textComponent: UILabel){
        if value != nil {
            textComponent.text = value
        } else {
            textComponent.text = ""
        }
    }
    
    func setupDetailLabels() {
        
        if let UUOOCode = parametersForRenovationDetail?.codUOrga, let UUOOName = parametersForRenovationDetail?.desUOrga {
            UUOOCodeAndNameLabel.text = "\(UUOOCode) - \( UUOOName)"
        }
        
        if let nombre = parametersForRenovationDetail?.nombPersona, let codColaborador = parametersForRenovationDetail?.codRegistro {
            self.nomColaboradorLabel.text = "\(codColaborador) - \(nombre)"
        }

        checkIfValueIsNil(value: parametersForRenovationDetail?.situacion, textComponent: situacionLabel)

        if let desPeriodo = parametersForRenovationDetail?.desPeriodo {
            periodoLabel.text = desPeriodo
        } else {
            periodoLabel.text = "SIN PERIODO"
        }
        checkIfValueIsNil(value: parametersForRenovationDetail?.tipContrato, textComponent: tipoContratoLabel)
        if let estado = parametersForRenovationDetail?.estado {
            if estado.count == 0 {
                estadoLabel.text = "SIN ESTADO"

            } else {
                estadoLabel.text = estado
            }
        } else {
            estadoLabel.text = "SIN ESTADO"
        }
        
        if let desTiempoServ = parametersForRenovationDetail?.desTiempoServ {
            if desTiempoServ.count == 0 {
                tiempoServicioLabel.text = "SIN TIEMPO DE SERVICIO"

            } else {
                tiempoServicioLabel.text = desTiempoServ
            }
        } else {
            tiempoServicioLabel.text = "SIN TIEMPO DE SERVICIO"
        }
        
        if let observation = parametersForRenovationDetail?.observacion {
            if observation.count > 0 {
                self.observacionTextView.text = observation
            } else {
                self.observacionTextView.text = "SIN OBSERVACIONES"
            }
        } else {
            self.observacionTextView.text = "SIN OBSERVACIONES"
        }
        
       
        self.observacionTextView.isEditable = false
    }

    
    func prepareRenovationRequestForDetail(parameters : Renovacion)->SeguimientoRenovacionRequest{
        var request = SeguimientoRenovacionRequest()
        request.numIntencion = Int.init(parameters.numIntencion!)
        return request
    }
    
    func retrieveRenovationTrackings(using token: String, with request: SeguimientoRenovacionRequest){
        showSpinner(onView: self.view)
        var autorizacionbean = "ios-"
        if let uuid = appDelegate.UUID {
            autorizacionbean += uuid + "|"
        }
        
        if let latitude = appDelegate.location?.latitude, let longitude = appDelegate.location?.longitude {
            autorizacionbean += "\(latitude)|\(longitude)"
        }
        RenovacionTrackingWorker.getRenovationTracking(with: token, with: autorizacionbean, parameters: request) { (onSuccessResponse) in
            DispatchQueue.main.async {
                if let lista = onSuccessResponse.httpBody.lista {
                    self.trackings = lista
                } else {
                    self.seguimientoTableView.isHidden = true
                }
                self.seguimientoTableView.reloadData()
                self.removeSpinner()
            }
        } onFailed: { (onFailed) in
            self.removeSpinner()
            if onFailed.httpResponse.httpCode.isEmpty{
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            } else {
                UserAlerts.showAlertForUserToServiceAction(on: self, title: AppConstants.MESSAGES.CONNECTION_ERROR_TITLE, message: AppConstants.MESSAGES.CONNECTION_ERROR, configuration: .Error)
            }
        } onAuthenticationError: { (onFailedResponse) in
            self.removeSpinner()
            self.showExpiredSessionAlert(on: self)
        }
    }

        
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

// MARK: - HeaderViewDelegate
extension DetalleAutorizacionViewController : HeaderViewDelegate {
    
    func actionLeft() {
        self.goBackMore()
    }
    
}

extension DetalleAutorizacionViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        self.trackingHeight.constant = CGFloat(125 * trackings.count) + 650.0
        return trackings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: RenovacionTrackingTableViewCell.IDENTIFIER ,for: indexPath) as! RenovacionTrackingTableViewCell
        let tracking = trackings[indexPath.row]
            
        if let situacion = tracking.situacion {
            cell.situacionLabel.text = situacion
        }
        if let codRegistro = tracking.codRegistro, let nombPersona = tracking.nombPersona {
            cell.codeAndNameLabel.text = "\(codRegistro) - \(nombPersona)"
        }
        if let estado = tracking.estado {
            if estado.count > 0 {
                cell.estadoAndDesPeriodoLabel.text = "\(estado)"
            } else {
                cell.estadoAndDesPeriodoLabel.text = "SIN ESTADO"
            }
        } else {
            cell.estadoAndDesPeriodoLabel.text = "SIN ESTADO"
        }
        
        if let desPeriodo = tracking.desPeriodo {
            if desPeriodo.count > 0 {
                cell.estadoAndDesPeriodoLabel.text = cell.estadoAndDesPeriodoLabel.text! + " - \(desPeriodo)"
            } else {
                cell.estadoAndDesPeriodoLabel.text = cell.estadoAndDesPeriodoLabel.text! + " - SIN PERIODO"
            }
        } else {
            cell.estadoAndDesPeriodoLabel.text = cell.estadoAndDesPeriodoLabel.text! + " - SIN PERIODO"
        }
        
        if let observacion = tracking.obsRenovacion {
            if observacion.count > 0 {
                cell.observacionLabel.text = observacion
            } else {
                cell.observacionLabel.text = ""
            }
        } else {
            cell.observacionLabel.text = ""
        }

        if let fecha = tracking.fecRegistro {
            let components = fecha.components(separatedBy: " ")
            /*let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd'/'MM'/'yyy' 'HH':'mm':'ss"
            let date = dateFormatter.date(from: fecha)
            let dateString = date?.timeAgoDisplay()*/
            cell.fechaLabel.text = components[0]
            cell.horaLabel.text =  components[1]
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*if tableView == self.tableView {
            self.selectedTracking = trackings[indexPath.row]
            self.performSegue(withIdentifier: AppConstants.SEGUE.TRACKING_DETAIL, sender: nil)
        } else if tableView == self.tableExceptional {
            let selectedDetalleLabor = exceptionalWorksDetails[indexPath.row]
            self.showLaborExcepcionalDetalle(detalleLaborExcepcional: selectedDetalleLabor)
        }
 */
    }
    
}
