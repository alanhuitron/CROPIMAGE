//
//  ObtenerNumeroRenovacionesRequest.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by Gonzalo Leon Suarez on 11/26/20.
//

import Foundation

struct ObtenerNumeroRenovacionesRequest: Codable {
    var codUOrga : String?
    var situaciones: [String] = [String]()
    var dependencias: String?
}
