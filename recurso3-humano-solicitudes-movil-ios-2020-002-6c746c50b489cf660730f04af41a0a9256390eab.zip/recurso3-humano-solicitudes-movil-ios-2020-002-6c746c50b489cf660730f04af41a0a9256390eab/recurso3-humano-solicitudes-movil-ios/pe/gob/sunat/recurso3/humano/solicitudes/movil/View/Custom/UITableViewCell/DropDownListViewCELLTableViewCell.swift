//
//  DropDownListViewCELLTableViewCell.swift
//  recurso3-humano-solicitudes-movil-ios
//
//  Created by MOJAVE on 11/9/19.
//

import UIKit

class DropDownListViewCELLTableViewCell: UITableViewCell {
    static let NAME = "DropDownListViewCELLTableViewCell"
    @IBOutlet weak var labelCriterio: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    public func setupContent(textCriterio:String){
        self.labelCriterio.text = textCriterio
    }
    
}
